[ENGLISH]

Files are free for personal use. Distributing these files (or images) commercially or with any intent for monetary gains is prohibited.
NO MODIFICATIONS OR REDISTRIBUTION WITHOUT PERMISSION.



[FRENCH]

Les fichiers propos�s peuvent �tre utilis�s librement pour un usage personnel (sur son ordinateur).
Tout usage commercial ou � but lucratif est strictement prohib�.
IL EST FORMELEMENT INTERDIT DE REDISTRIBUER CE FICHIER OU DE LE MODIFIER SANS AUTORISATION

Copyright - Tixarto.net - All Rights Reserved - 2007/2008

http://www.tixarto.net/

----------------------------------------------------------------------------------------------
                                                                                           ---
The Text In Bloc-Note Translation In English By Chozo-MJ => http://chozo-mj.deviantart.com/ ---
                                                                                           ---
----------------------------------------------------------------------------------------------