RefreshCL Icon Pack by TPDK �2005 www.tpdkdesign.net
Tous droits r�serv�s.
version 1.0  du 18/11/2005


Conditions d'utilisations
Ces ic�nes sont prot�g�es par copyright, � utilisation strictement personnelle.
Pour le moment, l'utilisation de ces ic�nes dans un cadre commercial ou � des fins commerciales est strictement interdite.

Vous ne pouvez pas (liste non exhaustive) :
- Utiliser mes icones sur un site web commercial ou logiciel commercial (shareware)
- Utiliser mes ic�nes comme �l�ment graphique de site web professionnel
- La vente ou la redistribution de ces ic�nes.

Pour toutes autres utilisations, telles que :
- Utilisation de mes ic�nes comme �l�ment graphique de site non commercial ou � but non lucratif.
- Utilisation de mes ic�nes au sein d'interface logiciel sous licence GPL (freeware GPL licence)
...mon autorisation est n�cessaire. Si vous avez mon accord, vous devrez me citer dans les licences l�gales et mettre un lien vers mon site (http://www.tpdkdesign.net).
Je ne peux �tre tenu pour responsable d'�ventuelles dommages caus�s par une mauvaise utilisation du produit.

Pour toutes demandes concernant le pack, merci de m'envoyer un email � tpdk@tpdkdesign.net.

Mes remerciements aux �quipes des sites customxp & crystalxp ainsi qu'� leurs membres pour leur soutien et leur coup de main ;)
http://crystalxp.net
http://customxp.net
http://pngfactory.net
visitez ma page deviantart : http://tpdkcasimir.deviantart.com/
