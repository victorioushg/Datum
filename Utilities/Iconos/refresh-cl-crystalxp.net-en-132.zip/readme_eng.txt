RefreshCL Icon Pack by TPDK �2005 www.tpdkdesign.net
All rights reserved.
version 1.0  2005/18/11


Terms of use
Theses icons are copyrighted, and for personal use only.
Until now, COMMERCIAL USE is strictly forbidden.

You cannot (non-exhaustive list) :
- Use my icons in commercial website
- Use my icons in a professional website layout
- Sell or distribute those icons

For any other use, such as :
- using in non-commercial website
- using icon in free software under GPL licence
you need my authorization to use them. If you have my permission, you need to credit me in your terms and put a link to my website.
I would not be responsible fo any damage you may encounter while using this product.
For any question or request about the pack, please send me an email to tpdk@tpdkdesign.net.

Special thanks to customxp's & crystalxp's teams and members for help and support ;)
http://crystalxp.net
http://customxp.net
http://pngfactory.net
visit my deviantart webpage : http://tpdkcasimir.deviantart.com/
