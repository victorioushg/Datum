Symbology: Code 128 B, C
Created By: Dobson Software
E-Mail: brian@dobsonsw.com	
Web: http://www.dobsonsw.com

Look for more free high quality barcode fonts at:
http://freebarcodefonts.dobsonsw.com/


This font is freeware and may be distributed freely with the following
restrictions:

This font may not be distributed with any software application,
commercial, shareware, or freeware, without the express written consent of
the Author.

This font may not be included in any commercial font distribution.
Freeware font distribution for a nominal fee is permissable. If your not
sure if you qualify, feel free to contact me. Any distribution of this
font should include this README file, unaltered and in it's entirety.

Use at your own risk.

For more information on font usage please see the product documentation.

Code 128 requires a stop, start, and computed check digit. If you require
an application to manage this for you please navigate to
http://www.dobsonsw.com/downloads.html 

For a free, limited online utility to manage the stop, start, and check
digit please navigate to:
http://freebarcodefonts.dobsonsw.com/code128convert.html

Thanks... and enjoy!