Imports System.IO
Imports System.Text
Imports System.Data.OleDb
Imports System.Globalization
Imports Bematech
Imports Bematech.Texto
Imports Bematech.Fiscal.ECF
Imports Bematech.Fiscal.TEF
Imports Bematech.Fiscal.ECF.CupomFiscal
Imports Bematech.Relatorios
Imports Bematech.Relatorios.Sintegra
Imports Bematech.Relatorios.Administrativos
Imports Bematech.Fiscal.GerenciamentoDados


Public Class Principal
    Inherits System.Windows.Forms.Form

#Region "Constants"
    Private Const TRANSACAO_APROVADA As String = "0"
    Private Const CONSULTA_CDC As String = "41"
    Private Const CONSULTA_CHEQUE As String = "70"
#End Region
#Region "Members"
    Private dsProdutos As DataSet
#End Region


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents txCodProd As System.Windows.Forms.TextBox
    Friend WithEvents rhtCupom As System.Windows.Forms.RichTextBox
    Friend WithEvents txQtde As System.Windows.Forms.TextBox
    'Friend Property lblSubTotal() As String
    '   Get
    '      Return lblSubTotal
    '    End Get
    '    Set(ByVal Value As String)
    '       lblSubTotal = Value
    '   End Set
    'End Property

    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents imFechamento As System.Windows.Forms.PictureBox
    Friend WithEvents imDadosCupom As System.Windows.Forms.PictureBox
    Friend WithEvents txValorPagar As System.Windows.Forms.TextBox
    Friend WithEvents cbFormaPgto As System.Windows.Forms.ComboBox
    Friend WithEvents lblMenuIniciarVenda As System.Windows.Forms.Label
    Friend WithEvents lblMenuCancelarItem As System.Windows.Forms.Label
    Friend WithEvents grbSeparador2 As System.Windows.Forms.GroupBox
    Friend WithEvents lblMenuSangria As System.Windows.Forms.Label
    Friend WithEvents lblMenuSuprimento As System.Windows.Forms.Label
    Friend WithEvents grbSeparador1 As System.Windows.Forms.GroupBox
    Friend WithEvents lblMenuSair As System.Windows.Forms.Label
    Friend WithEvents lblMenuCancelarVenda As System.Windows.Forms.Label
    Friend WithEvents lblMenuFecharVenda As System.Windows.Forms.Label
    Friend WithEvents lblMenuAlterarQtde As System.Windows.Forms.Label
    Friend WithEvents lblCaixaLivre As System.Windows.Forms.Label
    Friend WithEvents imCupom As System.Windows.Forms.PictureBox
    Friend WithEvents imDescricao As System.Windows.Forms.PictureBox
    Friend WithEvents lblMenuFecharCaixa As System.Windows.Forms.Label
    Friend WithEvents lblMenuAbrirCaixa As System.Windows.Forms.Label
    Friend WithEvents lblMenuVendas As System.Windows.Forms.Label
    Friend WithEvents pnlSintegra As System.Windows.Forms.Panel
    Friend WithEvents dtFinal As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtInicial As System.Windows.Forms.DateTimePicker
    Friend WithEvents btnVoltar As System.Windows.Forms.Button
    Friend WithEvents btnGerarRegistros As System.Windows.Forms.Button
    Friend WithEvents lblMenuSintegra As System.Windows.Forms.Label
    Friend WithEvents lblValorUnit As System.Windows.Forms.Label
    Friend WithEvents lblSubTotal As System.Windows.Forms.Label
    Friend WithEvents lblTotalVenda As System.Windows.Forms.Label
    Friend WithEvents lblDescricao As System.Windows.Forms.Label
    Friend WithEvents lblRelatorioSintegra As System.Windows.Forms.Label
    Friend WithEvents lblDataFinal As System.Windows.Forms.Label
    Friend WithEvents lblDataInicial As System.Windows.Forms.Label
    Friend WithEvents txtSintegra As System.Windows.Forms.TextBox
    Friend WithEvents lblMenuAdministrativoTEF As System.Windows.Forms.Label
    Friend WithEvents lblRelatorios As System.Windows.Forms.Label
    Friend WithEvents pnlRelatorios As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents grbRelatorios As System.Windows.Forms.GroupBox
    Friend WithEvents rbtTotalAliquota As System.Windows.Forms.RadioButton
    Friend WithEvents rbtListaVendedores As System.Windows.Forms.RadioButton
    Friend WithEvents rbtListaClientes As System.Windows.Forms.RadioButton
    Friend WithEvents rbtVendasPorECF As System.Windows.Forms.RadioButton
    Friend WithEvents rbtVendasPorVendedor As System.Windows.Forms.RadioButton
    Friend WithEvents rbtVendasPorProduto As System.Windows.Forms.RadioButton
    Friend WithEvents rbtVendasPorCliente As System.Windows.Forms.RadioButton
    Friend WithEvents rbtVendasPeriodo As System.Windows.Forms.RadioButton
    Friend WithEvents rbtListaProdutos As System.Windows.Forms.RadioButton
    Friend WithEvents btnGerarRelatGerenc As System.Windows.Forms.Button
    Friend WithEvents PrintPreviewDialog1 As System.Windows.Forms.PrintPreviewDialog
    Private WithEvents dtInicialRelatorio As System.Windows.Forms.DateTimePicker
    Private WithEvents dtFinalRelatorio As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblDtFinRelat As System.Windows.Forms.Label
    Friend WithEvents lblDtIniRelat As System.Windows.Forms.Label
    Friend WithEvents btnVoltarRelatGerenc As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Principal))
        Me.rhtCupom = New System.Windows.Forms.RichTextBox
        Me.txCodProd = New System.Windows.Forms.TextBox
        Me.txQtde = New System.Windows.Forms.TextBox
        Me.lblValorUnit = New System.Windows.Forms.Label
        Me.lblSubTotal = New System.Windows.Forms.Label
        Me.lblTotalVenda = New System.Windows.Forms.Label
        Me.lblDescricao = New System.Windows.Forms.Label
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.imCupom = New System.Windows.Forms.PictureBox
        Me.imDescricao = New System.Windows.Forms.PictureBox
        Me.imDadosCupom = New System.Windows.Forms.PictureBox
        Me.imFechamento = New System.Windows.Forms.PictureBox
        Me.txValorPagar = New System.Windows.Forms.TextBox
        Me.cbFormaPgto = New System.Windows.Forms.ComboBox
        Me.lblMenuIniciarVenda = New System.Windows.Forms.Label
        Me.lblMenuCancelarItem = New System.Windows.Forms.Label
        Me.grbSeparador2 = New System.Windows.Forms.GroupBox
        Me.lblMenuSangria = New System.Windows.Forms.Label
        Me.lblMenuSuprimento = New System.Windows.Forms.Label
        Me.grbSeparador1 = New System.Windows.Forms.GroupBox
        Me.lblMenuSair = New System.Windows.Forms.Label
        Me.lblMenuCancelarVenda = New System.Windows.Forms.Label
        Me.lblMenuFecharVenda = New System.Windows.Forms.Label
        Me.lblMenuAlterarQtde = New System.Windows.Forms.Label
        Me.lblCaixaLivre = New System.Windows.Forms.Label
        Me.lblMenuFecharCaixa = New System.Windows.Forms.Label
        Me.lblMenuAbrirCaixa = New System.Windows.Forms.Label
        Me.lblMenuVendas = New System.Windows.Forms.Label
        Me.pnlSintegra = New System.Windows.Forms.Panel
        Me.btnGerarRegistros = New System.Windows.Forms.Button
        Me.txtSintegra = New System.Windows.Forms.TextBox
        Me.btnVoltar = New System.Windows.Forms.Button
        Me.dtFinal = New System.Windows.Forms.DateTimePicker
        Me.dtInicial = New System.Windows.Forms.DateTimePicker
        Me.lblRelatorioSintegra = New System.Windows.Forms.Label
        Me.lblDataFinal = New System.Windows.Forms.Label
        Me.lblDataInicial = New System.Windows.Forms.Label
        Me.lblMenuSintegra = New System.Windows.Forms.Label
        Me.lblMenuAdministrativoTEF = New System.Windows.Forms.Label
        Me.lblRelatorios = New System.Windows.Forms.Label
        Me.pnlRelatorios = New System.Windows.Forms.Panel
        Me.grbRelatorios = New System.Windows.Forms.GroupBox
        Me.btnVoltarRelatGerenc = New System.Windows.Forms.Button
        Me.lblDtFinRelat = New System.Windows.Forms.Label
        Me.lblDtIniRelat = New System.Windows.Forms.Label
        Me.dtFinalRelatorio = New System.Windows.Forms.DateTimePicker
        Me.dtInicialRelatorio = New System.Windows.Forms.DateTimePicker
        Me.btnGerarRelatGerenc = New System.Windows.Forms.Button
        Me.rbtTotalAliquota = New System.Windows.Forms.RadioButton
        Me.rbtListaVendedores = New System.Windows.Forms.RadioButton
        Me.rbtListaClientes = New System.Windows.Forms.RadioButton
        Me.rbtVendasPorECF = New System.Windows.Forms.RadioButton
        Me.rbtVendasPorVendedor = New System.Windows.Forms.RadioButton
        Me.rbtVendasPorProduto = New System.Windows.Forms.RadioButton
        Me.rbtVendasPorCliente = New System.Windows.Forms.RadioButton
        Me.rbtVendasPeriodo = New System.Windows.Forms.RadioButton
        Me.rbtListaProdutos = New System.Windows.Forms.RadioButton
        Me.Label1 = New System.Windows.Forms.Label
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog
        Me.pnlSintegra.SuspendLayout()
        Me.pnlRelatorios.SuspendLayout()
        Me.grbRelatorios.SuspendLayout()
        Me.SuspendLayout()
        '
        'rhtCupom
        '
        Me.rhtCupom.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.rhtCupom.Font = New System.Drawing.Font("Courier New", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rhtCupom.Location = New System.Drawing.Point(184, 32)
        Me.rhtCupom.Name = "rhtCupom"
        Me.rhtCupom.ReadOnly = True
        Me.rhtCupom.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical
        Me.rhtCupom.Size = New System.Drawing.Size(376, 384)
        Me.rhtCupom.TabIndex = 23
        Me.rhtCupom.Text = ""
        Me.rhtCupom.WordWrap = False
        '
        'txCodProd
        '
        Me.txCodProd.BackColor = System.Drawing.Color.FromArgb(CType(230, Byte), CType(232, Byte), CType(185, Byte))
        Me.txCodProd.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txCodProd.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txCodProd.Location = New System.Drawing.Point(600, 56)
        Me.txCodProd.Name = "txCodProd"
        Me.txCodProd.Size = New System.Drawing.Size(168, 19)
        Me.txCodProd.TabIndex = 1
        Me.txCodProd.Text = ""
        '
        'txQtde
        '
        Me.txQtde.BackColor = System.Drawing.Color.FromArgb(CType(230, Byte), CType(232, Byte), CType(185, Byte))
        Me.txQtde.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txQtde.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txQtde.Location = New System.Drawing.Point(656, 136)
        Me.txQtde.Name = "txQtde"
        Me.txQtde.Size = New System.Drawing.Size(104, 19)
        Me.txQtde.TabIndex = 2
        Me.txQtde.Text = ""
        Me.txQtde.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblValorUnit
        '
        Me.lblValorUnit.BackColor = System.Drawing.Color.FromArgb(CType(230, Byte), CType(232, Byte), CType(185, Byte))
        Me.lblValorUnit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblValorUnit.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblValorUnit.Location = New System.Drawing.Point(656, 216)
        Me.lblValorUnit.Name = "lblValorUnit"
        Me.lblValorUnit.Size = New System.Drawing.Size(104, 24)
        Me.lblValorUnit.TabIndex = 26
        Me.lblValorUnit.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblSubTotal
        '
        Me.lblSubTotal.BackColor = System.Drawing.Color.FromArgb(CType(230, Byte), CType(232, Byte), CType(185, Byte))
        Me.lblSubTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubTotal.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblSubTotal.Location = New System.Drawing.Point(656, 304)
        Me.lblSubTotal.Name = "lblSubTotal"
        Me.lblSubTotal.Size = New System.Drawing.Size(104, 24)
        Me.lblSubTotal.TabIndex = 27
        Me.lblSubTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblTotalVenda
        '
        Me.lblTotalVenda.BackColor = System.Drawing.Color.FromArgb(CType(230, Byte), CType(232, Byte), CType(185, Byte))
        Me.lblTotalVenda.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalVenda.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblTotalVenda.Location = New System.Drawing.Point(656, 384)
        Me.lblTotalVenda.Name = "lblTotalVenda"
        Me.lblTotalVenda.Size = New System.Drawing.Size(104, 24)
        Me.lblTotalVenda.TabIndex = 28
        Me.lblTotalVenda.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblDescricao
        '
        Me.lblDescricao.BackColor = System.Drawing.Color.FromArgb(CType(230, Byte), CType(232, Byte), CType(185, Byte))
        Me.lblDescricao.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDescricao.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblDescricao.Location = New System.Drawing.Point(184, 504)
        Me.lblDescricao.Name = "lblDescricao"
        Me.lblDescricao.Size = New System.Drawing.Size(584, 32)
        Me.lblDescricao.TabIndex = 29
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 8)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(169, 582)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 30
        Me.PictureBox1.TabStop = False
        '
        'imCupom
        '
        Me.imCupom.Image = CType(resources.GetObject("imCupom.Image"), System.Drawing.Image)
        Me.imCupom.Location = New System.Drawing.Point(168, 8)
        Me.imCupom.Name = "imCupom"
        Me.imCupom.Size = New System.Drawing.Size(410, 440)
        Me.imCupom.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.imCupom.TabIndex = 31
        Me.imCupom.TabStop = False
        '
        'imDescricao
        '
        Me.imDescricao.Image = CType(resources.GetObject("imDescricao.Image"), System.Drawing.Image)
        Me.imDescricao.Location = New System.Drawing.Point(168, 440)
        Me.imDescricao.Name = "imDescricao"
        Me.imDescricao.Size = New System.Drawing.Size(621, 134)
        Me.imDescricao.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.imDescricao.TabIndex = 32
        Me.imDescricao.TabStop = False
        '
        'imDadosCupom
        '
        Me.imDadosCupom.Image = CType(resources.GetObject("imDadosCupom.Image"), System.Drawing.Image)
        Me.imDadosCupom.Location = New System.Drawing.Point(576, 8)
        Me.imDadosCupom.Name = "imDadosCupom"
        Me.imDadosCupom.Size = New System.Drawing.Size(217, 439)
        Me.imDadosCupom.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.imDadosCupom.TabIndex = 33
        Me.imDadosCupom.TabStop = False
        '
        'imFechamento
        '
        Me.imFechamento.Image = CType(resources.GetObject("imFechamento.Image"), System.Drawing.Image)
        Me.imFechamento.Location = New System.Drawing.Point(576, 8)
        Me.imFechamento.Name = "imFechamento"
        Me.imFechamento.Size = New System.Drawing.Size(217, 208)
        Me.imFechamento.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.imFechamento.TabIndex = 34
        Me.imFechamento.TabStop = False
        '
        'txValorPagar
        '
        Me.txValorPagar.BackColor = System.Drawing.Color.FromArgb(CType(230, Byte), CType(232, Byte), CType(185, Byte))
        Me.txValorPagar.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txValorPagar.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txValorPagar.Location = New System.Drawing.Point(616, 136)
        Me.txValorPagar.Name = "txValorPagar"
        Me.txValorPagar.Size = New System.Drawing.Size(136, 19)
        Me.txValorPagar.TabIndex = 36
        Me.txValorPagar.Text = ""
        Me.txValorPagar.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'cbFormaPgto
        '
        Me.cbFormaPgto.BackColor = System.Drawing.Color.FromArgb(CType(230, Byte), CType(232, Byte), CType(185, Byte))
        Me.cbFormaPgto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbFormaPgto.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbFormaPgto.Items.AddRange(New Object() {"Cart�o Visa", "Cart�o Redecard", "Cart�o Amex", "Cart�o Tecban", "Cheque", "Cheque Tecban", "Dinheiro", "Ticket"})
        Me.cbFormaPgto.Location = New System.Drawing.Point(608, 56)
        Me.cbFormaPgto.Name = "cbFormaPgto"
        Me.cbFormaPgto.Size = New System.Drawing.Size(152, 26)
        Me.cbFormaPgto.TabIndex = 37
        '
        'lblMenuIniciarVenda
        '
        Me.lblMenuIniciarVenda.BackColor = System.Drawing.Color.FromArgb(CType(218, Byte), CType(223, Byte), CType(149, Byte))
        Me.lblMenuIniciarVenda.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMenuIniciarVenda.ForeColor = System.Drawing.Color.Black
        Me.lblMenuIniciarVenda.Location = New System.Drawing.Point(16, 64)
        Me.lblMenuIniciarVenda.Name = "lblMenuIniciarVenda"
        Me.lblMenuIniciarVenda.Size = New System.Drawing.Size(136, 16)
        Me.lblMenuIniciarVenda.TabIndex = 39
        Me.lblMenuIniciarVenda.Text = "F2 - Iniciar Venda"
        '
        'lblMenuCancelarItem
        '
        Me.lblMenuCancelarItem.BackColor = System.Drawing.Color.FromArgb(CType(218, Byte), CType(223, Byte), CType(149, Byte))
        Me.lblMenuCancelarItem.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMenuCancelarItem.ForeColor = System.Drawing.Color.Black
        Me.lblMenuCancelarItem.Location = New System.Drawing.Point(16, 112)
        Me.lblMenuCancelarItem.Name = "lblMenuCancelarItem"
        Me.lblMenuCancelarItem.Size = New System.Drawing.Size(136, 16)
        Me.lblMenuCancelarItem.TabIndex = 44
        Me.lblMenuCancelarItem.Text = "F4 - Cancelar Item"
        '
        'grbSeparador2
        '
        Me.grbSeparador2.BackColor = System.Drawing.Color.FromArgb(CType(218, Byte), CType(223, Byte), CType(149, Byte))
        Me.grbSeparador2.Location = New System.Drawing.Point(16, 280)
        Me.grbSeparador2.Name = "grbSeparador2"
        Me.grbSeparador2.Size = New System.Drawing.Size(144, 8)
        Me.grbSeparador2.TabIndex = 48
        Me.grbSeparador2.TabStop = False
        '
        'lblMenuSangria
        '
        Me.lblMenuSangria.BackColor = System.Drawing.Color.FromArgb(CType(218, Byte), CType(223, Byte), CType(149, Byte))
        Me.lblMenuSangria.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMenuSangria.ForeColor = System.Drawing.Color.Black
        Me.lblMenuSangria.Location = New System.Drawing.Point(16, 256)
        Me.lblMenuSangria.Name = "lblMenuSangria"
        Me.lblMenuSangria.Size = New System.Drawing.Size(136, 16)
        Me.lblMenuSangria.TabIndex = 47
        Me.lblMenuSangria.Text = "F9 - Sangria"
        '
        'lblMenuSuprimento
        '
        Me.lblMenuSuprimento.BackColor = System.Drawing.Color.FromArgb(CType(218, Byte), CType(223, Byte), CType(149, Byte))
        Me.lblMenuSuprimento.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMenuSuprimento.ForeColor = System.Drawing.Color.Black
        Me.lblMenuSuprimento.Location = New System.Drawing.Point(16, 232)
        Me.lblMenuSuprimento.Name = "lblMenuSuprimento"
        Me.lblMenuSuprimento.Size = New System.Drawing.Size(136, 16)
        Me.lblMenuSuprimento.TabIndex = 46
        Me.lblMenuSuprimento.Text = "F8 - Suprimento"
        '
        'grbSeparador1
        '
        Me.grbSeparador1.BackColor = System.Drawing.Color.FromArgb(CType(218, Byte), CType(223, Byte), CType(149, Byte))
        Me.grbSeparador1.Location = New System.Drawing.Point(16, 184)
        Me.grbSeparador1.Name = "grbSeparador1"
        Me.grbSeparador1.Size = New System.Drawing.Size(144, 8)
        Me.grbSeparador1.TabIndex = 45
        Me.grbSeparador1.TabStop = False
        '
        'lblMenuSair
        '
        Me.lblMenuSair.BackColor = System.Drawing.Color.FromArgb(CType(218, Byte), CType(223, Byte), CType(149, Byte))
        Me.lblMenuSair.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMenuSair.ForeColor = System.Drawing.Color.Black
        Me.lblMenuSair.Location = New System.Drawing.Point(16, 296)
        Me.lblMenuSair.Name = "lblMenuSair"
        Me.lblMenuSair.Size = New System.Drawing.Size(136, 16)
        Me.lblMenuSair.TabIndex = 43
        Me.lblMenuSair.Text = "F10 - Voltar"
        '
        'lblMenuCancelarVenda
        '
        Me.lblMenuCancelarVenda.BackColor = System.Drawing.Color.FromArgb(CType(218, Byte), CType(223, Byte), CType(149, Byte))
        Me.lblMenuCancelarVenda.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMenuCancelarVenda.ForeColor = System.Drawing.Color.Black
        Me.lblMenuCancelarVenda.Location = New System.Drawing.Point(16, 160)
        Me.lblMenuCancelarVenda.Name = "lblMenuCancelarVenda"
        Me.lblMenuCancelarVenda.Size = New System.Drawing.Size(136, 16)
        Me.lblMenuCancelarVenda.TabIndex = 42
        Me.lblMenuCancelarVenda.Text = "F6 - Cancelar Venda"
        '
        'lblMenuFecharVenda
        '
        Me.lblMenuFecharVenda.BackColor = System.Drawing.Color.FromArgb(CType(218, Byte), CType(223, Byte), CType(149, Byte))
        Me.lblMenuFecharVenda.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMenuFecharVenda.ForeColor = System.Drawing.Color.Black
        Me.lblMenuFecharVenda.Location = New System.Drawing.Point(16, 136)
        Me.lblMenuFecharVenda.Name = "lblMenuFecharVenda"
        Me.lblMenuFecharVenda.Size = New System.Drawing.Size(136, 16)
        Me.lblMenuFecharVenda.TabIndex = 41
        Me.lblMenuFecharVenda.Text = "F5 - Fechar Venda"
        '
        'lblMenuAlterarQtde
        '
        Me.lblMenuAlterarQtde.BackColor = System.Drawing.Color.FromArgb(CType(218, Byte), CType(223, Byte), CType(149, Byte))
        Me.lblMenuAlterarQtde.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMenuAlterarQtde.ForeColor = System.Drawing.Color.Black
        Me.lblMenuAlterarQtde.Location = New System.Drawing.Point(16, 88)
        Me.lblMenuAlterarQtde.Name = "lblMenuAlterarQtde"
        Me.lblMenuAlterarQtde.Size = New System.Drawing.Size(136, 16)
        Me.lblMenuAlterarQtde.TabIndex = 40
        Me.lblMenuAlterarQtde.Text = "F3 - Alterar Qtde"
        '
        'lblCaixaLivre
        '
        Me.lblCaixaLivre.BackColor = System.Drawing.Color.Transparent
        Me.lblCaixaLivre.Font = New System.Drawing.Font("Verdana", 44.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCaixaLivre.ForeColor = System.Drawing.Color.White
        Me.lblCaixaLivre.Location = New System.Drawing.Point(184, 256)
        Me.lblCaixaLivre.Name = "lblCaixaLivre"
        Me.lblCaixaLivre.Size = New System.Drawing.Size(584, 81)
        Me.lblCaixaLivre.TabIndex = 49
        Me.lblCaixaLivre.Text = "CAIXA LIVRE"
        Me.lblCaixaLivre.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblMenuFecharCaixa
        '
        Me.lblMenuFecharCaixa.BackColor = System.Drawing.Color.FromArgb(CType(218, Byte), CType(223, Byte), CType(149, Byte))
        Me.lblMenuFecharCaixa.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMenuFecharCaixa.ForeColor = System.Drawing.Color.Black
        Me.lblMenuFecharCaixa.Location = New System.Drawing.Point(8, 64)
        Me.lblMenuFecharCaixa.Name = "lblMenuFecharCaixa"
        Me.lblMenuFecharCaixa.Size = New System.Drawing.Size(152, 16)
        Me.lblMenuFecharCaixa.TabIndex = 50
        Me.lblMenuFecharCaixa.Text = "Alt + F3 - Fechar Caixa"
        '
        'lblMenuAbrirCaixa
        '
        Me.lblMenuAbrirCaixa.BackColor = System.Drawing.Color.FromArgb(CType(218, Byte), CType(223, Byte), CType(149, Byte))
        Me.lblMenuAbrirCaixa.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMenuAbrirCaixa.ForeColor = System.Drawing.Color.Black
        Me.lblMenuAbrirCaixa.Location = New System.Drawing.Point(8, 64)
        Me.lblMenuAbrirCaixa.Name = "lblMenuAbrirCaixa"
        Me.lblMenuAbrirCaixa.Size = New System.Drawing.Size(152, 16)
        Me.lblMenuAbrirCaixa.TabIndex = 51
        Me.lblMenuAbrirCaixa.Text = "Alt + F2 - Abrir Caixa"
        '
        'lblMenuVendas
        '
        Me.lblMenuVendas.BackColor = System.Drawing.Color.FromArgb(CType(218, Byte), CType(223, Byte), CType(149, Byte))
        Me.lblMenuVendas.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMenuVendas.ForeColor = System.Drawing.Color.Black
        Me.lblMenuVendas.Location = New System.Drawing.Point(8, 88)
        Me.lblMenuVendas.Name = "lblMenuVendas"
        Me.lblMenuVendas.Size = New System.Drawing.Size(152, 16)
        Me.lblMenuVendas.TabIndex = 52
        Me.lblMenuVendas.Text = "Alt + F5 - Vendas"
        '
        'pnlSintegra
        '
        Me.pnlSintegra.BackColor = System.Drawing.Color.FromArgb(CType(228, Byte), CType(232, Byte), CType(185, Byte))
        Me.pnlSintegra.Controls.Add(Me.btnGerarRegistros)
        Me.pnlSintegra.Controls.Add(Me.txtSintegra)
        Me.pnlSintegra.Controls.Add(Me.btnVoltar)
        Me.pnlSintegra.Controls.Add(Me.dtFinal)
        Me.pnlSintegra.Controls.Add(Me.dtInicial)
        Me.pnlSintegra.Controls.Add(Me.lblRelatorioSintegra)
        Me.pnlSintegra.Controls.Add(Me.lblDataFinal)
        Me.pnlSintegra.Controls.Add(Me.lblDataInicial)
        Me.pnlSintegra.Location = New System.Drawing.Point(176, 16)
        Me.pnlSintegra.Name = "pnlSintegra"
        Me.pnlSintegra.Size = New System.Drawing.Size(616, 560)
        Me.pnlSintegra.TabIndex = 53
        Me.pnlSintegra.Visible = False
        '
        'btnGerarRegistros
        '
        Me.btnGerarRegistros.BackColor = System.Drawing.Color.FromArgb(CType(224, Byte), CType(224, Byte), CType(224, Byte))
        Me.btnGerarRegistros.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGerarRegistros.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnGerarRegistros.Location = New System.Drawing.Point(280, 68)
        Me.btnGerarRegistros.Name = "btnGerarRegistros"
        Me.btnGerarRegistros.Size = New System.Drawing.Size(96, 24)
        Me.btnGerarRegistros.TabIndex = 7
        Me.btnGerarRegistros.Text = "Gerar"
        '
        'txtSintegra
        '
        Me.txtSintegra.Location = New System.Drawing.Point(16, 112)
        Me.txtSintegra.Multiline = True
        Me.txtSintegra.Name = "txtSintegra"
        Me.txtSintegra.Size = New System.Drawing.Size(584, 440)
        Me.txtSintegra.TabIndex = 9
        Me.txtSintegra.Text = ""
        '
        'btnVoltar
        '
        Me.btnVoltar.BackColor = System.Drawing.Color.FromArgb(CType(185, Byte), CType(196, Byte), CType(18, Byte))
        Me.btnVoltar.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnVoltar.ForeColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(255, Byte), CType(232, Byte))
        Me.btnVoltar.Location = New System.Drawing.Point(512, 72)
        Me.btnVoltar.Name = "btnVoltar"
        Me.btnVoltar.Size = New System.Drawing.Size(88, 23)
        Me.btnVoltar.TabIndex = 8
        Me.btnVoltar.Text = "voltar"
        '
        'dtFinal
        '
        Me.dtFinal.CustomFormat = "dd/MM/yyyy"
        Me.dtFinal.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtFinal.Location = New System.Drawing.Point(152, 72)
        Me.dtFinal.Name = "dtFinal"
        Me.dtFinal.Size = New System.Drawing.Size(104, 20)
        Me.dtFinal.TabIndex = 5
        '
        'dtInicial
        '
        Me.dtInicial.CustomFormat = "dd/MM/yyyy"
        Me.dtInicial.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtInicial.Location = New System.Drawing.Point(24, 72)
        Me.dtInicial.Name = "dtInicial"
        Me.dtInicial.Size = New System.Drawing.Size(104, 20)
        Me.dtInicial.TabIndex = 3
        '
        'lblRelatorioSintegra
        '
        Me.lblRelatorioSintegra.Font = New System.Drawing.Font("Arial Black", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRelatorioSintegra.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblRelatorioSintegra.Location = New System.Drawing.Point(16, 8)
        Me.lblRelatorioSintegra.Name = "lblRelatorioSintegra"
        Me.lblRelatorioSintegra.Size = New System.Drawing.Size(272, 40)
        Me.lblRelatorioSintegra.TabIndex = 0
        Me.lblRelatorioSintegra.Text = "Relat�rio Sintegra"
        '
        'lblDataFinal
        '
        Me.lblDataFinal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDataFinal.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblDataFinal.Location = New System.Drawing.Point(152, 56)
        Me.lblDataFinal.Name = "lblDataFinal"
        Me.lblDataFinal.TabIndex = 6
        Me.lblDataFinal.Text = "Data Final:"
        '
        'lblDataInicial
        '
        Me.lblDataInicial.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDataInicial.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblDataInicial.Location = New System.Drawing.Point(24, 56)
        Me.lblDataInicial.Name = "lblDataInicial"
        Me.lblDataInicial.TabIndex = 4
        Me.lblDataInicial.Text = "Data Inicial:"
        '
        'lblMenuSintegra
        '
        Me.lblMenuSintegra.BackColor = System.Drawing.Color.FromArgb(CType(218, Byte), CType(223, Byte), CType(149, Byte))
        Me.lblMenuSintegra.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMenuSintegra.ForeColor = System.Drawing.Color.Black
        Me.lblMenuSintegra.Location = New System.Drawing.Point(8, 112)
        Me.lblMenuSintegra.Name = "lblMenuSintegra"
        Me.lblMenuSintegra.Size = New System.Drawing.Size(152, 16)
        Me.lblMenuSintegra.TabIndex = 54
        Me.lblMenuSintegra.Text = "Alt + F7 - Sintegra"
        '
        'lblMenuAdministrativoTEF
        '
        Me.lblMenuAdministrativoTEF.BackColor = System.Drawing.Color.FromArgb(CType(218, Byte), CType(223, Byte), CType(149, Byte))
        Me.lblMenuAdministrativoTEF.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMenuAdministrativoTEF.ForeColor = System.Drawing.Color.Black
        Me.lblMenuAdministrativoTEF.Location = New System.Drawing.Point(16, 208)
        Me.lblMenuAdministrativoTEF.Name = "lblMenuAdministrativoTEF"
        Me.lblMenuAdministrativoTEF.Size = New System.Drawing.Size(136, 16)
        Me.lblMenuAdministrativoTEF.TabIndex = 55
        Me.lblMenuAdministrativoTEF.Text = "F7 - Adm TEF"
        '
        'lblRelatorios
        '
        Me.lblRelatorios.BackColor = System.Drawing.Color.FromArgb(CType(218, Byte), CType(223, Byte), CType(149, Byte))
        Me.lblRelatorios.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRelatorios.ForeColor = System.Drawing.Color.Black
        Me.lblRelatorios.Location = New System.Drawing.Point(8, 136)
        Me.lblRelatorios.Name = "lblRelatorios"
        Me.lblRelatorios.Size = New System.Drawing.Size(152, 16)
        Me.lblRelatorios.TabIndex = 56
        Me.lblRelatorios.Text = "Alt + F8 - Relat�rios"
        '
        'pnlRelatorios
        '
        Me.pnlRelatorios.BackColor = System.Drawing.Color.FromArgb(CType(183, Byte), CType(194, Byte), CType(2, Byte))
        Me.pnlRelatorios.Controls.Add(Me.grbRelatorios)
        Me.pnlRelatorios.Controls.Add(Me.Label1)
        Me.pnlRelatorios.Location = New System.Drawing.Point(168, 8)
        Me.pnlRelatorios.Name = "pnlRelatorios"
        Me.pnlRelatorios.Size = New System.Drawing.Size(624, 568)
        Me.pnlRelatorios.TabIndex = 57
        Me.pnlRelatorios.Visible = False
        '
        'grbRelatorios
        '
        Me.grbRelatorios.BackColor = System.Drawing.Color.Transparent
        Me.grbRelatorios.Controls.Add(Me.btnVoltarRelatGerenc)
        Me.grbRelatorios.Controls.Add(Me.lblDtFinRelat)
        Me.grbRelatorios.Controls.Add(Me.lblDtIniRelat)
        Me.grbRelatorios.Controls.Add(Me.dtFinalRelatorio)
        Me.grbRelatorios.Controls.Add(Me.dtInicialRelatorio)
        Me.grbRelatorios.Controls.Add(Me.btnGerarRelatGerenc)
        Me.grbRelatorios.Controls.Add(Me.rbtTotalAliquota)
        Me.grbRelatorios.Controls.Add(Me.rbtListaVendedores)
        Me.grbRelatorios.Controls.Add(Me.rbtListaClientes)
        Me.grbRelatorios.Controls.Add(Me.rbtVendasPorECF)
        Me.grbRelatorios.Controls.Add(Me.rbtVendasPorVendedor)
        Me.grbRelatorios.Controls.Add(Me.rbtVendasPorProduto)
        Me.grbRelatorios.Controls.Add(Me.rbtVendasPorCliente)
        Me.grbRelatorios.Controls.Add(Me.rbtVendasPeriodo)
        Me.grbRelatorios.Controls.Add(Me.rbtListaProdutos)
        Me.grbRelatorios.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grbRelatorios.Location = New System.Drawing.Point(20, 80)
        Me.grbRelatorios.Name = "grbRelatorios"
        Me.grbRelatorios.Size = New System.Drawing.Size(584, 408)
        Me.grbRelatorios.TabIndex = 10
        Me.grbRelatorios.TabStop = False
        Me.grbRelatorios.Text = "Relat�rios"
        '
        'btnVoltarRelatGerenc
        '
        Me.btnVoltarRelatGerenc.BackColor = System.Drawing.Color.FromArgb(CType(183, Byte), CType(215, Byte), CType(2, Byte))
        Me.btnVoltarRelatGerenc.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnVoltarRelatGerenc.Location = New System.Drawing.Point(440, 40)
        Me.btnVoltarRelatGerenc.Name = "btnVoltarRelatGerenc"
        Me.btnVoltarRelatGerenc.Size = New System.Drawing.Size(88, 24)
        Me.btnVoltarRelatGerenc.TabIndex = 14
        Me.btnVoltarRelatGerenc.Text = "Voltar"
        '
        'lblDtFinRelat
        '
        Me.lblDtFinRelat.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDtFinRelat.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblDtFinRelat.Location = New System.Drawing.Point(160, 24)
        Me.lblDtFinRelat.Name = "lblDtFinRelat"
        Me.lblDtFinRelat.Size = New System.Drawing.Size(100, 16)
        Me.lblDtFinRelat.TabIndex = 13
        Me.lblDtFinRelat.Text = "Data Final"
        '
        'lblDtIniRelat
        '
        Me.lblDtIniRelat.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDtIniRelat.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblDtIniRelat.Location = New System.Drawing.Point(32, 24)
        Me.lblDtIniRelat.Name = "lblDtIniRelat"
        Me.lblDtIniRelat.Size = New System.Drawing.Size(100, 16)
        Me.lblDtIniRelat.TabIndex = 12
        Me.lblDtIniRelat.Text = "Data Inicial"
        '
        'dtFinalRelatorio
        '
        Me.dtFinalRelatorio.CustomFormat = "dd/MM/yyyy"
        Me.dtFinalRelatorio.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.dtFinalRelatorio.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtFinalRelatorio.Location = New System.Drawing.Point(160, 40)
        Me.dtFinalRelatorio.Name = "dtFinalRelatorio"
        Me.dtFinalRelatorio.Size = New System.Drawing.Size(88, 20)
        Me.dtFinalRelatorio.TabIndex = 11
        '
        'dtInicialRelatorio
        '
        Me.dtInicialRelatorio.CustomFormat = "dd/MM/yyyy"
        Me.dtInicialRelatorio.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.dtInicialRelatorio.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtInicialRelatorio.Location = New System.Drawing.Point(40, 40)
        Me.dtInicialRelatorio.Name = "dtInicialRelatorio"
        Me.dtInicialRelatorio.Size = New System.Drawing.Size(88, 20)
        Me.dtInicialRelatorio.TabIndex = 10
        '
        'btnGerarRelatGerenc
        '
        Me.btnGerarRelatGerenc.BackColor = System.Drawing.Color.FromArgb(CType(183, Byte), CType(215, Byte), CType(2, Byte))
        Me.btnGerarRelatGerenc.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnGerarRelatGerenc.Location = New System.Drawing.Point(224, 320)
        Me.btnGerarRelatGerenc.Name = "btnGerarRelatGerenc"
        Me.btnGerarRelatGerenc.Size = New System.Drawing.Size(96, 24)
        Me.btnGerarRelatGerenc.TabIndex = 9
        Me.btnGerarRelatGerenc.Text = "Gerar"
        '
        'rbtTotalAliquota
        '
        Me.rbtTotalAliquota.BackColor = System.Drawing.Color.Transparent
        Me.rbtTotalAliquota.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtTotalAliquota.Location = New System.Drawing.Point(352, 232)
        Me.rbtTotalAliquota.Name = "rbtTotalAliquota"
        Me.rbtTotalAliquota.Size = New System.Drawing.Size(128, 24)
        Me.rbtTotalAliquota.TabIndex = 8
        Me.rbtTotalAliquota.Text = "Total al�quota"
        '
        'rbtListaVendedores
        '
        Me.rbtListaVendedores.BackColor = System.Drawing.Color.Transparent
        Me.rbtListaVendedores.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtListaVendedores.Location = New System.Drawing.Point(352, 200)
        Me.rbtListaVendedores.Name = "rbtListaVendedores"
        Me.rbtListaVendedores.Size = New System.Drawing.Size(128, 24)
        Me.rbtListaVendedores.TabIndex = 7
        Me.rbtListaVendedores.Text = "Vendedores"
        '
        'rbtListaClientes
        '
        Me.rbtListaClientes.BackColor = System.Drawing.Color.Transparent
        Me.rbtListaClientes.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtListaClientes.Location = New System.Drawing.Point(352, 168)
        Me.rbtListaClientes.Name = "rbtListaClientes"
        Me.rbtListaClientes.Size = New System.Drawing.Size(128, 24)
        Me.rbtListaClientes.TabIndex = 6
        Me.rbtListaClientes.Text = "Clientes"
        '
        'rbtVendasPorECF
        '
        Me.rbtVendasPorECF.BackColor = System.Drawing.Color.Transparent
        Me.rbtVendasPorECF.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtVendasPorECF.Location = New System.Drawing.Point(88, 264)
        Me.rbtVendasPorECF.Name = "rbtVendasPorECF"
        Me.rbtVendasPorECF.Size = New System.Drawing.Size(160, 24)
        Me.rbtVendasPorECF.TabIndex = 5
        Me.rbtVendasPorECF.Text = "Vendas por ECF"
        '
        'rbtVendasPorVendedor
        '
        Me.rbtVendasPorVendedor.BackColor = System.Drawing.Color.Transparent
        Me.rbtVendasPorVendedor.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtVendasPorVendedor.Location = New System.Drawing.Point(88, 232)
        Me.rbtVendasPorVendedor.Name = "rbtVendasPorVendedor"
        Me.rbtVendasPorVendedor.Size = New System.Drawing.Size(160, 24)
        Me.rbtVendasPorVendedor.TabIndex = 4
        Me.rbtVendasPorVendedor.Text = "Vendas por vendedor"
        '
        'rbtVendasPorProduto
        '
        Me.rbtVendasPorProduto.BackColor = System.Drawing.Color.Transparent
        Me.rbtVendasPorProduto.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtVendasPorProduto.Location = New System.Drawing.Point(88, 200)
        Me.rbtVendasPorProduto.Name = "rbtVendasPorProduto"
        Me.rbtVendasPorProduto.Size = New System.Drawing.Size(160, 24)
        Me.rbtVendasPorProduto.TabIndex = 3
        Me.rbtVendasPorProduto.Text = "Vendas por produto"
        '
        'rbtVendasPorCliente
        '
        Me.rbtVendasPorCliente.BackColor = System.Drawing.Color.Transparent
        Me.rbtVendasPorCliente.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtVendasPorCliente.Location = New System.Drawing.Point(88, 168)
        Me.rbtVendasPorCliente.Name = "rbtVendasPorCliente"
        Me.rbtVendasPorCliente.Size = New System.Drawing.Size(160, 24)
        Me.rbtVendasPorCliente.TabIndex = 2
        Me.rbtVendasPorCliente.Text = "Vendas por cliente"
        '
        'rbtVendasPeriodo
        '
        Me.rbtVendasPeriodo.BackColor = System.Drawing.Color.Transparent
        Me.rbtVendasPeriodo.Checked = True
        Me.rbtVendasPeriodo.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtVendasPeriodo.Location = New System.Drawing.Point(88, 136)
        Me.rbtVendasPeriodo.Name = "rbtVendasPeriodo"
        Me.rbtVendasPeriodo.Size = New System.Drawing.Size(160, 24)
        Me.rbtVendasPeriodo.TabIndex = 1
        Me.rbtVendasPeriodo.TabStop = True
        Me.rbtVendasPeriodo.Text = "Vendas por per�odo"
        '
        'rbtListaProdutos
        '
        Me.rbtListaProdutos.BackColor = System.Drawing.Color.Transparent
        Me.rbtListaProdutos.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtListaProdutos.Location = New System.Drawing.Point(352, 136)
        Me.rbtListaProdutos.Name = "rbtListaProdutos"
        Me.rbtListaProdutos.Size = New System.Drawing.Size(128, 24)
        Me.rbtListaProdutos.TabIndex = 0
        Me.rbtListaProdutos.Text = "Produtos"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(65, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(290, 30)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Relat�rios Gerenciais"
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Location = New System.Drawing.Point(22, 29)
        Me.PrintPreviewDialog1.MinimumSize = New System.Drawing.Size(375, 250)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.TransparencyKey = System.Drawing.Color.Empty
        Me.PrintPreviewDialog1.Visible = False
        '
        'Principal
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(798, 598)
        Me.ControlBox = False
        Me.Controls.Add(Me.pnlRelatorios)
        Me.Controls.Add(Me.lblMenuAdministrativoTEF)
        Me.Controls.Add(Me.lblMenuIniciarVenda)
        Me.Controls.Add(Me.lblMenuAbrirCaixa)
        Me.Controls.Add(Me.txQtde)
        Me.Controls.Add(Me.txCodProd)
        Me.Controls.Add(Me.txValorPagar)
        Me.Controls.Add(Me.lblValorUnit)
        Me.Controls.Add(Me.lblTotalVenda)
        Me.Controls.Add(Me.lblSubTotal)
        Me.Controls.Add(Me.lblMenuFecharVenda)
        Me.Controls.Add(Me.lblMenuCancelarItem)
        Me.Controls.Add(Me.grbSeparador2)
        Me.Controls.Add(Me.lblMenuSangria)
        Me.Controls.Add(Me.lblMenuSuprimento)
        Me.Controls.Add(Me.grbSeparador1)
        Me.Controls.Add(Me.lblMenuSair)
        Me.Controls.Add(Me.lblMenuCancelarVenda)
        Me.Controls.Add(Me.lblMenuAlterarQtde)
        Me.Controls.Add(Me.cbFormaPgto)
        Me.Controls.Add(Me.imFechamento)
        Me.Controls.Add(Me.lblDescricao)
        Me.Controls.Add(Me.imDescricao)
        Me.Controls.Add(Me.rhtCupom)
        Me.Controls.Add(Me.imCupom)
        Me.Controls.Add(Me.lblMenuFecharCaixa)
        Me.Controls.Add(Me.lblMenuVendas)
        Me.Controls.Add(Me.lblCaixaLivre)
        Me.Controls.Add(Me.imDadosCupom)
        Me.Controls.Add(Me.pnlSintegra)
        Me.Controls.Add(Me.lblMenuSintegra)
        Me.Controls.Add(Me.lblRelatorios)
        Me.Controls.Add(Me.PictureBox1)
        Me.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Principal"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.pnlSintegra.ResumeLayout(False)
        Me.pnlRelatorios.ResumeLayout(False)
        Me.grbRelatorios.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Printer As ImpressoraFiscal
    Private Cabecalho As String
    Private conexaoBanco As OleDbConnection
    Private total As Decimal
    Public Shared valorTroco As Decimal


    Private Sub Principal_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try
            Dim status As StatusImpressora
            Dim splash As splash

            splash = New splash
            splash.Show()

            Printer = ImpressoraFiscal.Construir 'constroi a impressora fiscal

            'Se houver transa��o TEF pendente cancela. 
            If Printer.TEF.Transacoes.Count > 0 Then
                CancelarCupom() 'Cancela o cupom fiscal se estiver aberto 
                CancelarTransacaoTEFPendente()
            End If

            'string de conexao com o banco access
            conexaoBanco = conectar("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Application.StartupPath + "\ExemDotNET.mdb;User ID=Admin;Jet OLEDB:Database Locking Mode=1;persist security info=False")

            'define as configura��es do Access, no sql server n�o � necess�rio definir a cultura
            Dim cultura As CultureInfo = New CultureInfo(CultureInfo.CurrentCulture.LCID, False)
            cultura.NumberFormat.NumberDecimalSeparator = "."
            cultura.DateTimeFormat.ShortDatePattern = "#MM/dd/yyyy#"
            cultura.DateTimeFormat.LongTimePattern = ""

            'gerenciamento dos dados para a gera��o do sintegra
            Dim sintegra As GerenciadorDados = New GerenciadorDados(conexaoBanco)
            sintegra.CulturaInfo = cultura
            Printer.GerenciamentoDados = sintegra
            Printer.GerenciamentoDados.GerenciaSintegra = False 'habilitar p/ true caso necess�rio

            Try
                status = Printer.VerificarEstado()

                Cabecalho = Printer.Informacao.ClicheProprietario + _
                            "CNPJ:" + Printer.Informacao.CNPJ + vbNewLine + _
                            "IE:" + Printer.Informacao.InscricaoEstadual + vbNewLine

                If status.JaHouveReducaoZ Then
                    montarAparenciaCaixaFechado(True)
                Else
                    If Printer.Informacao.DataMovimento = DateTime.MinValue Then
                        montarAparenciaCaixaFechado(False)
                    Else
                        montarAparenciaCaixaAberto()
                    End If
                End If

            Catch ex As BematechException
                MsgBox(ex.Message)
            End Try

        Catch erro As Exception
            Dim formOperador As frmOperador = New frmOperador(erro.Message)
            If TypeOf erro Is ComunicacaoException Then
                formOperador = New frmOperador("Erro de comunica��o com a impressora.")
            End If

            formOperador.ShowDialog()
            formOperador.Dispose()
            Me.Dispose()

        End Try
    End Sub

    Private Function conectar(ByVal parametrosConexao As String) As OleDbConnection
        Dim conexao As OleDbConnection
        conexao = New OleDbConnection(parametrosConexao)
        conexao.Open()
        Return conexao
    End Function

    Private Function consultarProd(ByVal codProd As String, _
    ByVal conexao As OleDbConnection) As DataRow()

        Dim comando As OleDbCommand
        Dim dataAdapter As OleDbDataAdapter
        Dim dataSete As DataSet
        Dim dataTabela As DataTable


        '       comando = New OleDbCommand("select Codigo, Descricao, preco, aliquota, estoque from Produto where codigo = " + codProd.ToString(), conexao)
        comando = New OleDbCommand("SELECT COD_BARRAS, COD_PRODUTO, DESCRICAO, TIPO_ALIQUOTA, UNIDADE_MEDIDA, VALOR_ALIQUOTA, VALOR_UNITARIO FROM PRODUTO where COD_BARRAS = '" + codProd + "'", conexao)

        'comando.Parameters.Add("@Codigo", OleDbType.VarChar, 13)
        'comando.Parameters(0).Value = codProd

        dataAdapter = New OleDbDataAdapter(comando)
        dataSete = New DataSet
        Try
            dataAdapter.Fill(dataSete)
            dataTabela = dataSete.Tables(0)
        Catch ex As OleDbException
            MsgBox(ex.Message)
        End Try

        Return dataTabela.Select()

    End Function

    Private Function incluirVendaBD(ByVal nCupom As String, ByVal nECF As String, _
    ByVal conexao As OleDbConnection) As Integer
        Dim comando As OleDbCommand
        '        Dim dataAdapter As OleDbDataAdapter
        Try
            comando = New OleDbCommand("INSERT INTO Cupom(NumeroCupom, NumeroSerieECF)values('" & nCupom & "','" & nECF & "')", conexao)
            Return comando.ExecuteNonQuery()
        Catch ex As OleDbException
            MsgBox(ex.Message)
        End Try
    End Function

    Private Function incluirItemBD(ByVal nCupom As String, ByVal codProd As String, _
    ByVal qtde As Integer, ByVal preco As Double, ByVal conexao As OleDbConnection) As Integer
        Dim comando As OleDbCommand

        Try
            comando = New OleDbCommand("INSERT INTO ItensCupom(CodigoCupom, CodigoProduto, Quantidade, Preco)values('" & _
            nCupom & "','" & codProd & "'," & qtde & ",'" & preco & "')", conexao)
            Return comando.ExecuteNonQuery()
        Catch ex As OleDbException
            MsgBox(ex.Message)
        End Try

    End Function


    Public Sub atualizaDisplay(ByVal mensagem As String)
        rhtCupom.Focus()
        rhtCupom.SelectionStart = (rhtCupom.Text.Length + 1)
        rhtCupom.SelectedText = mensagem
        rhtCupom.ScrollToCaret()
        txCodProd.Focus()
    End Sub

    Private Function montaItem(ByVal item As String, ByVal descricao As String, _
    ByVal qtde As String, ByVal valor As String)
        rhtCupom.SelectionAlignment = HorizontalAlignment.Left

        While item.Length < 4
            item = item & Space(1)
        End While
        While descricao.Length < 29
            descricao = descricao & Space(1)
        End While
        While qtde.Length < 4
            qtde = Space(1) & qtde
        End While
        While valor.Length < 8
            valor = Space(1) & valor
        End While
        atualizaDisplay(Space(2) & item & Space(2) & descricao & Space(1) & qtde & Space(1) & valor & vbNewLine)

    End Function

    Private Sub abrirCupom()
        Dim retorno As Integer

        Try
            Printer.Cupom.Abrir()
            montarAparenciaVenda()
            MontarCabecalhoCupom()
        Catch ex As BematechException
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub cancelaCupom()
        Try
            Printer.Cupom.Cancelar()
            montarAparenciaCaixaAberto()
        Catch ex As BematechException
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub venderItem()
        Dim dataSete As DataSet
        Dim dataro As DataRow()
        Dim item As item
        Dim retorno As Integer

        txCodProd.Text = txCodProd.Text.PadLeft(13, "0")
        dataro = consultarProd(txCodProd.Text, conexaoBanco)
        If dataro.Length < 1 Then
            MsgBox("Produto nao cadastrado")
            Exit Sub
        End If
        lblDescricao.Text = dataro(0).Item("DESCRICAO")
        item = New item
        item.Codigo = dataro(0).Item("COD_BARRAS")
        item.Descricao = dataro(0).Item("DESCRICAO")
        item.ValorUnitario = dataro(0).Item("VALOR_UNITARIO")
        If txQtde.Text = "" Or txQtde.Text = "0" Then
            MsgBox("Quantidade nula ou zerada")
            Exit Sub
        End If

        item.Quantidade = CDbl(txQtde.Text)
        If ((dataro(0).Item("TIPO_ALIQUOTA") = "ICMS") Or _
            (dataro(0).Item("TIPO_ALIQUOTA").ToString() = "ISS")) Then
            item.Aliquota = dataro(0).Item("VALOR_ALIQUOTA").ToString()
        Else
            item.Aliquota = dataro(0).Item("TIPO_ALIQUOTA").ToString()
        End If
        'item.Aliquota = dataro(0).Item("TIPO_ALIQUOTA")
        'item.Aliquota = dataro(0).Item("VALOR_ALIQUOTA")
        Try
            Printer.Cupom.Vender(item)
            montaItem(item.NumeroSequencial, dataro(0).Item("DESCRICAO"), txQtde.Text, (item.ValorTotal.ToString("N")))
            txCodProd.Text = ""
            txQtde.Text = "1"
            lblValorUnit.Text = item.ValorUnitario.ToString("N")
            lblSubTotal.Text = item.ValorTotal.ToString("N")
            lblTotalVenda.Text = Printer.Cupom.SubTotal.ToString("N")
            txCodProd.Focus()
            'retorno = incluirItemBD(Printer.Cupom.Numero, dataro(0).Item("Codigo"), item.Quantidade, item.ValorTotal, conexaoBanco)
        Catch ex As BematechException
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub txCodProd_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txCodProd.KeyPress
        '    If e.KeyChar = ChrW(Keys.Enter) Then
        '        If txCodProd.Text = "" Then
        '            Me.txQtde.Focus()
        '            Return
        '        End If
        '        Dim tmpCodigo As String
        '        tmpCodigo = txCodProd.Text.PadLeft(13, "0")
        '        Dim produtos As DataRow()

        '        produtos = dsProdutos.Tables("Produto").Select("COD_BARRAS = " + tmpCodigo)
        '        If (produtos.Length = 0) Then

        'MessageBox.Show("Produto n�o cadastrado!", "Exemplo C#", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        '            Me.txCodProd.Text = ""
        '            Me.txCodProd.Focus()

        '        Else
        '            Dim produto As DataRow
        '            produto = produtos(0)

        '            Try
        '                Dim item As New item

        '                item.Descricao = produto("descricao").ToString()
        '                item.Codigo = produto("cod_barras").ToString()
        '                If ((produto("TIPO_ALIQUOTA").ToString() = "ICMS") Or _
        '                 (produto("TIPO_ALIQUOTA").ToString() = "ISS")) Then
        '                    item.Aliquota = produto("VALOR_ALIQUOTA").ToString()
        '                Else
        '                    item.Aliquota = produto("TIPO_ALIQUOTA").ToString()
        '                End If


        '                item.ValorUnitario = Decimal.Parse(produto("VALOR_UNITARIO").ToString())
        '                item.Quantidade = Integer.Parse(txQtde.Text)

        '                Printer.Cupom.Vender(item)

        '                '// atualiza o display
        '                Dim cupom As New StringBuilder(200)
        '                cupom.AppendFormat("{0:000}", item.NumeroSequencial)
        '                cupom.Append(" ", 2)
        '                cupom.AppendFormat("{0,-29:G}", produto("DESCRICAO"))
        '                cupom.Append(" ", 2)
        '                cupom.AppendFormat(item.Quantidade.ToString("G").PadLeft(3, " "))
        '                cupom.AppendFormat(item.ValorTotal.ToString("N").PadLeft(12, " "))
        '                cupom.Append("\n")

        '                Me.atualizaDisplay(cupom.ToString())
        '                Application.DoEvents()

        '                Me.lblValorUnit.Text = item.ValorUnitario.ToString("N")
        '                Me.lblTotalVenda.Text = item.ValorTotal.ToString("N")
        '                Me.lblDescricao.Text = produto("DESCRICAO").ToString()
        '                Me.lblTotalVenda.Text = Printer.Cupom.SubTotal.ToString("N")
        '                Me.txQtde.Text = "1" '// volta quantidade para 1
        '                Me.txCodProd.Text = ""
        '                Me.lblMenuCancelarItem.Enabled = True
        '                Me.lblMenuFecharVenda.Enabled = True


        '            Catch erro As BematechException
        '                MessageBox.Show(erro.Message, "Erro no cancelamento da venda", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '            End Try
        '        End If
        '    End If


        If e.KeyChar = ChrW(Keys.Enter) Then
            venderItem()
        Else

            Select Case e.KeyChar
                'Permite digitar somente n�meros 
            Case ChrW(48) To ChrW(57)
                    e.Handled = False
                Case ChrW(8)
                    e.Handled = False
                Case Else
                    e.Handled = True
            End Select
        End If
    End Sub
    Private Sub cancelaItem()
        Dim cancelarItem As cancelaItem
        cancelarItem = New cancelaItem(Me)
        cancelarItem.Show()
    End Sub

    Private Sub iniciaFechamento()

        montaAparenciaFechamentoVenda()

        Try
            total = Printer.Cupom.SubTotal
            txValorPagar.Text = total.ToString("N")

            Printer.Cupom.SubTotalizar()
            Printer.Cupom.Totalizar()
            cbFormaPgto.Focus()

            'Preparando o cupom para ser colocado na tela
            Dim cupom As StringBuilder = New StringBuilder(200)
            cupom.Append(" ", 40)
            cupom.Append("-", 11)
            cupom.Append(vbNewLine)
            cupom.Append("TOTAL R$")
            cupom.AppendFormat(Printer.Cupom.SubTotal.ToString("N").PadLeft(43, " "))
            cupom.Append(vbNewLine)
            atualizaDisplay(cupom.ToString())

            cbFormaPgto.SelectedIndex = 0
            cbFormaPgto.Focus()

        Catch ex As BematechException
            MsgBox(ex.Message)
        End Try
    End Sub
    Private Sub terminaVenda()

        Dim frTroco As Troco
        Try

            valorTroco = Decimal.Parse(txValorPagar.Text)

            If cbFormaPgto.Text.IndexOf("Cart�o") >= 0 Or cbFormaPgto.Text.IndexOf("Tecban") >= 0 Then
                If valorTroco > (Printer.Cupom.SubTotal - Printer.Cupom.ValorPago) Then
                    MessageBox.Show("N�o � permitido troco para as opera��es TEF.", "PDV-VB.NET", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Exit Sub
                End If

                Me.Cursor = Cursors.WaitCursor

                ' Confirma a transa��o anterior antes de solicitar uma nova
                If (Printer.TEF.TransacaoNaoConfirmada) Then
                    Dim confirmacao As SolicitacaoConfirmacao = Printer.TEF.CriarSolicitacaoConfirmacao()
                    Printer.TEF.ConfirmarTransacao(confirmacao)
                    Application.DoEvents()
                    System.Threading.Thread.Sleep(2)
                End If

                Dim transacao As transacao = Nothing

                If cbFormaPgto.Text.IndexOf("Tecban") > 0 Then
                    Printer.TEF.PathSolicitacao = "C:\Tef_disc\req"
                    Printer.TEF.PathResposta = "C:\Tef_disc\resp"

                    If cbFormaPgto.Text = "Cheque Tecban" Then
                        Dim solicitacao As SolicitacaoCheque = Printer.TEF.CriarSolicitacaoCheque(cbFormaPgto.Text, valorTroco)
                        transacao = Printer.TEF.EnviarSolicitacao(solicitacao)

                    Else

                        Dim solicitacao As SolicitacaoCartao = Printer.TEF.CriarSolicitacaoCartao(cbFormaPgto.Text, valorTroco)
                        transacao = Printer.TEF.EnviarSolicitacao(solicitacao)

                    End If
                Else
                    Printer.TEF.PathSolicitacao = "C:\Tef_dial\req"
                    Printer.TEF.PathResposta = "C:\Tef_dial\resp"

                    Dim solicitacao As SolicitacaoCartao = Printer.TEF.CriarSolicitacaoCartao(cbFormaPgto.Text, valorTroco)

                    'solicitacao.Buffer.Insert(2, "777-777 = 10\r\n");
                    transacao = Printer.TEF.EnviarSolicitacao(solicitacao)
                End If

                Application.DoEvents()
                If (transacao.Status <> TRANSACAO_APROVADA) Then

                    Me.Cursor = Cursors.Default
                    Dim formOperador As frmOperador = New frmOperador(transacao.TextoOperador)
                    formOperador.ShowDialog()
                    formOperador.Dispose()
                    Exit Sub
                End If
            End If

            ' tratamento de desligamento da impressora no cupom fiscal
            While (True)

                Try
                    Printer.Cupom.EfetuarPagamento(cbFormaPgto.Text, valorTroco)
                    Exit While

                Catch
                    If MessageBox.Show("Impressora n�o responde. Tentar imprimir novamente?", "PDV-CSharp", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1) = DialogResult.No Then
                        NaoConfirmarTransacao()
                        Exit Sub
                    End If

                End Try
            End While

            'Preparando o cupom para ser colocado na tela
            Dim cupom As StringBuilder
            cupom = New StringBuilder(105)
            cupom.AppendFormat("{0,-16:G}", cbFormaPgto.Text)
            cupom.AppendFormat(txValorPagar.Text.ToString().PadLeft(35, " "))
            cupom.AppendFormat(vbNewLine)
            atualizaDisplay(cupom.ToString())

            If Printer.Cupom.ValorPago < Printer.Cupom.SubTotal Then
                txValorPagar.Text = Decimal.Subtract(Printer.Cupom.SubTotal, Printer.Cupom.ValorPago).ToString("N")
                cbFormaPgto.SelectedIndex = 0
                cbFormaPgto.Focus()
            Else
                Dim msgs As Mensagens = New Mensagens
                msgs.Adicionar(New TextoFormatado("TER VOC� COMO CLIENTE � UM PRIVIL�GIO.", Bematech.Texto.TextoFormatado.TamanhoCaracter.Normal, TextoFormatado.FormatoCaracter.Normal, TextoFormatado.TipoAlinhamento.Centralizado))
                Dim msg As TextoFormatado = New TextoFormatado("OBRIGADO, VOLTE SEMPRE.", Bematech.Texto.TextoFormatado.TamanhoCaracter.Normal, TextoFormatado.FormatoCaracter.Normal, TextoFormatado.TipoAlinhamento.Centralizado)
                msgs.Adicionar(msg)

                ' tratamento de desligamento da impressora no cupom fiscal
                While (True)

                    Try
                        Printer.Cupom.Fechar(msgs)
                        Exit While

                    Catch
                        If MessageBox.Show("Impressora n�o responde. Tentar imprimir novamente?", "PDV-CSharp", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1) = DialogResult.No Then
                            NaoConfirmarTransacao()
                            Exit Sub
                        End If

                    End Try
                End While

                valorTroco = Printer.Cupom.ValorPago - Printer.Cupom.SubTotal

                'Preparando a string Valor Recebido e Troco para ser exibido no display;
                cupom = New StringBuilder(105)
                cupom.Append("Valor Recebido R$")
                cupom.AppendFormat(Printer.Cupom.ValorPago.ToString("N").PadLeft(34, " "))
                cupom.Append(vbNewLine)
                cupom.Append("Troco R$")
                cupom.AppendFormat(valorTroco.ToString("N").PadLeft(43, " "))
                cupom.Append(vbNewLine)
                atualizaDisplay(cupom.ToString())

                Application.DoEvents()

                If (Printer.TEF.Transacoes.Count > 0) Then
                    ImprimirTEF()
                End If

                Me.Cursor = Cursors.Default
                frTroco = New Troco(Me)
                frTroco.ShowDialog()
                montarAparenciaCaixaAberto()

            End If

        Catch erro As TEFException
            Dim formOperador As frmOperador = New frmOperador(erro.Message)
            formOperador.ShowDialog()
            formOperador.Dispose()

        Catch erro As Exception
            Dim formOperador As frmOperador = New frmOperador(erro.Message)
            formOperador.ShowDialog()
            formOperador.Dispose()

        Finally
            cbFormaPgto.Focus()
            Me.Cursor = Cursors.Default

        End Try
    End Sub

    Public Function montaMascara(ByVal valor As Double) As String
        Dim aux As Integer
        aux = InStr(CStr(valor), ",", CompareMethod.Text)
        If aux = 0 Then
            Return "R$" & valor & ",00"
        Else
            Return "R$" & valor & "0"
        End If
    End Function
    Public Sub atualizaSubTotal()
        Dim ItemCancelado As Item


        ItemCancelado = Printer.Cupom.UltimoItemCancelado
        lblTotalVenda.Text = Printer.Cupom.SubTotal.ToString("c")
        lblValorUnit.Text = ItemCancelado.ValorUnitario.ToString("c")
        lblSubTotal.Text = "-" & ItemCancelado.ValorTotal.ToString("c")

    End Sub

    Private Sub txValorPagar_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txValorPagar.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            terminaVenda()
        Else
            Select Case e.KeyChar
                'Permite digitar somente n�meros 
            Case ChrW(48) To ChrW(57)
                    e.Handled = False
                Case ChrW(8)
                    e.Handled = False
                Case ChrW(44)
                    e.Handled = False
                Case Else
                    e.Handled = True
            End Select
        End If
    End Sub


    Private Sub rhtCupom_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles rhtCupom.GotFocus
        If txCodProd.Visible Then
            txCodProd.Focus()
        Else
            txValorPagar.Focus()
        End If
    End Sub

    Private Sub MontarCabecalhoCupom()
        Dim cupom As StringBuilder = New StringBuilder(500)
        cupom.Append(Cabecalho)
        cupom.Append("-", 51)
        cupom.Append(vbNewLine)
        cupom.Append(" ", 19)
        cupom.Append("CUPOM FISCAL")
        cupom.Append(vbNewLine)
        cupom.Append("ITEM  ")
        cupom.Append("DESCRI��O                     ")
        cupom.Append("QTD  ")
        cupom.Append("TOTAL ITEM")
        cupom.Append(vbNewLine)
        cupom.Append("-", 51)
        cupom.Append(vbNewLine)
        atualizaDisplay(cupom.ToString())
    End Sub

    Private Sub montaAparenciaFechamentoVenda()
        txCodProd.Visible = False
        txQtde.Visible = False
        lblDescricao.Visible = False
        imDescricao.Visible = False
        lblValorUnit.Visible = False
        lblSubTotal.Visible = False
        lblTotalVenda.Visible = False
        imDadosCupom.Visible = False
        imFechamento.Visible = True
        cbFormaPgto.Visible = True
        txValorPagar.Visible = True
        lblMenuAlterarQtde.Enabled = False
        lblMenuCancelarItem.Enabled = False
        lblMenuFecharVenda.Enabled = False
        total = 0

    End Sub

    Public Sub montarAparenciaCaixaAberto()
        Me.Tag = "CAIXA_ABERTO"
        total = 0
        lblMenuIniciarVenda.Visible = True
        lblMenuAlterarQtde.Visible = True
        lblMenuCancelarItem.Visible = True
        lblMenuCancelarVenda.Visible = True
        lblMenuFecharVenda.Visible = True
        lblMenuSangria.Visible = True
        lblMenuSangria.Enabled = True
        lblMenuAdministrativoTEF.Visible = True
        lblMenuAdministrativoTEF.Enabled = True
        lblMenuSuprimento.Visible = True
        lblMenuSuprimento.Enabled = True
        lblMenuSair.Visible = True
        lblMenuSair.Enabled = True
        lblMenuAlterarQtde.Enabled = False
        lblMenuCancelarItem.Enabled = False
        lblMenuCancelarVenda.Enabled = False
        lblMenuFecharVenda.Enabled = False
        lblCaixaLivre.Visible = True
        lblCaixaLivre.Text = "CAIXA LIVRE"
        grbSeparador1.Visible = True
        grbSeparador2.Visible = True
        rhtCupom.Visible = False
        imCupom.Visible = False
        imFechamento.Visible = False
        cbFormaPgto.Visible = False
        txValorPagar.Visible = False
        imDadosCupom.Visible = False
        lblTotalVenda.Visible = False
        lblSubTotal.Visible = False
        lblValorUnit.Visible = False
        txQtde.Visible = False
        txCodProd.Visible = False
        imDescricao.Visible = False
        lblDescricao.Visible = False
        lblMenuFecharCaixa.Visible = False
        lblMenuAbrirCaixa.Visible = False
        lblMenuVendas.Visible = False
        lblMenuSintegra.Visible = False
        lblMenuIniciarVenda.Enabled = True
        lblMenuSair.Text = "F10 - Voltar"


    End Sub
    Public Sub montarAparenciaCaixaFechado(ByVal jahouveZ As Boolean)
        Me.Tag = "SAIR"
        lblMenuIniciarVenda.Visible = False
        lblMenuAlterarQtde.Visible = False
        lblMenuCancelarItem.Visible = False
        lblMenuCancelarVenda.Visible = False
        lblMenuFecharVenda.Visible = False
        lblMenuSangria.Visible = False
        lblMenuAdministrativoTEF.Visible = False
        lblMenuSuprimento.Visible = False
        lblMenuSair.Visible = False
        lblCaixaLivre.Visible = True
        grbSeparador1.Visible = False
        grbSeparador2.Visible = False
        rhtCupom.Visible = False
        imCupom.Visible = False
        imFechamento.Visible = False
        cbFormaPgto.Visible = False
        txValorPagar.Visible = False
        imDadosCupom.Visible = False
        lblTotalVenda.Visible = False
        lblSubTotal.Visible = False
        lblValorUnit.Visible = False
        txQtde.Visible = False
        txCodProd.Visible = False
        imDescricao.Visible = False
        lblDescricao.Visible = False
        lblCaixaLivre.Text = "CAIXA FECHADO"
        lblMenuFecharCaixa.Visible = True
        lblMenuAbrirCaixa.Visible = True
        lblMenuVendas.Visible = True
        lblMenuFecharCaixa.Enabled = False
        lblMenuAbrirCaixa.Visible = True
        If Not jahouveZ Then
            lblMenuAbrirCaixa.Enabled = True
        Else
            lblMenuAbrirCaixa.Enabled = False
        End If
        lblMenuVendas.Enabled = False
        lblMenuSintegra.Visible = True
        lblMenuSintegra.Enabled = True
        lblMenuSair.Visible = True
        lblMenuSair.Text = "F10 - Sair"


    End Sub

    Private Sub montarAparenciaVenda()
        LimparControles()
        lblMenuIniciarVenda.Visible = True
        lblMenuAlterarQtde.Visible = True
        lblMenuCancelarItem.Visible = True
        lblMenuCancelarVenda.Visible = True
        lblMenuFecharVenda.Visible = True
        lblMenuSangria.Visible = True
        lblMenuAdministrativoTEF.Visible = True
        lblMenuSuprimento.Visible = True
        lblMenuSair.Visible = True
        lblMenuIniciarVenda.Enabled = False
        lblMenuAlterarQtde.Enabled = True
        lblMenuCancelarItem.Enabled = True
        lblMenuCancelarVenda.Enabled = True
        lblMenuFecharVenda.Enabled = True
        lblCaixaLivre.Visible = False
        grbSeparador1.Visible = True
        grbSeparador2.Visible = True
        rhtCupom.Visible = True
        imCupom.Visible = True
        imFechamento.Visible = False
        cbFormaPgto.Visible = False
        txValorPagar.Visible = False
        imDadosCupom.Visible = True
        lblTotalVenda.Visible = True
        lblSubTotal.Visible = True
        lblValorUnit.Visible = True
        txQtde.Visible = True
        txCodProd.Visible = True
        imDescricao.Visible = True
        lblDescricao.Visible = True
        lblMenuFecharCaixa.Visible = False
        lblMenuAbrirCaixa.Visible = False
        lblMenuVendas.Visible = False
        lblMenuIniciarVenda.Enabled = False
        txCodProd.Focus()
        txQtde.Text = "1"
        lblValorUnit.Text = "R$" & "0,00"
        lblSubTotal.Text = CStr(Printer.Cupom.SubTotal.ToString("c"))
        lblTotalVenda.Text = "R$" & "0,00"
        lblCaixaLivre.Text = "CAIXA ABERTO"
        lblMenuSangria.Enabled = False
        lblMenuAdministrativoTEF.Enabled = False
        lblMenuSuprimento.Enabled = False
        lblMenuSair.Enabled = False

    End Sub
    Private Sub lblMenuIniciarVenda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblMenuIniciarVenda.Click
        abrirCupom()
    End Sub


    Private Sub lblMenuCancelarItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblMenuCancelarItem.Click
        cancelaItem()
    End Sub

    Private Sub lblMenuCancelarVenda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblMenuCancelarVenda.Click
        cancelaCupom()
    End Sub

    Private Sub lblMenuFecharVenda_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblMenuFecharVenda.Click
        iniciaFechamento()
    End Sub

    Private Sub lblMenuSair_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblMenuSair.Click
        sair()
    End Sub

    Private Sub abrirCaixa()
        Dim abrir As Sangria_Suplimento
        abrir = New Sangria_Suplimento(Me, Printer)
        abrir.Show()
    End Sub
    Private Sub fecharCaixa()
        Dim fecha As Sangria_Suplimento
        fecha = New Sangria_Suplimento(Me, Printer)
        fecha.Tag = "FECHAMENTO"
        fecha.Show()
    End Sub
    Private Sub lblMenuAbrirCaixa_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblMenuAbrirCaixa.Click
        abrirCaixa()
    End Sub
    Private Sub lblMenuFecharCaixa_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblMenuFecharCaixa.Click
        fecharCaixa()
    End Sub
    Private Sub fazerSuprimento()
        Dim supri As Sangria_Suplimento
        supri = New Sangria_Suplimento(Me, Printer)
        supri.Tag = "SUPRIMENTO"
        supri.Show()
    End Sub
    Private Sub fazerSangria()
        Dim sangri As Sangria_Suplimento
        sangri = New Sangria_Suplimento(Me, Printer)
        sangri.Tag = "SANGRIA"
        sangri.Show()
    End Sub
    Private Sub lblMenuSuprimento_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblMenuSuprimento.Click
        fazerSuprimento()
    End Sub
    Private Sub lblMenuSangria_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblMenuSangria.Click
        fazerSangria()
    End Sub
    Private Sub sair()
        If Me.Tag = "CAIXA_ABERTO" Then
            lblMenuIniciarVenda.Visible = False
            lblMenuAlterarQtde.Visible = False
            lblMenuCancelarItem.Visible = False
            lblMenuCancelarVenda.Visible = False
            lblMenuFecharVenda.Visible = False
            lblMenuSangria.Visible = False
            lblMenuAdministrativoTEF.Visible = False
            lblMenuSuprimento.Visible = False
            lblMenuSair.Visible = False
            lblCaixaLivre.Visible = True
            grbSeparador1.Visible = False
            grbSeparador2.Visible = False
            rhtCupom.Visible = False
            imCupom.Visible = False
            imFechamento.Visible = False
            cbFormaPgto.Visible = False
            txValorPagar.Visible = False
            imDadosCupom.Visible = False
            lblTotalVenda.Visible = False
            lblSubTotal.Visible = False
            lblValorUnit.Visible = False
            txQtde.Visible = False
            txCodProd.Visible = False
            imDescricao.Visible = False
            lblDescricao.Visible = False
            lblCaixaLivre.Text = "CAIXA ABERTO"
            lblMenuFecharCaixa.Visible = True
            lblMenuAbrirCaixa.Visible = False
            lblMenuAbrirCaixa.Enabled = False
            lblMenuVendas.Enabled = False
            lblMenuVendas.Visible = True
            lblMenuFecharCaixa.Enabled = True
            lblMenuVendas.Enabled = True
            lblMenuSintegra.Visible = True
            lblMenuSintegra.Enabled = False
            lblMenuSair.Visible = True
            lblMenuSair.Text = "F10 - Sair"
            Me.Tag = "SAIR"
        ElseIf Me.Tag = "CAIXA_FECHADO" Then
            lblMenuIniciarVenda.Visible = False
            lblMenuAlterarQtde.Visible = False
            lblMenuCancelarItem.Visible = False
            lblMenuCancelarVenda.Visible = False
            lblMenuFecharVenda.Visible = False
            lblMenuSangria.Visible = False
            lblMenuAdministrativoTEF.Visible = False
            lblMenuSuprimento.Visible = False
            lblMenuSair.Visible = False
            lblCaixaLivre.Visible = True
            grbSeparador1.Visible = False
            grbSeparador2.Visible = False
            rhtCupom.Visible = False
            imCupom.Visible = False
            imFechamento.Visible = False
            cbFormaPgto.Visible = False
            txValorPagar.Visible = False
            imDadosCupom.Visible = False
            lblTotalVenda.Visible = False
            lblSubTotal.Visible = False
            lblValorUnit.Visible = False
            txQtde.Visible = False
            txCodProd.Visible = False
            imDescricao.Visible = False
            lblDescricao.Visible = False
            lblCaixaLivre.Text = "CAIXA FECHADO"
            lblMenuFecharCaixa.Visible = True
            lblMenuAbrirCaixa.Visible = True
            lblMenuAbrirCaixa.Enabled = False
            lblMenuVendas.Enabled = False
            lblMenuVendas.Visible = True
            lblMenuFecharCaixa.Enabled = False
            lblMenuAbrirCaixa.Visible = True
            lblMenuVendas.Enabled = False
            lblMenuSintegra.Visible = True
            lblMenuSintegra.Enabled = True
            lblMenuSair.Visible = True
            lblMenuSair.Text = "F10 - Sair"
            Me.Tag = "SAIR"
        Else
            Printer.GerenciamentoDados.Dispose() 'destrutor da classe sintegra
            Me.Dispose()

        End If
    End Sub

    Private Sub Principal_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyUp

        If e.Modifiers = Keys.Alt Then
            If e.KeyCode = Keys.F2 And lblMenuAbrirCaixa.Visible And lblMenuAbrirCaixa.Enabled Then
                abrirCaixa()
            ElseIf e.KeyCode = Keys.F3 And lblMenuFecharCaixa.Visible And lblMenuFecharCaixa.Enabled Then
                fecharCaixa()
            ElseIf e.KeyCode = Keys.F5 And lblMenuVendas.Visible And lblMenuVendas.Enabled Then
                montarAparenciaCaixaAberto()
            ElseIf e.KeyCode = Keys.F7 And lblMenuSintegra.Visible And lblMenuSintegra.Enabled Then
                lblCaixaLivre.Visible = False
                pnlSintegra.Visible = True
                dtInicial.Value = DateTime.Now
                dtFinal.Value = DateTime.Now
            ElseIf e.KeyCode = Keys.F8 And lblRelatorios.Visible And lblRelatorios.Enabled Then
                lblCaixaLivre.Visible = False
                pnlSintegra.Visible = False
                pnlRelatorios.Visible = True
            End If

        Else
            If e.KeyCode = Keys.F2 And lblMenuIniciarVenda.Visible And lblMenuIniciarVenda.Enabled Then
                abrirCupom()
            ElseIf e.KeyCode = Keys.F3 And lblMenuAlterarQtde.Visible And lblMenuAlterarQtde.Enabled Then
                txQtde.Focus()
            ElseIf e.KeyCode = Keys.F4 And lblMenuCancelarItem.Visible And lblMenuCancelarItem.Enabled Then
                cancelaItem()
            ElseIf e.KeyCode = Keys.F5 And lblMenuFecharVenda.Visible And lblMenuFecharVenda.Enabled Then
                iniciaFechamento()
            ElseIf e.KeyCode = Keys.F6 And lblMenuCancelarVenda.Visible And lblMenuCancelarVenda.Enabled Then
                cancelaCupom()

            ElseIf e.KeyCode = Keys.F7 And lblMenuAdministrativoTEF.Visible And lblMenuAdministrativoTEF.Enabled Then
                ' F7 - Administrativo TEF
                Dim adm As frmAdministrativo = New frmAdministrativo
                If adm.ShowDialog(Me) = DialogResult.OK Then
                    Cursor = Cursors.WaitCursor
                    Application.DoEvents()
                    AdministrativoTEF(adm.cboRede.Text)
                    Cursor = Cursors.Default
                End If
                adm.Dispose()

            ElseIf e.KeyCode = Keys.F8 And lblMenuSuprimento.Visible And lblMenuSuprimento.Enabled Then
                fazerSuprimento()
            ElseIf e.KeyCode = Keys.F9 And lblMenuSangria.Visible And lblMenuSangria.Enabled Then
                fazerSangria()
            ElseIf e.KeyCode = Keys.F10 And lblMenuSair.Visible And lblMenuSair.Enabled Then
                sair()
            End If
        End If
    End Sub

    Private Sub cbFormaPgto_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cbFormaPgto.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            txValorPagar.Focus()
        End If
    End Sub
    Private Sub LimparControles()
        rhtCupom.Clear()
        txCodProd.Text = ""
        txQtde.Text = "1"
        txValorPagar.Text = "0,00"
        lblDescricao.Text = ""
        lblTotalVenda.Text = "0,00"
        lblSubTotal.Text = "0,00"
        lblValorUnit.Text = "0,00"
        txCodProd.Focus()
    End Sub

    Private Sub btnGerarRegistros_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGerarRegistros.Click


        Dim temp As New System.Data.OleDb.OleDbDataAdapter
        Dim relatSintegra As New RelatorioSintegra

        relatSintegra.CulturaInfo = Printer.GerenciamentoDados.CulturaInfo
        Dim myDataSet As DataSetRelatorios
        myDataSet = relatSintegra.GerarDataSetSintegra(Printer.GerenciamentoDados.Conexao, dtInicial.Value, dtFinal.Value, temp)
        'myDataSet = relatSintegra.GerarDataSetSintegra(Printer.GerenciamentoDados, dtInicial.Value, dtFinal.Value, temp)

        relatSintegra.Registro10 = New RegistroTipo10(dtFinal.Value.Year, dtFinal.Value.Month)
        relatSintegra.Registro10.Cidade = "Curitiba"
        relatSintegra.Registro10.CNPJ = "82373077000171"
        relatSintegra.Registro10.InscricaoEstadual = "1018146530"
        relatSintegra.Registro10.RazaoSocial = "Bematech S.A"
        relatSintegra.Registro10.Estado = UnidadeFederacao.PR

        relatSintegra.Registro11.Contato = "Fulano"
        relatSintegra.Registro11.Logradouro = "Estrada de Santa Candida"
        relatSintegra.Registro11.Numero = "263"
        relatSintegra.Registro11.CEP = "82630490"
        relatSintegra.Registro11.Telefone = "33512700"


        If (relatSintegra.Gerar(myDataSet, "sintegra.txt")) Then

            Me.txtSintegra.Clear()
            Dim sr As New StreamReader("Sintegra.txt")
            Me.txtSintegra.Text = sr.ReadToEnd()
            sr.Close()
        Else
            For Each erro As String In relatSintegra.ListaErros
                txtSintegra.Text = txtSintegra.Text + erro + vbNewLine
            Next
        End If

        'Dim daAdapter As OleDbDataAdapter = New OleDbDataAdapter
        'Dim relatSintegra As RelatorioSintegra = New RelatorioSintegra
        'Dim dsDataSet As DataSetRelatorios


        'Printer.Sintegra.GerarDataSetSintegra(dsDataSet, dtInicial.Value, dtFinal.Value, daAdapter)

        'relatSintegra.Registro10 = New RegistroTipo10(DateTime.Now.Month)
        'relatSintegra.Registro10.Cidade = "Curitiba"
        'relatSintegra.Registro10.CNPJ = "82373077000171"
        'relatSintegra.Registro10.InscricaoEstadual = "1018146530"
        'relatSintegra.Registro10.RazaoSocial = "Bematech S.A"
        'relatSintegra.Registro10.Estado = UnidadeFederacao.PR

        'relatSintegra.Registro11.Contato = "Fulano"
        'relatSintegra.Registro11.Logradouro = "Estrada de Santa Candida"
        'relatSintegra.Registro11.Numero = "263"
        'relatSintegra.Registro11.CEP = "82630490"
        'relatSintegra.Registro11.Telefone = "33512700"

        'If (relatSintegra.Gerar(dsDataSet, "sintegra.txt")) Then
        '    txtSintegra.Clear()
        '    Dim arquivoSintegra As StreamReader = New StreamReader("Sintegra.txt")
        '    txtSintegra.Text = arquivoSintegra.ReadToEnd()
        '    arquivoSintegra.Close()
        'Else
        '    txtSintegra.Text = ""
        '    For Each erro As String In relatSintegra.ListaErros
        '        txtSintegra.Text = txtSintegra.Text + erro + vbNewLine
        '    Next
        'End If
    End Sub

    Private Sub btnVoltar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnVoltar.Click
        pnlSintegra.Visible = False
        lblCaixaLivre.Visible = True
    End Sub

    Private Sub CancelarCupom()
        Try
            If Printer.Cupom.Status.Aberto Then
                Printer.Cupom.Cancelar()
                montarAparenciaCaixaAberto()
            End If

        Catch erro As Exception

            Throw erro
        End Try
    End Sub

#Region "Fun��es TEF"

    '
    'Imprime as transa��es TEF.
    '
    Private Sub ImprimirTEF()
        If (ImprimirComprovantes(False)) Then
            ConfirmarTransacao()            'confirma a impress�o dos comprovantses
        Else
            NaoConfirmarTransacao()         ' n�o confirma a �ltima transa��o
            CancelarTransacao()             ' cancela as transa��es confirmadas
        End If
        Printer.TEF.ClearTransacoes()       ' limpa a cole��o de transa��es aprovadas
    End Sub

    '
    ' Imprime os comprovantes das transa��es TEF.
    '
    ' Parametro:    gerencial - true se a impress�o for realizada no relat�rio gerencial
    ' Retorno:      True se as transa��es forem impressas com sucesso.
    '
    Private Function ImprimirComprovantes(ByVal gerencial As Boolean) As Boolean
        'printer.TEF.CorteParcialEntreComprovantes = false;
        Printer.TEF.TimeoutEntreComprovantes = 2
        Printer.TEF.TravarTeclado(True)

        Dim impressao As frmImpressaoTEF = New frmImpressaoTEF
        impressao.lblMensagem.Text = Printer.TEF.Transacoes(0).TextoOperador
        impressao.Show()
        Application.DoEvents()

        For i As Integer = 0 To Printer.TEF.Transacoes.Count - 1 Step 0
            Try
                impressao.lblMensagem.Text = Printer.TEF.Transacoes(i).TextoOperador
                Printer.TEF.Imprimir(Printer.TEF.Transacoes(i), gerencial)
                i = i + 1
            Catch
                Printer.TEF.TravarTeclado(False)
                If MessageBox.Show("Impressora n�o responde. Tentar imprimir novamente?", "PDV-VB.NET", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1) = DialogResult.Yes Then
                    Application.DoEvents()
                    gerencial = True
                    i = 0
                    Printer.TEF.TravarTeclado(True)
                Else
                    impressao.Dispose()
                    Application.DoEvents()
                    ImprimirComprovantes = False
                    Exit Function
                End If
            End Try
        Next
        Printer.TEF.TravarTeclado(False)
        impressao.Dispose()
        ImprimirComprovantes = True
    End Function

    '
    ' Imprime e confirma o cancelamento de uma transa��o TEF
    '
    ' parametro:    transacaoCancelamento - Transa��o de cancelamento a ser impressa
    ' retorno:      True se cancelamento ok, false se cancelamento n�o ok
    ' observa��es:  Se houver algum erro (impressora desligada, gerenciador inativo)
    '               fica em loop at� que o cancelamento seja conclu�do com sucesso
    '
    Private Function ImprimirCancelamento(ByVal transacaoCancelamento As Transacao) As Boolean
        'printer.TEF.CorteParcialEntreComprovantes = false;
        Printer.TEF.TimeoutEntreComprovantes = 2
        Printer.TEF.TravarTeclado(True)

        Dim impressao As frmImpressaoTEF = New frmImpressaoTEF
        impressao.lblMensagem.Text = transacaoCancelamento.TextoOperador
        impressao.Show()
        Application.DoEvents()
        While True
            Try
                Printer.TEF.Imprimir(transacaoCancelamento, True)
                ConfirmarTransacao()
                Printer.TEF.TravarTeclado(False)
                impressao.Dispose()
                Exit While

            Catch
                Printer.TEF.TravarTeclado(False)
                If MessageBox.Show("Impressora n�o responde. Tentar imprimir novamente?", "PDV-VB.NET", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1) = DialogResult.No Then
                    impressao.Dispose()
                    NaoConfirmarTransacao()
                    ImprimirCancelamento = False
                    Exit Function
                End If
            End Try
        End While
        ImprimirCancelamento = True
    End Function

    '
    ' N�o confirma a �ltima transa��o enviando um NCN.
    '
    ' Observa��es:  Se o gerenciador padr�o estiver inativo, fica em loop at� 
    '               que o mesmo seja ativado.
    '
    Private Sub NaoConfirmarTransacao()
        While True
            Try
                Dim NCN As SolicitacaoNaoConfirmacao = Printer.TEF.CriarSolicitacaoNaoConfirmacao()
                Dim mensagem As String = Printer.TEF.NaoConfirmarTransacao(NCN)
                Dim formOperador As frmOperador = New frmOperador(mensagem)
                formOperador.ShowDialog()
                Exit While

            Catch ex As GerenciadorInativoException
                MessageBox.Show("Gerenciador Padr�o n�o est� ativo!", "Gerenciador Inativo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Catch erro As TEFException
                MessageBox.Show(erro.Message, "PDV-VB.NET", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End Try
        End While
    End Sub

    '
    ' Confirma a �ltima transa��o aprovada.
    '
    ' Observa��es:  Se o gerenciador padr�o estiver inativo, fica em loop at� 
    '               que o mesmo seja ativado.
    '
    Private Sub ConfirmarTransacao()
        Dim CNF As SolicitacaoConfirmacao = Printer.TEF.CriarSolicitacaoConfirmacao()
        While True
            Try
                Printer.TEF.ConfirmarTransacao(CNF)
                Exit While

            Catch erro As GerenciadorInativoException

                MessageBox.Show(erro.Message, "PDV-VB.NET", MessageBoxButtons.OK, MessageBoxIcon.Information)

            Catch erro As Exception

                MessageBox.Show(erro.Message, "PDV-VB.NET", MessageBoxButtons.OK, MessageBoxIcon.Error)

                Application.DoEvents()
            End Try
        End While
    End Sub

    '
    ' Cancela todas as transa��es confirmadas. Se houver algum erro 
    ' fica em loop at� que todas as transa��es sejam canceladas.
    '
    ' Observa��es:  Se a transa��o a ser cancelada for uma consulta
    '               de cheque ou consulta CDC envia um NCN, pois n�o h�
    '               cancelamento (CNC) para consulta
    '
    Private Sub CancelarTransacao()
        Dim formOperador As frmOperador

        For i As Integer = Printer.TEF.Transacoes.Count - 1 To 0 Step -1
            If Printer.TEF.Transacoes(i).Tipo = CONSULTA_CDC Or _
                Printer.TEF.Transacoes(i).Tipo = CONSULTA_CHEQUE Then
                NaoConfirmarTransacao()

            Else
                Dim cancelamentoOk As Boolean = False

                While Not cancelamentoOk
                    Try
                        Dim CNC As SolicitacaoCancelamento = Printer.TEF.CriarSolicitacaoCancelamento(Printer.TEF.Transacoes(i))
                        Dim cancelamento As Transacao = Printer.TEF.CancelarTransacao(CNC)

                        If cancelamento.Status = TRANSACAO_APROVADA Then
                            ' imprime e confirma o cancelamento
                            ' se houver erro durante a impress�o envia o NCN
                            cancelamentoOk = ImprimirCancelamento(cancelamento)

                        Else ' cancelamento n�o aprovado

                            formOperador = New frmOperador(cancelamento.TextoOperador)
                            formOperador.ShowDialog()
                            formOperador.Dispose()
                        End If

                    Catch erro As GerenciadorInativoException
                        formOperador = New frmOperador(erro.Message)
                        formOperador.ShowDialog()
                        formOperador.Dispose()

                    Catch erro As Exception
                        formOperador = New frmOperador(erro.Message)
                        formOperador.ShowDialog()
                        formOperador.Dispose()
                    End Try
                End While
            End If
        Next
    End Sub

    '
    ' Cancela as transa��es TEF que n�o foram impressas
    '
    Private Sub CancelarTransacaoTEFPendente()
        'verifica se tem transa��o TEF n�o confirmada se tiver envia 
        'uma n�o confirma��o
        If Printer.TEF.TransacaoNaoConfirmada Then
            NaoConfirmarTransacao()
        End If

        'verifica se tem transa��o TEF confirmada, se tiver, cancela.
        If Printer.TEF.Transacoes.Count > 0 Then
            CancelarTransacao()
        End If
    End Sub

    '
    ' Inicia o m�dulo administrativo e imprime os comprovantes se houverem
    '
    Private Sub AdministrativoTEF(ByVal rede As String)
        If rede = "TECBAN" Then

            Printer.TEF.PathSolicitacao = "C:\TEF_DISC\REQ"
            Printer.TEF.PathResposta = "C:\TEF_DISC\RESP"

        Else

            Printer.TEF.PathSolicitacao = "C:\TEF_DIAL\REQ"
            Printer.TEF.PathResposta = "C:\TEF_DIAL\RESP"

            Try
                Dim solicitacao As SolicitacaoAdministrativa = Printer.TEF.CriarSolicitacaoAdministrativa()
                Dim transacao As transacao = Printer.TEF.EnviarSolicitacao(solicitacao)
                If transacao.Status = TRANSACAO_APROVADA And CInt(transacao.QuantidadeLinhas) > 0 Then

                    While (True)
                        If ImprimirComprovantes(True) Then
                            ConfirmarTransacao()
                            Printer.TEF.ClearTransacoes()
                            Exit While

                        Else

                            NaoConfirmarTransacao()
                            CancelarTransacao()
                            Exit While
                        End If
                    End While

                Else
                    Dim formOperador As frmOperador = New frmOperador(transacao.TextoOperador)
                    formOperador.ShowDialog()
                    formOperador.Dispose()
                End If

            Catch erro As GerenciadorInativoException
                Dim formOperador As frmOperador = New frmOperador(erro.Message)
                formOperador.ShowDialog()
                formOperador.Dispose()

            Catch erro As Exception
                Dim formOperador As frmOperador = New frmOperador(erro.Message)
                formOperador.ShowDialog()
                formOperador.Dispose()
            End Try
        End If
    End Sub

#End Region

   
    Private Sub btnGerarRelatGerenc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGerarRelatGerenc.Click
        If grbRelatorios.Visible Then
            Try

                '//GerenciadorDados manager = printer.Sintegra;			
                Dim dadosRelatorios As New GerenciadorDados(conexaoBanco)

                '// cultura usada porque est� sendo utilizado o access
                Dim myCultura As New CultureInfo(CultureInfo.CurrentCulture.LCID, False)
                myCultura.NumberFormat.NumberDecimalSeparator = "."
                myCultura.DateTimeFormat.ShortDatePattern = "#MM/dd/yyyy#"
                myCultura.DateTimeFormat.LongTimePattern = ""
                dadosRelatorios.CulturaInfo = myCultura ' // no sqlserver N�o deve usar essa cultura
                If Not dadosRelatorios Is Nothing Then
                    Dim daRelatorios As New OleDbDataAdapter
                    Dim dsRelatorios As DataSetRelatorios

                    '	//dadosRelatorios.Conexao .GerarDataSetRelatorio(dsRelatorios, dtInicial.Value, dtFinal.Value, daRelatorios);
                    Dim geradorRelatorios As New GeradorRelatorio
                    geradorRelatorios.CulturaInfo = myCultura
                    dsRelatorios = geradorRelatorios.GerarDataSetRelatorio(dadosRelatorios.Conexao, dtInicialRelatorio.Value, dtFinalRelatorio.Value, daRelatorios)
                    Dim relatorio As RelatorioAdministrativo
                    If (rbtListaProdutos.Checked) Then
                        relatorio = geradorRelatorios.ListaDeProdutos(dsRelatorios, True)
                    ElseIf (rbtVendasPorCliente.Checked) Then
                        relatorio = geradorRelatorios.VendasPorCliente(dsRelatorios, True)
                    ElseIf (Me.rbtVendasPorProduto.Checked) Then
                        relatorio = geradorRelatorios.VendasPorProduto(dsRelatorios, True)
                    ElseIf (rbtVendasPorVendedor.Checked) Then
                        relatorio = geradorRelatorios.VendasPorVendedor(dsRelatorios, True)
                    ElseIf (rbtVendasPorECF.Checked) Then
                        relatorio = geradorRelatorios.VendasPorECF(dsRelatorios, True)
                    ElseIf (rbtListaClientes.Checked) Then
                        relatorio = geradorRelatorios.ListaDeClientes(dsRelatorios, True)
                    ElseIf (rbtListaVendedores.Checked) Then
                        relatorio = geradorRelatorios.ListaDeVendedores(dsRelatorios, True)
                    ElseIf (rbtTotalAliquota.Checked) Then
                        relatorio = geradorRelatorios.VendasPorAliquota(dsRelatorios)
                    Else
                        relatorio = geradorRelatorios.VendasPorPeriodo(dsRelatorios, dtInicialRelatorio.Value, dtFinalRelatorio.Value, True)
                    End If
                    If Not relatorio.Documento Is Nothing Then
                        PrintPreviewDialog1.Document = relatorio.Documento
                        PrintPreviewDialog1.Bounds = New Rectangle(0, 0, 800, 600) ' 800x600
                        PrintPreviewDialog1.ShowDialog()
                    End If
                End If
            Catch erro As Exception

                MessageBox.Show(erro.Message)
            End Try

        End If
    End Sub

    Private Sub btnVoltarRelatGerenc_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnVoltarRelatGerenc.Click
        pnlRelatorios.Visible = False
        lblCaixaLivre.Visible = True
    End Sub
End Class
