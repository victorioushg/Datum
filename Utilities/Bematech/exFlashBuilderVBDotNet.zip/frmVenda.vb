Imports Bematech.FiscalPrinter  'assembly com as declara��es das fun��es da dll bemafi32
Imports System.IO               'assembly com fun��es para acesso a arquivo texto

Public Class frmVenda
    Inherits System.Windows.Forms.Form

    Private ValorRecebido As Decimal    'valor recebido na venda
    Private SubTotal As Decimal         'armazena o subtotal da venda no cupom fiscal
    Private RetECF As Integer           'retorno das fun��es do ECF
    Private NumeroItem As Integer       'n�mero sequencial do item no cupom
    Private Cupom As New CupomFiscal    'criando um objeto cupom da classe cupomfiscal

    Private TEF As New BemaTEF          'classe para realizar o TEF

    Private Enum LayoutVenda    'Indica o layout a ser exibido no momento da venda
        CaixaLivre
        InicioVenda
        FechamentoVenda
    End Enum

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents txtValorProduto As System.Windows.Forms.TextBox
    Friend WithEvents txtDescProduto As System.Windows.Forms.TextBox
    Friend WithEvents txtCodProduto As System.Windows.Forms.TextBox
    Friend WithEvents txtSubTotal As System.Windows.Forms.TextBox
    Friend WithEvents DaProdutos As System.Data.OleDb.OleDbDataAdapter
    Friend WithEvents OleDbSelectCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbInsertCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbUpdateCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbDeleteCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents cnProdutos As System.Data.OleDb.OleDbConnection
    Friend WithEvents DsProdutos As TEF_VBNET.DsProdutos
    Friend WithEvents txtTotalItem As System.Windows.Forms.TextBox
    Friend WithEvents txtQtdProduto As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents lblProduto As System.Windows.Forms.Label
    Friend WithEvents lblQtd As System.Windows.Forms.Label
    Friend WithEvents lblValor As System.Windows.Forms.Label
    Friend WithEvents lblSubTotal As System.Windows.Forms.Label
    Friend WithEvents lblTotalItem As System.Windows.Forms.Label
    Friend WithEvents lblFormaPagamento As System.Windows.Forms.Label
    Friend WithEvents cboFormaPagamento As System.Windows.Forms.ComboBox
    Friend WithEvents rtbCupomFiscal As System.Windows.Forms.RichTextBox
    Friend WithEvents lblCupomFiscal As System.Windows.Forms.Label
    Friend WithEvents btnIniciarVenda As System.Windows.Forms.Button
    Friend WithEvents btnFecharVenda As System.Windows.Forms.Button
    Friend WithEvents btnCancelarVenda As System.Windows.Forms.Button
    Friend WithEvents btnSair As System.Windows.Forms.Button
    Friend WithEvents btnAlterarQtd As System.Windows.Forms.Button
    Friend WithEvents pnlCaixaLivre As System.Windows.Forms.Panel
    Friend WithEvents lblCaixaLivre As System.Windows.Forms.Label
    Friend WithEvents btnFuncoesAdm As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmVenda))
        Me.lblProduto = New System.Windows.Forms.Label
        Me.lblQtd = New System.Windows.Forms.Label
        Me.txtValorProduto = New System.Windows.Forms.TextBox
        Me.txtDescProduto = New System.Windows.Forms.TextBox
        Me.lblValor = New System.Windows.Forms.Label
        Me.rtbCupomFiscal = New System.Windows.Forms.RichTextBox
        Me.txtCodProduto = New System.Windows.Forms.TextBox
        Me.lblSubTotal = New System.Windows.Forms.Label
        Me.txtSubTotal = New System.Windows.Forms.TextBox
        Me.txtTotalItem = New System.Windows.Forms.TextBox
        Me.lblTotalItem = New System.Windows.Forms.Label
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.lblCupomFiscal = New System.Windows.Forms.Label
        Me.DaProdutos = New System.Data.OleDb.OleDbDataAdapter
        Me.OleDbDeleteCommand1 = New System.Data.OleDb.OleDbCommand
        Me.cnProdutos = New System.Data.OleDb.OleDbConnection
        Me.OleDbInsertCommand1 = New System.Data.OleDb.OleDbCommand
        Me.OleDbSelectCommand1 = New System.Data.OleDb.OleDbCommand
        Me.OleDbUpdateCommand1 = New System.Data.OleDb.OleDbCommand
        Me.DsProdutos = New TEF_VBNET.DsProdutos
        Me.txtQtdProduto = New System.Windows.Forms.TextBox
        Me.btnIniciarVenda = New System.Windows.Forms.Button
        Me.btnFecharVenda = New System.Windows.Forms.Button
        Me.btnCancelarVenda = New System.Windows.Forms.Button
        Me.btnSair = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.cboFormaPagamento = New System.Windows.Forms.ComboBox
        Me.lblFormaPagamento = New System.Windows.Forms.Label
        Me.btnAlterarQtd = New System.Windows.Forms.Button
        Me.pnlCaixaLivre = New System.Windows.Forms.Panel
        Me.lblCaixaLivre = New System.Windows.Forms.Label
        Me.btnFuncoesAdm = New System.Windows.Forms.Button
        CType(Me.DsProdutos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlCaixaLivre.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblProduto
        '
        Me.lblProduto.AutoSize = True
        Me.lblProduto.BackColor = System.Drawing.Color.Transparent
        Me.lblProduto.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProduto.ForeColor = System.Drawing.Color.White
        Me.lblProduto.Location = New System.Drawing.Point(8, 400)
        Me.lblProduto.Name = "lblProduto"
        Me.lblProduto.Size = New System.Drawing.Size(75, 22)
        Me.lblProduto.TabIndex = 0
        Me.lblProduto.Text = "Produto"
        Me.lblProduto.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'lblQtd
        '
        Me.lblQtd.AutoSize = True
        Me.lblQtd.BackColor = System.Drawing.Color.Transparent
        Me.lblQtd.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQtd.ForeColor = System.Drawing.Color.White
        Me.lblQtd.Location = New System.Drawing.Point(8, 160)
        Me.lblQtd.Name = "lblQtd"
        Me.lblQtd.Size = New System.Drawing.Size(36, 22)
        Me.lblQtd.TabIndex = 4
        Me.lblQtd.Text = "Qtd"
        '
        'txtValorProduto
        '
        Me.txtValorProduto.BackColor = System.Drawing.Color.FromArgb(CType(216, Byte), CType(228, Byte), CType(248, Byte))
        Me.txtValorProduto.Font = New System.Drawing.Font("Verdana", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtValorProduto.ForeColor = System.Drawing.Color.FromArgb(CType(0, Byte), CType(0, Byte), CType(192, Byte))
        Me.txtValorProduto.Location = New System.Drawing.Point(8, 184)
        Me.txtValorProduto.Name = "txtValorProduto"
        Me.txtValorProduto.Size = New System.Drawing.Size(264, 43)
        Me.txtValorProduto.TabIndex = 7
        Me.txtValorProduto.TabStop = False
        Me.txtValorProduto.Text = "0,00"
        Me.txtValorProduto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtDescProduto
        '
        Me.txtDescProduto.BackColor = System.Drawing.Color.FromArgb(CType(216, Byte), CType(228, Byte), CType(248, Byte))
        Me.txtDescProduto.Font = New System.Drawing.Font("Verdana", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDescProduto.ForeColor = System.Drawing.Color.FromArgb(CType(0, Byte), CType(0, Byte), CType(192, Byte))
        Me.txtDescProduto.Location = New System.Drawing.Point(8, 424)
        Me.txtDescProduto.Name = "txtDescProduto"
        Me.txtDescProduto.Size = New System.Drawing.Size(752, 43)
        Me.txtDescProduto.TabIndex = 3
        Me.txtDescProduto.TabStop = False
        Me.txtDescProduto.Text = "Descri��o do Produto"
        '
        'lblValor
        '
        Me.lblValor.AutoSize = True
        Me.lblValor.BackColor = System.Drawing.Color.Transparent
        Me.lblValor.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblValor.ForeColor = System.Drawing.Color.White
        Me.lblValor.Location = New System.Drawing.Point(192, 160)
        Me.lblValor.Name = "lblValor"
        Me.lblValor.Size = New System.Drawing.Size(80, 22)
        Me.lblValor.TabIndex = 6
        Me.lblValor.Text = "Valor R$"
        '
        'rtbCupomFiscal
        '
        Me.rtbCupomFiscal.BackColor = System.Drawing.Color.FromArgb(CType(216, Byte), CType(228, Byte), CType(248, Byte))
        Me.rtbCupomFiscal.Font = New System.Drawing.Font("Courier New", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtbCupomFiscal.ForeColor = System.Drawing.Color.FromArgb(CType(0, Byte), CType(0, Byte), CType(192, Byte))
        Me.rtbCupomFiscal.Location = New System.Drawing.Point(288, 128)
        Me.rtbCupomFiscal.Name = "rtbCupomFiscal"
        Me.rtbCupomFiscal.Size = New System.Drawing.Size(472, 288)
        Me.rtbCupomFiscal.TabIndex = 13
        Me.rtbCupomFiscal.TabStop = False
        Me.rtbCupomFiscal.Text = ""
        '
        'txtCodProduto
        '
        Me.txtCodProduto.BackColor = System.Drawing.Color.FromArgb(CType(78, Byte), CType(107, Byte), CType(177, Byte))
        Me.txtCodProduto.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtCodProduto.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCodProduto.ForeColor = System.Drawing.Color.White
        Me.txtCodProduto.Location = New System.Drawing.Point(88, 400)
        Me.txtCodProduto.MaxLength = 13
        Me.txtCodProduto.Name = "txtCodProduto"
        Me.txtCodProduto.Size = New System.Drawing.Size(168, 20)
        Me.txtCodProduto.TabIndex = 1
        Me.txtCodProduto.Text = "1234567890123"
        '
        'lblSubTotal
        '
        Me.lblSubTotal.AutoSize = True
        Me.lblSubTotal.BackColor = System.Drawing.Color.Transparent
        Me.lblSubTotal.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubTotal.ForeColor = System.Drawing.Color.White
        Me.lblSubTotal.Location = New System.Drawing.Point(8, 320)
        Me.lblSubTotal.Name = "lblSubTotal"
        Me.lblSubTotal.Size = New System.Drawing.Size(82, 22)
        Me.lblSubTotal.TabIndex = 10
        Me.lblSubTotal.Text = "SubTotal"
        '
        'txtSubTotal
        '
        Me.txtSubTotal.BackColor = System.Drawing.Color.FromArgb(CType(216, Byte), CType(228, Byte), CType(248, Byte))
        Me.txtSubTotal.Font = New System.Drawing.Font("Verdana", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSubTotal.ForeColor = System.Drawing.Color.FromArgb(CType(0, Byte), CType(0, Byte), CType(192, Byte))
        Me.txtSubTotal.Location = New System.Drawing.Point(8, 344)
        Me.txtSubTotal.Name = "txtSubTotal"
        Me.txtSubTotal.Size = New System.Drawing.Size(264, 43)
        Me.txtSubTotal.TabIndex = 11
        Me.txtSubTotal.TabStop = False
        Me.txtSubTotal.Text = "0,00"
        Me.txtSubTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtTotalItem
        '
        Me.txtTotalItem.BackColor = System.Drawing.Color.FromArgb(CType(216, Byte), CType(228, Byte), CType(248, Byte))
        Me.txtTotalItem.Font = New System.Drawing.Font("Verdana", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalItem.ForeColor = System.Drawing.Color.FromArgb(CType(0, Byte), CType(0, Byte), CType(192, Byte))
        Me.txtTotalItem.Location = New System.Drawing.Point(8, 264)
        Me.txtTotalItem.MaxLength = 0
        Me.txtTotalItem.Name = "txtTotalItem"
        Me.txtTotalItem.Size = New System.Drawing.Size(264, 43)
        Me.txtTotalItem.TabIndex = 9
        Me.txtTotalItem.TabStop = False
        Me.txtTotalItem.Text = "0,00"
        Me.txtTotalItem.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblTotalItem
        '
        Me.lblTotalItem.AutoSize = True
        Me.lblTotalItem.BackColor = System.Drawing.Color.Transparent
        Me.lblTotalItem.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalItem.ForeColor = System.Drawing.Color.White
        Me.lblTotalItem.Location = New System.Drawing.Point(8, 240)
        Me.lblTotalItem.Name = "lblTotalItem"
        Me.lblTotalItem.Size = New System.Drawing.Size(123, 22)
        Me.lblTotalItem.TabIndex = 8
        Me.lblTotalItem.Text = "Total do Item"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(776, 88)
        Me.PictureBox1.TabIndex = 16
        Me.PictureBox1.TabStop = False
        '
        'lblCupomFiscal
        '
        Me.lblCupomFiscal.AutoSize = True
        Me.lblCupomFiscal.BackColor = System.Drawing.Color.Transparent
        Me.lblCupomFiscal.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCupomFiscal.ForeColor = System.Drawing.Color.White
        Me.lblCupomFiscal.Location = New System.Drawing.Point(448, 104)
        Me.lblCupomFiscal.Name = "lblCupomFiscal"
        Me.lblCupomFiscal.Size = New System.Drawing.Size(120, 22)
        Me.lblCupomFiscal.TabIndex = 12
        Me.lblCupomFiscal.Text = "Cupom Fiscal"
        '
        'DaProdutos
        '
        Me.DaProdutos.DeleteCommand = Me.OleDbDeleteCommand1
        Me.DaProdutos.InsertCommand = Me.OleDbInsertCommand1
        Me.DaProdutos.SelectCommand = Me.OleDbSelectCommand1
        Me.DaProdutos.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Produto", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("Aliquota", "Aliquota"), New System.Data.Common.DataColumnMapping("Codigo", "Codigo"), New System.Data.Common.DataColumnMapping("Descricao", "Descricao"), New System.Data.Common.DataColumnMapping("Estoque", "Estoque"), New System.Data.Common.DataColumnMapping("Preco", "Preco")})})
        Me.DaProdutos.UpdateCommand = Me.OleDbUpdateCommand1
        '
        'OleDbDeleteCommand1
        '
        Me.OleDbDeleteCommand1.CommandText = "DELETE FROM Produto WHERE (Codigo = ?) AND (Aliquota = ? OR ? IS NULL AND Aliquot" & _
        "a IS NULL) AND (Descricao = ? OR ? IS NULL AND Descricao IS NULL) AND (Estoque =" & _
        " ? OR ? IS NULL AND Estoque IS NULL) AND (Preco = ? OR ? IS NULL AND Preco IS NU" & _
        "LL)"
        Me.OleDbDeleteCommand1.Connection = Me.cnProdutos
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Codigo", System.Data.OleDb.OleDbType.VarWChar, 13, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Codigo", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Aliquota", System.Data.OleDb.OleDbType.VarWChar, 2, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Aliquota", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Aliquota1", System.Data.OleDb.OleDbType.VarWChar, 2, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Aliquota", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Descricao", System.Data.OleDb.OleDbType.VarWChar, 29, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Descricao", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Descricao1", System.Data.OleDb.OleDbType.VarWChar, 29, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Descricao", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Estoque", System.Data.OleDb.OleDbType.Decimal, 0, System.Data.ParameterDirection.Input, False, CType(18, Byte), CType(3, Byte), "Estoque", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Estoque1", System.Data.OleDb.OleDbType.Decimal, 0, System.Data.ParameterDirection.Input, False, CType(18, Byte), CType(3, Byte), "Estoque", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Preco", System.Data.OleDb.OleDbType.Currency, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Preco", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Preco1", System.Data.OleDb.OleDbType.Currency, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Preco", System.Data.DataRowVersion.Original, Nothing))
        '
        'cnProdutos
        '
        Me.cnProdutos.ConnectionString = "Jet OLEDB:Global Partial Bulk Ops=2;Jet OLEDB:Registry Path=;Jet OLEDB:Database L" & _
        "ocking Mode=1;Data Source=""D:\Projetos\Condex 2004\TEF_VBNET\Produtos.mdb"";Mode=" & _
        "Share Deny None;Jet OLEDB:Engine Type=5;Provider=""Microsoft.Jet.OLEDB.4.0"";Jet O" & _
        "LEDB:System database=;Jet OLEDB:SFP=False;persist security info=False;Extended P" & _
        "roperties=;Jet OLEDB:Compact Without Replica Repair=False;Jet OLEDB:Encrypt Data" & _
        "base=False;Jet OLEDB:Create System Database=False;Jet OLEDB:Don't Copy Locale on" & _
        " Compact=False;User ID=Admin;Jet OLEDB:Global Bulk Transactions=1"
        '
        'OleDbInsertCommand1
        '
        Me.OleDbInsertCommand1.CommandText = "INSERT INTO Produto(Aliquota, Codigo, Descricao, Estoque, Preco) VALUES (?, ?, ?," & _
        " ?, ?)"
        Me.OleDbInsertCommand1.Connection = Me.cnProdutos
        Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Aliquota", System.Data.OleDb.OleDbType.VarWChar, 2, "Aliquota"))
        Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Codigo", System.Data.OleDb.OleDbType.VarWChar, 13, "Codigo"))
        Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Descricao", System.Data.OleDb.OleDbType.VarWChar, 29, "Descricao"))
        Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Estoque", System.Data.OleDb.OleDbType.Decimal, 0, System.Data.ParameterDirection.Input, False, CType(18, Byte), CType(3, Byte), "Estoque", System.Data.DataRowVersion.Current, Nothing))
        Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Preco", System.Data.OleDb.OleDbType.Currency, 0, "Preco"))
        '
        'OleDbSelectCommand1
        '
        Me.OleDbSelectCommand1.CommandText = "SELECT Aliquota, Codigo, Descricao, Estoque, Preco FROM Produto"
        Me.OleDbSelectCommand1.Connection = Me.cnProdutos
        '
        'OleDbUpdateCommand1
        '
        Me.OleDbUpdateCommand1.CommandText = "UPDATE Produto SET Aliquota = ?, Codigo = ?, Descricao = ?, Estoque = ?, Preco = " & _
        "? WHERE (Codigo = ?) AND (Aliquota = ? OR ? IS NULL AND Aliquota IS NULL) AND (D" & _
        "escricao = ? OR ? IS NULL AND Descricao IS NULL) AND (Estoque = ? OR ? IS NULL A" & _
        "ND Estoque IS NULL) AND (Preco = ? OR ? IS NULL AND Preco IS NULL)"
        Me.OleDbUpdateCommand1.Connection = Me.cnProdutos
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Aliquota", System.Data.OleDb.OleDbType.VarWChar, 2, "Aliquota"))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Codigo", System.Data.OleDb.OleDbType.VarWChar, 13, "Codigo"))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Descricao", System.Data.OleDb.OleDbType.VarWChar, 29, "Descricao"))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Estoque", System.Data.OleDb.OleDbType.Decimal, 0, System.Data.ParameterDirection.Input, False, CType(18, Byte), CType(3, Byte), "Estoque", System.Data.DataRowVersion.Current, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Preco", System.Data.OleDb.OleDbType.Currency, 0, "Preco"))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Codigo", System.Data.OleDb.OleDbType.VarWChar, 13, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Codigo", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Aliquota", System.Data.OleDb.OleDbType.VarWChar, 2, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Aliquota", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Aliquota1", System.Data.OleDb.OleDbType.VarWChar, 2, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Aliquota", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Descricao", System.Data.OleDb.OleDbType.VarWChar, 29, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Descricao", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Descricao1", System.Data.OleDb.OleDbType.VarWChar, 29, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Descricao", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Estoque", System.Data.OleDb.OleDbType.Decimal, 0, System.Data.ParameterDirection.Input, False, CType(18, Byte), CType(3, Byte), "Estoque", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Estoque1", System.Data.OleDb.OleDbType.Decimal, 0, System.Data.ParameterDirection.Input, False, CType(18, Byte), CType(3, Byte), "Estoque", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Preco", System.Data.OleDb.OleDbType.Currency, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Preco", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Preco1", System.Data.OleDb.OleDbType.Currency, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Preco", System.Data.DataRowVersion.Original, Nothing))
        '
        'DsProdutos
        '
        Me.DsProdutos.DataSetName = "DsProdutos"
        Me.DsProdutos.Locale = New System.Globalization.CultureInfo("pt-BR")
        '
        'txtQtdProduto
        '
        Me.txtQtdProduto.BackColor = System.Drawing.Color.FromArgb(CType(216, Byte), CType(228, Byte), CType(248, Byte))
        Me.txtQtdProduto.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtQtdProduto.Font = New System.Drawing.Font("Verdana", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtQtdProduto.ForeColor = System.Drawing.Color.FromArgb(CType(0, Byte), CType(0, Byte), CType(192, Byte))
        Me.txtQtdProduto.Location = New System.Drawing.Point(10, 186)
        Me.txtQtdProduto.MaxLength = 2
        Me.txtQtdProduto.Name = "txtQtdProduto"
        Me.txtQtdProduto.Size = New System.Drawing.Size(54, 36)
        Me.txtQtdProduto.TabIndex = 17
        Me.txtQtdProduto.TabStop = False
        Me.txtQtdProduto.Text = "1"
        Me.txtQtdProduto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btnIniciarVenda
        '
        Me.btnIniciarVenda.BackColor = System.Drawing.Color.FromArgb(CType(216, Byte), CType(228, Byte), CType(248, Byte))
        Me.btnIniciarVenda.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnIniciarVenda.Location = New System.Drawing.Point(8, 544)
        Me.btnIniciarVenda.Name = "btnIniciarVenda"
        Me.btnIniciarVenda.Size = New System.Drawing.Size(112, 64)
        Me.btnIniciarVenda.TabIndex = 18
        Me.btnIniciarVenda.TabStop = False
        Me.btnIniciarVenda.Text = "Iniciar Venda (F2)"
        '
        'btnFecharVenda
        '
        Me.btnFecharVenda.BackColor = System.Drawing.Color.FromArgb(CType(216, Byte), CType(228, Byte), CType(248, Byte))
        Me.btnFecharVenda.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFecharVenda.Location = New System.Drawing.Point(120, 544)
        Me.btnFecharVenda.Name = "btnFecharVenda"
        Me.btnFecharVenda.Size = New System.Drawing.Size(112, 64)
        Me.btnFecharVenda.TabIndex = 19
        Me.btnFecharVenda.TabStop = False
        Me.btnFecharVenda.Text = "Fechar Venda (ESC)"
        '
        'btnCancelarVenda
        '
        Me.btnCancelarVenda.BackColor = System.Drawing.Color.FromArgb(CType(216, Byte), CType(228, Byte), CType(248, Byte))
        Me.btnCancelarVenda.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancelarVenda.Location = New System.Drawing.Point(232, 544)
        Me.btnCancelarVenda.Name = "btnCancelarVenda"
        Me.btnCancelarVenda.Size = New System.Drawing.Size(112, 64)
        Me.btnCancelarVenda.TabIndex = 20
        Me.btnCancelarVenda.TabStop = False
        Me.btnCancelarVenda.Text = "Cancelar Venda (F4)"
        '
        'btnSair
        '
        Me.btnSair.BackColor = System.Drawing.Color.FromArgb(CType(216, Byte), CType(228, Byte), CType(248, Byte))
        Me.btnSair.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSair.Location = New System.Drawing.Point(648, 544)
        Me.btnSair.Name = "btnSair"
        Me.btnSair.Size = New System.Drawing.Size(112, 64)
        Me.btnSair.TabIndex = 21
        Me.btnSair.TabStop = False
        Me.btnSair.Text = "Sair            (F10)"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Location = New System.Drawing.Point(8, 528)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(752, 8)
        Me.GroupBox1.TabIndex = 22
        Me.GroupBox1.TabStop = False
        '
        'cboFormaPagamento
        '
        Me.cboFormaPagamento.BackColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.cboFormaPagamento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboFormaPagamento.Font = New System.Drawing.Font("Verdana", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboFormaPagamento.ForeColor = System.Drawing.Color.FromArgb(CType(0, Byte), CType(0, Byte), CType(192, Byte))
        Me.cboFormaPagamento.Items.AddRange(New Object() {"Dinheiro", "Cart�o", "Cheque", "Ticket"})
        Me.cboFormaPagamento.Location = New System.Drawing.Point(8, 184)
        Me.cboFormaPagamento.Name = "cboFormaPagamento"
        Me.cboFormaPagamento.Size = New System.Drawing.Size(264, 43)
        Me.cboFormaPagamento.TabIndex = 24
        '
        'lblFormaPagamento
        '
        Me.lblFormaPagamento.AutoSize = True
        Me.lblFormaPagamento.BackColor = System.Drawing.Color.Transparent
        Me.lblFormaPagamento.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFormaPagamento.ForeColor = System.Drawing.Color.White
        Me.lblFormaPagamento.Location = New System.Drawing.Point(8, 160)
        Me.lblFormaPagamento.Name = "lblFormaPagamento"
        Me.lblFormaPagamento.Size = New System.Drawing.Size(190, 22)
        Me.lblFormaPagamento.TabIndex = 25
        Me.lblFormaPagamento.Text = "Forma de Pagamento"
        '
        'btnAlterarQtd
        '
        Me.btnAlterarQtd.BackColor = System.Drawing.Color.FromArgb(CType(216, Byte), CType(228, Byte), CType(248, Byte))
        Me.btnAlterarQtd.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAlterarQtd.Location = New System.Drawing.Point(8, 544)
        Me.btnAlterarQtd.Name = "btnAlterarQtd"
        Me.btnAlterarQtd.Size = New System.Drawing.Size(112, 64)
        Me.btnAlterarQtd.TabIndex = 26
        Me.btnAlterarQtd.TabStop = False
        Me.btnAlterarQtd.Text = "Alterar Qtde (F3)"
        '
        'pnlCaixaLivre
        '
        Me.pnlCaixaLivre.BackColor = System.Drawing.Color.Transparent
        Me.pnlCaixaLivre.Controls.Add(Me.lblCaixaLivre)
        Me.pnlCaixaLivre.Location = New System.Drawing.Point(0, 88)
        Me.pnlCaixaLivre.Name = "pnlCaixaLivre"
        Me.pnlCaixaLivre.Size = New System.Drawing.Size(760, 440)
        Me.pnlCaixaLivre.TabIndex = 27
        '
        'lblCaixaLivre
        '
        Me.lblCaixaLivre.AutoSize = True
        Me.lblCaixaLivre.BackColor = System.Drawing.Color.Transparent
        Me.lblCaixaLivre.Font = New System.Drawing.Font("Verdana", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCaixaLivre.ForeColor = System.Drawing.Color.White
        Me.lblCaixaLivre.Location = New System.Drawing.Point(136, 172)
        Me.lblCaixaLivre.Name = "lblCaixaLivre"
        Me.lblCaixaLivre.Size = New System.Drawing.Size(506, 81)
        Me.lblCaixaLivre.TabIndex = 24
        Me.lblCaixaLivre.Text = "CAIXA LIVRE"
        Me.lblCaixaLivre.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnFuncoesAdm
        '
        Me.btnFuncoesAdm.BackColor = System.Drawing.Color.FromArgb(CType(216, Byte), CType(228, Byte), CType(248, Byte))
        Me.btnFuncoesAdm.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFuncoesAdm.Location = New System.Drawing.Point(120, 544)
        Me.btnFuncoesAdm.Name = "btnFuncoesAdm"
        Me.btnFuncoesAdm.Size = New System.Drawing.Size(112, 64)
        Me.btnFuncoesAdm.TabIndex = 28
        Me.btnFuncoesAdm.TabStop = False
        Me.btnFuncoesAdm.Text = "Fun��es ADM (F5)"
        '
        'frmVenda
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(768, 614)
        Me.Controls.Add(Me.btnFuncoesAdm)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnSair)
        Me.Controls.Add(Me.btnCancelarVenda)
        Me.Controls.Add(Me.btnFecharVenda)
        Me.Controls.Add(Me.btnIniciarVenda)
        Me.Controls.Add(Me.txtQtdProduto)
        Me.Controls.Add(Me.lblCupomFiscal)
        Me.Controls.Add(Me.lblSubTotal)
        Me.Controls.Add(Me.txtSubTotal)
        Me.Controls.Add(Me.txtTotalItem)
        Me.Controls.Add(Me.lblTotalItem)
        Me.Controls.Add(Me.txtCodProduto)
        Me.Controls.Add(Me.lblValor)
        Me.Controls.Add(Me.txtDescProduto)
        Me.Controls.Add(Me.txtValorProduto)
        Me.Controls.Add(Me.lblQtd)
        Me.Controls.Add(Me.lblProduto)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.rtbCupomFiscal)
        Me.Controls.Add(Me.lblFormaPagamento)
        Me.Controls.Add(Me.cboFormaPagamento)
        Me.Controls.Add(Me.btnAlterarQtd)
        Me.Controls.Add(Me.pnlCaixaLivre)
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.Name = "frmVenda"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Descomplicando o TEF"
        CType(Me.DsProdutos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlCaixaLivre.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.ResizeRedraw = True

        txtCodProduto.Text = ""
        txtDescProduto.Text = ""

        'vamos usar a rotina CarregaDataset para preencher 
        'o objeto dataset com os registros retornados dos 
        'produtos
        CarregaDataset(DsProdutos)

        'Exibe o layout de caixa livre
        Call ExibeLayoutVenda(LayoutVenda.CaixaLivre)

    End Sub

     Public Sub CarregaDataset(ByVal DataSet As TEF_VBNET.DsProdutos)

        Me.cnProdutos.Open()  'abre a conexao com o banco de dados
        DataSet.EnforceConstraints = False
        Try
            Me.DaProdutos.Fill(DsProdutos) 'dispara o m�todo Fill do objeto DataAdapter

        Catch cException As System.Exception
            Throw cException

        Finally
            DataSet.EnforceConstraints = True
            Me.cnProdutos.Close()
            Me.cnProdutos = Nothing
        End Try

    End Sub

    Private Sub txtCodProduto_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtCodProduto.KeyPress

        Dim Produto As DsProdutos.ProdutoRow
        Dim TmpCodigo As String
        Dim TotalItem As Decimal
        Dim Cupom As String
        Dim i As Integer

        If e.KeyChar = ChrW(Keys.Enter) Then

            TmpCodigo = Format(CInt(Trim(txtCodProduto.Text)), "0000000000000")

            Produto = DsProdutos.Produto.FindByCodigo(TmpCodigo)
            If (Produto Is Nothing) Then
                MessageBox.Show("Produto n�o cadastrado!", "TEF_VBNET", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Me.txtCodProduto.Text = ""
                Me.txtCodProduto.Focus()
                Exit Sub

            Else
                RetECF = Bematech_FI_VendeItem(Produto.Codigo, Produto.Descricao, Produto.Aliquota, _
                                               "I", Me.txtQtdProduto.Text, 2, _
                                               Format(Produto.Preco, "#,##0.00"), "$", "0")
                If ComandoExecutado(RetECF) Then
                    Me.Cupom.ItemVendido = True

                    TotalItem = Produto.Preco * CInt(txtQtdProduto.Text)
                    SubTotal += TotalItem

                    NumeroItem += 1

                    'Preparando o codigo e descri��o do produto para ser mostrada na tela
                    Cupom = Space(1) & Format(NumeroItem, "000") & Space(2) & _
                        Produto.Descricao & Space(29 - Len(Produto.Descricao)) & _
                        Space(2) & Space(3 - Len(txtQtdProduto.Text)) & txtQtdProduto.Text & _
                        Space(11 - Len(Format(TotalItem, "#,##0.00"))) & Format(TotalItem, "#,##0.00") & vbNewLine

                    Call AtualizarDisplay(Cupom)

                    Me.txtDescProduto.Text = Produto.Descricao
                    Me.txtValorProduto.Text = Format(Produto.Preco, "##0.00")
                    Me.txtTotalItem.Text = Format(TotalItem, "##0.00")

                    Me.txtSubTotal.Text = Format(SubTotal, "##0.00")
                    txtQtdProduto.Text = "1"

                    Me.btnFecharVenda.Enabled = True
                    Me.btnCancelarVenda.Enabled = True
                End If

                Me.txtCodProduto.Text = ""
                Me.txtCodProduto.Focus()
            End If

        End If

    End Sub

    Private Sub ExibeLayoutVenda(ByVal Layout As LayoutVenda)
        If Layout = LayoutVenda.CaixaLivre Then
            Me.pnlCaixaLivre.BringToFront()
            Me.pnlCaixaLivre.Visible = True

            Me.btnIniciarVenda.Visible = True
            Me.btnFecharVenda.Visible = False
            Me.btnCancelarVenda.Visible = False

            Me.btnSair.Enabled = True
            Me.btnFuncoesAdm.Visible = True

            Me.txtCodProduto.Focus()

        Else
            Dim EstadoObjeto As Boolean

            'esconde o panel de caixa livre
            Me.pnlCaixaLivre.SendToBack()
            Me.pnlCaixaLivre.Visible = False

            Me.btnFecharVenda.Visible = True
            Me.btnCancelarVenda.Visible = True
            Me.btnIniciarVenda.Visible = False

            Me.btnSair.Enabled = False
            Me.btnFuncoesAdm.Visible = False

            If Layout = LayoutVenda.InicioVenda Then

                EstadoObjeto = True

                'exibe os componentes usados quando 
                'a venda est� iniciada
                Me.lblTotalItem.Text = "Total do Item"
                Me.lblFormaPagamento.Visible = False
                Me.cboFormaPagamento.Visible = False

                Me.btnIniciarVenda.Visible = False
                Me.btnAlterarQtd.Enabled = True
                Me.btnFecharVenda.Visible = True
                Me.btnFecharVenda.Enabled = False
                Me.btnCancelarVenda.Visible = True
                Me.btnCancelarVenda.Enabled = False

                Me.txtCodProduto.Focus()

            ElseIf Layout = LayoutVenda.FechamentoVenda Then
                EstadoObjeto = False

                'exibe os componentes usados quando 
                'a venda est� iniciada
                'Me.lblQtd.Visible = False

                Me.lblTotalItem.Text = "Valor R$"

                Me.lblFormaPagamento.Visible = True
                Me.cboFormaPagamento.Visible = True
                Me.cboFormaPagamento.SelectedIndex = 0
                Me.txtTotalItem.Text = Format(SubTotal, "#,##0.00")
                Me.txtTotalItem.TabStop = True
                Me.txtTotalItem.Focus()

                'Me.btnIniciarVenda.Visible = False
                Me.btnAlterarQtd.Enabled = False
                Me.btnFecharVenda.Enabled = False
                Me.btnCancelarVenda.Enabled = True

            End If

            Me.lblQtd.Visible = EstadoObjeto
            Me.txtQtdProduto.Visible = EstadoObjeto
            Me.lblValor.Visible = EstadoObjeto
            Me.txtValorProduto.Visible = EstadoObjeto
            Me.lblSubTotal.Visible = EstadoObjeto
            Me.txtSubTotal.Visible = EstadoObjeto

            Me.lblProduto.Visible = EstadoObjeto
            Me.txtDescProduto.Visible = EstadoObjeto
            Me.txtCodProduto.Visible = EstadoObjeto

        End If

    End Sub

    Private Sub frmVenda_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyUp
        If e.KeyCode = Keys.F10 And Me.btnSair.Enabled = True Then
            Me.Close()

        ElseIf e.KeyCode = Keys.F2 And Not Me.Cupom.CupomAberto Then
            Call InicializaControles() 'inicializa os controles e variaveis

            RetECF = Bematech_FI_AbreCupom("")
            If (ComandoExecutado(RetECF)) Then
                Me.Cupom.CupomAberto = True
                Call ExibeLayoutVenda(LayoutVenda.InicioVenda)
            End If

            Me.txtCodProduto.Focus()

        ElseIf e.KeyCode = Keys.F3 And Me.Cupom.CupomAberto Then
            Me.txtQtdProduto.Focus()

        ElseIf e.KeyCode = Keys.F4 And (Me.Cupom.ItemVendido Or Me.Cupom.FechamentoIniciado) Then
            'cancela o cupom fiscal
            RetECF = Bematech_FI_CancelaCupom()
            If (ComandoExecutado(RetECF)) Then
                Me.Cupom.ItemVendido = False
                Me.Cupom.FechamentoIniciado = False
                Me.Cupom.CupomAberto = False

                Call ExibeLayoutVenda(LayoutVenda.CaixaLivre)
            End If

        ElseIf e.KeyCode = Keys.F5 And Me.btnFuncoesAdm.Visible Then
            Call TEF.FuncoesAdministrativas()

        ElseIf e.KeyCode = Keys.Escape And Me.Cupom.ItemVendido Then
            Dim TotalCupom As String = Space(14)

            'le o subtotal do cupom
            RetECF = Bematech_FI_SubTotal(TotalCupom)
            If Not ComandoExecutado(RetECF) Then
                Exit Sub
            End If

            'inicia o fechamento do cupom
            RetECF = Bematech_FI_IniciaFechamentoCupom("A", "$", "0")

            If ComandoExecutado(RetECF) Then

                Me.Cupom.FechamentoIniciado = True
                Me.Cupom.ItemVendido = False

                TotalCupom = TotalCupom.Insert(Len(TotalCupom) - 2, ",")
                SubTotal = CDec(TotalCupom)
                'If (ComandoExecutado(RetECF)) Then
                Call ExibeLayoutVenda(LayoutVenda.FechamentoVenda)

                'Preparando o cupom para ser colocado na tela
                Dim Cupom As String

                Cupom = Space(51 - Len("-----------")) & "-----------" & vbNewLine & _
                        Space(1) & "TOTAL R$ " & Space(41 - Len(Trim(Str(SubTotal)))) & _
                        Trim(Str(SubTotal)) & vbNewLine

                Call AtualizarDisplay(Cupom)
            End If

        End If
    End Sub

    Private Sub AtualizarDisplay(ByVal mensagem As String)
        rtbCupomFiscal.Text += mensagem
        'rtbCupomFiscal.Visible = False
        'rtbCupomFiscal.Visible = True
        rtbCupomFiscal.Refresh()
    End Sub

    Private Sub txtTotalItem_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtTotalItem.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            EfetuaFormaPagamento(Me.cboFormaPagamento.Text, Me.txtTotalItem.Text)

        ElseIf e.KeyChar = "."c Then
            e.Handled = True    ' inibe o sinal sonoro (beep)
            SendKeys.Send(",")  ' converte o ponto para virgula
        End If

    End Sub

    Private Sub cboFormaPagamento_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cboFormaPagamento.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            txtTotalItem.Focus()
        End If
    End Sub

    Private Sub txtTotalItem_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTotalItem.Enter
        ' ao receber o foco, o conteudo do controle ser� selecionado
        CType(sender, TextBox).SelectAll()
    End Sub

    Private Sub EfetuaFormaPagamento(ByVal FormaPagamento As String, ByVal ValorForma As Decimal)
        Dim Cupom As String

        Dim ValorPagto As String
        ValorPagto = Format(ValorForma, "#,##0.00")

        If FormaPagamento = "Cart�o" Then
            If ValorForma > SubTotal Then
                MessageBox.Show("N�o � permitido troco para as opera��es TEF.", "TEF_VBNET", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Me.txtTotalItem.Text = Format(SubTotal, "#,##0.00")
                Me.txtTotalItem.Focus()
                Exit Sub
            End If

            'Iniciar TEF
            If Not TEF.EnviaSolicita��o(Format(ValorForma, "0.00")) Then
                Me.cboFormaPagamento.Focus()
                Exit Sub
            End If

            Me.ResizeRedraw = True
            Me.Activate()
            Me.Refresh()

        End If

        RetECF = Bematech_FI_EfetuaFormaPagamento(FormaPagamento, ValorPagto)
        'if comando executado

        Me.Cupom.FechamentoIniciado = True

        'Preparando o cupom para ser colocado na tela
        Cupom = Space(1) & FormaPagamento & Space(16 - Len(FormaPagamento)) & _
                Space(34 - Len(ValorPagto)) & ValorPagto & vbNewLine


        Call AtualizarDisplay(Cupom)

        ValorRecebido += ValorForma
        SubTotal -= ValorForma
        If SubTotal > 0 Then
            Me.txtTotalItem.Text = Format(SubTotal, "#,##0.00")
            Me.cboFormaPagamento.Focus()

        Else
            Dim Troco As String
            SubTotal *= -1
            Troco = Format(SubTotal, "#,##0.00")

            RetECF = Bematech_FI_TerminaFechamentoCupom("Descomplicando o TEF em .NET" & vbLf & "Obrigado por participar do III Bematech Developers Day")
            Me.Cupom.CupomAberto = False

            'Preparando a string Valor Recebido e Troco para ser exibido no display
            Cupom = Space(1) & "Valor Recebido R$" & Space(33 - Len(Format(ValorRecebido, "#,##0.00"))) & _
                    Format(ValorRecebido, "#,##0.00") & vbNewLine

            Cupom += Space(1) & "Troco R$" & Space(42 - Len(Troco)) & _
                    Troco & vbNewLine

            Call AtualizarDisplay(Cupom)

            'imprime comprovante TEF
            TEF.Imprimir()

            Call ExibeLayoutVenda(LayoutVenda.CaixaLivre)

        End If
    End Sub

    Private Sub InicializaControles()
        'inicializa os controles
        Me.rtbCupomFiscal.Clear()
        Me.txtTotalItem.Text = ""
        Me.txtSubTotal.Text = ""
        Me.txtQtdProduto.Text = "1"
        Me.txtDescProduto.Text = ""
        Me.txtValorProduto.Text = ""
        Me.txtCodProduto.Text = ""

        'inicializa as variaveis globais da classe
        Me.ValorRecebido = 0
        Me.SubTotal = 0
        Me.NumeroItem = 0
        Me.RetECF = 0

        Me.txtCodProduto.Focus()

    End Sub

    Private Sub txtQtdProduto_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtQtdProduto.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            txtCodProduto.Focus()
        End If
    End Sub

    Private Function ComandoExecutado(ByVal RetFuncao As Integer) As Boolean
        Dim ACK, ST1, ST2 As Integer

        ComandoExecutado = False

        Select Case RetFuncao
            Case 0
                MessageBox.Show("Erro de comunica��o com a impressora!", "TEF_VBNET", MessageBoxButtons.OK, MessageBoxIcon.Error)

            Case 1, -27
                RetFuncao = Bematech_FI_RetornoImpressora(ACK, ST1, ST2)
                If ACK <> 6 And ST2 <> 0 Then
                    Dim MensagemErro As String

                    If ST1 >= 128 Then
                        ST1 -= 128 : MensagemErro = "Fim de papel. Por favor troque a bobina"

                    ElseIf ST1 >= 64 Then
                        ST1 -= 64 : MensagemErro = "Pouco Papel"

                    ElseIf ST1 >= 32 Then
                        ST1 -= 32 : MensagemErro = "Erro no rel�gio"

                    ElseIf ST1 >= 16 Then
                        ST1 -= 16 : MensagemErro = "Impressora em erro"

                    ElseIf ST1 >= 8 Then
                        ST1 -= 8 : MensagemErro = "O primeiro dado do comando n�o foi ESC"

                    ElseIf ST1 >= 4 Then
                        ST1 -= 4 : MensagemErro = "Comando inexistente"

                    ElseIf ST1 >= 2 Then
                        ST1 -= 2 : MensagemErro = "Cupom fiscal aberto"

                    ElseIf ST1 >= 1 Then
                        ST1 -= 1 : MensagemErro = "N�mero de par�metro inv�lido no comando"

                    End If

                    If ST2 >= 128 Then
                        ST2 -= 128 : MensagemErro = "Tipo de par�metro inv�lido"

                    ElseIf ST2 >= 64 Then
                        ST2 -= 64 : MensagemErro = "Mem�ria fiscal da impressora est� lotada"

                    ElseIf ST2 >= 32 Then
                        ST2 -= 32 : MensagemErro = "Erro na impressora"

                    ElseIf ST2 >= 16 Then
                        ST2 -= 16 : MensagemErro = "Al�quota n�o programada"

                    ElseIf ST2 >= 8 Then
                        ST2 -= 8 : MensagemErro = "Capacidade de al�quotas lotada"

                    ElseIf ST2 >= 4 Then
                        ST2 -= 4 : MensagemErro = "Cancelamento do cupom n�o permitido"

                    ElseIf ST2 >= 2 Then
                        ST2 -= 2 : MensagemErro = "Impressora n�o est� lacrada"

                    ElseIf ST2 >= 1 Then
                        ST2 -= 1 : MensagemErro = "Comando n�o executado"

                    End If

                    MessageBox.Show(mensagemerro, "TEF_VBNET", MessageBoxButtons.OK, MessageBoxIcon.Error)

                Else
                    ComandoExecutado = True
                End If

            Case Else
                MessageBox.Show("Erro na execu��o do comando!" & vbLf & "Erro: " & Str(RetFuncao), "TEF_VBNET", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Select




        Select Case RetFuncao
            Case 0
                MessageBox.Show("Erro de comunica��o com a impressora!", "TEF_VBNET", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Function

            Case 1, -27
                ComandoExecutado = True
                If ST1 <> 0 Or ST2 <> 0 Then
                    Dim MensagemErro As String
                    If ST1 >= 128 Then
                        ST1 -= 128 : MensagemErro = "Fim de papel. Por favor troque a bobina"

                    ElseIf ST1 >= 64 Then
                        ST1 -= 64 : MensagemErro = "Pouco Papel"

                    ElseIf ST1 >= 32 Then
                        ST1 -= 32 : MensagemErro = "Erro no rel�gio"

                    ElseIf ST1 >= 16 Then
                        ST1 -= 16 : MensagemErro = "Impressora em erro"

                    ElseIf ST1 >= 8 Then
                        ST1 -= 8 : MensagemErro = "Pouco Papel"




                    End If
                End If

            Case Else
                MessageBox.Show("Erro na execu��o do comando!" & vbLf & "Erro: " & Str(RetFuncao), "TEF_VBNET", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Function

        End Select
        RetFuncao = Bematech_FI_RetornoImpressora(ACK, ST1, ST2)

        ComandoExecutado = True
    End Function


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'Call ExibeMensagemOperador()
    End Sub

End Class

Public Class CupomFiscal
    Private bCupomAberto As Boolean
    Private bItemVendido As Boolean
    Private bFechamentoIniciado As Boolean

    Public Property CupomAberto() As Boolean
        Get
            Return bCupomAberto
        End Get
        Set(ByVal Value As Boolean)
            bCupomAberto = Value
        End Set
    End Property

    Public Property ItemVendido() As Boolean
        Get
            Return bItemVendido
        End Get
        Set(ByVal Value As Boolean)
            bItemVendido = Value
        End Set
    End Property

    Public Property FechamentoIniciado() As Boolean
        Get
            Return bFechamentoIniciado
        End Get
        Set(ByVal Value As Boolean)
            bFechamentoIniciado = Value
        End Set
    End Property

End Class

Public Class BemaTEF
    Private bImpressaoGerencial As Boolean   'Imprimir o comprovante TEF no rel. gerencial
    Private bTemImpressao As Boolean         'Indica se tem texto para ser impresso no TEF
    Private Rede As String                  'Nome da rede que est� sendo realizada a transa��o TEF
    Private NSU As String                   'Numero Sequencial Unico da transa��o TEF
    Private ValorTEF As String              'Valor da transa��o TEF
    Private Finalizacao As String           'Campo 27 do intpos.001
    Private MsgOperador As String           'Mensagem a ser exibida para o operador 

    Public Function EnviaSolicita��o(ByVal valorTEF As String) As Boolean

        Dim NumSequencialTEF As String
        Dim Mensagem As String

        'inicializa as variaveis usadas no TEF
        Call InicializaVariaveisTEF()

        Try
            If File.Exists("C:\TEF_DIAL\RESP\intpos.001") Then
                File.Delete("C:\TEF_DIAL\RESP\intpos.001")
            End If

        Catch ex As Exception

        End Try

        NumSequencialTEF = Format(DateTime.Now, "MMddHHmmss")

        '        valorTEF = valorTEF.Replace(",", "")
        'monta o arquivo de solicita��o do TEF
        Mensagem = "000-000 = CRT" + vbCrLf + _
                   "001-000 = " + NumSequencialTEF + vbCrLf + _
                   "003-000 = " + Trim(valorTEF.Replace(",", "")) + vbCrLf + _
                   "999-999 = 0"

        'gera o arquivo de solicitacao
        If Not GeraArquivoSolicitacao(Mensagem) Then
            Return False
        End If

        'verifica se a transacao foi ou n�o aprovada
        If Not TransacaoAprovada() Then
            'exibe mensagem ao operador
            If Me.MsgOperador <> "" Then
                Dim FrmOperador As New FormOperador

                FrmOperador.lblNSU.Visible = False
                FrmOperador.lblRede.Visible = False
                FrmOperador.lblValor.Visible = False
                FrmOperador.lblMsgOperador.Text = Me.MsgOperador
                FrmOperador.bSaidaAutomatica = False
                FrmOperador.botaoOkVisivel = True
                FrmOperador.ShowDialog()

                'apaga o arquivo intpos.001 de resposta
                Call ApagaArquivoResposta()
            End If
            Return False
        Else
            Return True
        End If
    End Function
    Private Function TransacaoAprovada() As Boolean

        'l� o arquivo de resposta e verifica se a transa��o foi aprovada
        Dim PathRESP As String = "C:\TEF_DIAL\RESP"
        Dim ArqResposta As StreamReader = Nothing
        Dim LinhaArquivo As String

        'aguarda receber o arquivo de resposta IntPos.001
        While True
            If File.Exists(PathRESP + "\intpos.001") Then
                Exit While
            End If
        End While

        ArqResposta = New StreamReader(PathRESP + "\intpos.001", System.Text.Encoding.UTF7)
        LinhaArquivo = ArqResposta.ReadLine()
        While Not LinhaArquivo Is Nothing

            'campo 003 - VALOR
            If LinhaArquivo.Substring(0, 3) = "003" Then
                ValorTEF = LinhaArquivo.Substring(10)
            End If

            'campo 009 - verifica se a transa��o foi aprovada
            If LinhaArquivo.Substring(0, 3) = "009" Then
                If LinhaArquivo.Substring(10, LinhaArquivo.Length - 10) = "0" Then
                    TransacaoAprovada = True
                Else
                    TransacaoAprovada = False
                End If
            End If

            'campo 010 - REDE
            If LinhaArquivo.Substring(0, 3) = "010" Then
                Rede = LinhaArquivo.Substring(10)

                'campo 012 - NSU
            ElseIf LinhaArquivo.Substring(0, 3) = "012" Then
                NSU = LinhaArquivo.Substring(10)

                'campo 027 - Finalizacao
            ElseIf LinhaArquivo.Substring(0, 3) = "027" Then
                Finalizacao = LinhaArquivo.Substring(10)

                'campo 028 - qtde de linhas para serem impressas
            ElseIf LinhaArquivo.Substring(0, 3) = "028" Then
                If CInt(LinhaArquivo.Substring(10, LinhaArquivo.Length - 10)) > 0 Then
                    bTemImpressao = True
                End If

                'campo 030 - Mensagem ao operador
            ElseIf LinhaArquivo.Substring(0, 3) = "030" Then
                MsgOperador = LinhaArquivo.Substring(10)

            End If
            LinhaArquivo = ArqResposta.ReadLine()
        End While

        ArqResposta.Close() 'fecha o arquivo
        ArqResposta = Nothing
    End Function

    Private Function ImprimeComprovante() As Boolean

        'l� o arquivo de resposta e verifica se a transa��o foi aprovada
        Dim PathRESP As String = "C:\TEF_DIAL\RESP\intpos.001"
        Dim ArqResposta As StreamReader = Nothing
        Dim LinhaArquivo As String
        Dim Contador As Integer
        Dim RetECF As Integer

        If Not bImpressaoGerencial Then
            RetECF = Bematech_FI_AbreComprovanteNaoFiscalVinculado("Cart�o", "", "")
            If RetECF = 0 Then  'impressora desligada
                Return False
            End If
        End If

        'trava o mouse e o teclado
        Bematech_FI_IniciaModoTEF()

        ArqResposta = File.OpenText(PathRESP)
        For Contador = 1 To 2
            ArqResposta = File.OpenText(PathRESP)
            LinhaArquivo = ArqResposta.ReadLine()
            While Not LinhaArquivo Is Nothing
                If LinhaArquivo.Substring(0, 3) = "029" Then
                    LinhaArquivo = LinhaArquivo.Substring(11, LinhaArquivo.Length() - 12)
                    LinhaArquivo = LinhaArquivo.Replace(Chr(34), "")
                    If LinhaArquivo = "" Then
                        LinhaArquivo = vbLf
                    End If
                    If bImpressaoGerencial Then
                        RetECF = Bematech_FI_RelatorioGerencial(LinhaArquivo)
                    Else

                        RetECF = Bematech_FI_UsaComprovanteNaoFiscalVinculado(LinhaArquivo)
                    End If
                    If RetECF <> 1 And RetECF <> -27 Then
                        ArqResposta.Close()
                        ArqResposta = Nothing

                        'destrava o mouse e o teclado
                        Bematech_FI_FinalizaModoTEF()

                        Return False
                    End If
                End If
                LinhaArquivo = ArqResposta.ReadLine()

            End While

            'se for a primeira via do comprovante salta 5 linhas
            'entre um comprovante e outro e aguarda 5 segundos
            'para o operador destacar o comprovante
            If Contador = 1 Then
                'salta 5 linhas entre uma via e outra
                LinhaArquivo = vbLf + vbLf + vbLf + vbLf + vbLf
                If bImpressaoGerencial Then
                    RetECF = Bematech_FI_RelatorioGerencial(LinhaArquivo)
                Else
                    RetECF = Bematech_FI_UsaComprovanteNaoFiscalVinculado(LinhaArquivo)
                End If

                If RetECF <> 1 And RetECF <> -27 Then
                    ArqResposta.Close()
                    ArqResposta = Nothing

                    'destrava o mouse e o teclado
                    Bematech_FI_FinalizaModoTEF()
                    Return False
                End If

                Espera(4000) 'espera 4 segundos
            End If

            ArqResposta.Close()
            ArqResposta = Nothing
        Next

        RetECF = Bematech_FI_FechaComprovanteNaoFiscalVinculado()

        'destrava o mouse e o teclado
        Bematech_FI_FinalizaModoTEF()

        Return True
    End Function

    Public Sub Imprimir()
        Dim FrmOperador As New FormOperador

        If bTemImpressao Then

            Dim Result As DialogResult

            'exibe mensagem ao operador
            If Me.MsgOperador <> "" Then
                FrmOperador.lblNSU.Visible = False
                FrmOperador.lblRede.Visible = False
                FrmOperador.lblValor.Visible = False
                FrmOperador.lblMsgOperador.Text = Me.MsgOperador
                FrmOperador.StartPosition = FormStartPosition.CenterScreen
                FrmOperador.bSaidaAutomatica = True
                FrmOperador.botaoOkVisivel = False
                FrmOperador.ShowDialog()
            End If

            While True
                If Not ImprimeComprovante() Then
                    FrmOperador.Hide()
                    Result = MessageBox.Show("A impressora n�o responde. Tentar imprimir novamente?", "TEF_VBNET", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1)
                    If Result = DialogResult.No Then
                        'envia o NCN
                        NaoConfirmaTransacao()

                        'fecha o comprovante
                        Bematech_FI_FechaComprovanteNaoFiscalVinculado()

                        'apaga o intpos.001
                        ApagaArquivoResposta()
                        Exit While
                    Else
                        'fecha o comprovante
                        Bematech_FI_FechaComprovanteNaoFiscalVinculado()

                        bImpressaoGerencial = True

                    End If

                Else

                    'envia o CNF
                    ConfirmaTransacao()

                    'apaga o intpos.001
                    ApagaArquivoResposta()

                    Exit While
                End If
            End While

            bImpressaoGerencial = False

        End If

        'zera as variaveis TEF
        Call InicializaVariaveisTEF()

        FrmOperador.Close()
        FrmOperador = Nothing

    End Sub

    Private Sub Espera(ByVal Milesegundos As Double)
        Dim TempoInicial As DateTime
        Dim TempoFinal As DateTime
        Dim DiferencaTempo As TimeSpan
        Dim Diferenca As Double

        TempoInicial = Now
        Do
            TempoFinal = Now
            DiferencaTempo = TempoFinal.Subtract(TempoInicial)
            Diferenca = DiferencaTempo.TotalMilliseconds

        Loop While Diferenca < Milesegundos

    End Sub

    Private Function ConfirmaTransacao() As Boolean
        Dim NumSequencialTEF As String     'numero sequencia da transacao TEF
        Dim Mensagem As String             'solicitacao enviada

        NumSequencialTEF = Format(DateTime.Now, "MMddHHmmss")

        'monta o arquivo de confirmacao
        Mensagem = "000-000 = CNF" + vbCrLf + _
                   "001-000 = " + NumSequencialTEF + vbCrLf + _
                   "010-000 = " + Rede + vbCrLf + _
                   "012-000 = " + NSU + vbCrLf + _
                   "027-000 = " + Finalizacao + vbCrLf + _
                   "999-999 = 0"

        If GeraArquivoSolicitacao(Mensagem) Then
            Return True
        Else
            Return False
        End If

    End Function
    Private Function NaoConfirmaTransacao() As Boolean
        Dim NumSequencialTEF As String     'numero sequencia da transacao TEF
        Dim Mensagem As String             'solicitacao enviada

        NumSequencialTEF = Format(DateTime.Now, "MMddHHmmss")

        'monta o arquivo de confirmacao
        Mensagem = "000-000 = NCN" + vbCrLf + _
                   "001-000 = " + NumSequencialTEF + vbCrLf + _
                   "010-000 = " + Rede + vbCrLf + _
                   "012-000 = " + NSU + vbCrLf + _
                   "027-000 = " + Finalizacao + vbCrLf + _
                   "999-999 = 0"

        If GeraArquivoSolicitacao(Mensagem) Then

            Dim FrmOperador As New FormOperador
            FrmOperador.lblMsgOperador.Text = "�ltima Transa��o TEF foi Cancelada"
            FrmOperador.lblRede.Text = "Rede: " & Me.Rede
            FrmOperador.lblNSU.Text = "NSU: " & Me.NSU
            If Me.NSU <> "" Then
                FrmOperador.lblNSU.Visible = True
            Else
                FrmOperador.lblNSU.Visible = True
            End If

            If Me.ValorTEF <> "" Then
                Dim tmpValor As String

                tmpValor = Format(CInt(Me.ValorTEF), "000")
                tmpValor = tmpValor.Insert(tmpValor.Length - 2, ",")
                tmpValor = Format(CDec(tmpValor), "#,##0.00")
                FrmOperador.lblValor.Text = "Valor: " & tmpValor
                FrmOperador.lblValor.Visible = True
            Else
                FrmOperador.lblValor.Visible = False
            End If

            FrmOperador.btnOk.Visible = True
            FrmOperador.bSaidaAutomatica = False
            FrmOperador.botaoOkVisivel = True
            FrmOperador.ShowDialog()

            'se a confirmacao for aceita, apaga o intpos.001
            ApagaArquivoResposta()
            Return True
        Else
            Return False
        End If
    End Function

    Private Function GeraArquivoSolicitacao(ByVal Mensagem As String) As Boolean
        Dim PathREQ As String = "C:\TEF_DIAL\REQ"   'path do arquivo de solicitacao
        Dim PathRESP As String = "C:\TEF_DIAL\RESP" 'path do arquivo de resposta
        Dim Arquivo As StreamWriter = Nothing       'arquivo de solicitacao

        Try
            'apaga os arquivos se existirem
            If File.Exists(PathREQ + "\intpos.tmp") Then
                File.Delete(PathREQ + "\intpos.tmp")
            End If

            If File.Exists("C:\TEF_DIAL\REQ\intpos.001") Then
                File.Delete("C:\TEF_DIAL\REQ\intpos.001")
            End If

            'cria o arquivo de solicita��o temporariamente
            Arquivo = File.CreateText(PathREQ + "\intpos.tmp")
            Arquivo.Write(Mensagem)
            Arquivo.Close()
            Arquivo = Nothing

            'renomeia o arquivo para intpos.001
            Rename(PathREQ + "\intpos.tmp", PathREQ + "\intpos.001")

            'aguarda at� 7 segundos para receber a confirma��o de recebimento 
            'da(solicitacao). Se n�o receber exibe a mensagem de gerenciador
            'padr�o inativo
            Dim Contador As Integer = 0
            While (Not File.Exists(PathRESP + "\intpos.sts")) And Contador < 70
                Espera(100)
                Contador += 1
            End While

            If Contador < 70 Then
                File.Delete(PathRESP + "\intpos.sts")
                Return True
            Else
                If File.Exists(PathREQ + "\intpos.001") Then
                    File.Delete(PathREQ + "\intpos.001")
                End If

                MessageBox.Show("O Gerenciador Padr�o n�o est� ativo!", "TEF_VBNET", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Function

    Private Sub ApagaArquivoResposta()
        Try
            If File.Exists("C:\TEF_DIAL\RESP\intpos.001") Then
                File.Delete("C:\TEF_DIAL\RESP\intpos.001")
            End If

        Catch ex As Exception

        End Try

    End Sub

    Public Sub FuncoesAdministrativas()
        Dim NumSequencialTEF As String     'numero sequencia da transacao TEF
        Dim Mensagem As String             'solicitacao enviada

        'apaga o intpos.001
        ApagaArquivoResposta()

        NumSequencialTEF = Format(DateTime.Now, "MMddHHmmss")

        'monta o arquivo de confirmacao
        Mensagem = "000-000 = ADM" + vbCrLf + _
                   "001-000 = " + NumSequencialTEF + vbCrLf + _
                   "999-999 = 0"

        If Not GeraArquivoSolicitacao(Mensagem) Then
            Exit Sub
        End If

        If Not TransacaoAprovada() Then
            'exibe mensagem ao operador
            If Me.MsgOperador <> "" Then
                Dim FrmOperador As New FormOperador

                FrmOperador.lblNSU.Visible = False
                FrmOperador.lblRede.Visible = False
                FrmOperador.lblValor.Visible = False
                FrmOperador.lblMsgOperador.Text = Me.MsgOperador
                FrmOperador.bSaidaAutomatica = False
                FrmOperador.botaoOkVisivel = True
                FrmOperador.ShowDialog()

                'apaga o arquivo intpos.001 de resposta
                Call ApagaArquivoResposta()
            End If
        Else
            'seta a variavel para imprimir no relatorio gerencial
            bImpressaoGerencial = True
            Call Imprimir()
            bImpressaoGerencial = False
        End If

    End Sub

    Private Sub InicializaVariaveisTEF()
        'inicializa as variaveis
        ValorTEF = ""
        Rede = ""
        NSU = ""
        bTemImpressao = False
        Finalizacao = ""
        MsgOperador = ""
    End Sub
End Class

