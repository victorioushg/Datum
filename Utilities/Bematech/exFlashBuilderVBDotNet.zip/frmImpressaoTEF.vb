Public Class frmImpressaoTEF
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lblMensagem As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmImpressaoTEF))
        Me.lblMensagem = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'lblMensagem
        '
        Me.lblMensagem.BackColor = System.Drawing.Color.FromArgb(CType(228, Byte), CType(232, Byte), CType(185, Byte))
        Me.lblMensagem.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMensagem.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblMensagem.Location = New System.Drawing.Point(16, 23)
        Me.lblMensagem.Name = "lblMensagem"
        Me.lblMensagem.Size = New System.Drawing.Size(280, 120)
        Me.lblMensagem.TabIndex = 4
        Me.lblMensagem.Text = "lblMensagem"
        '
        'frmImpressaoTEF
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(312, 166)
        Me.Controls.Add(Me.lblMensagem)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmImpressaoTEF"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmImpressaoTEF"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub lblMensagem_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lblMensagem.TextChanged
        Me.Refresh()
        Application.DoEvents()
    End Sub
End Class
