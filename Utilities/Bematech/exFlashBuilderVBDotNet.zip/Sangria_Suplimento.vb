Imports Bematech
Imports Bematech.Fiscal.ECF
Imports Bematech.Fiscal.ECF.CupomFiscal

Public Class Sangria_Suplimento

    Inherits System.Windows.Forms.Form
    Private main As Principal
    Private printer As ImpressoraFiscal

#Region " Windows Form Designer generated code "

    Public Sub New(ByVal main As Principal, ByVal printer As ImpressoraFiscal)
        MyBase.New()
        Me.main = main
        Me.printer = printer


        'This call is required by the Windows Form Designer.
        InitializeComponent()
        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lblAtrib As System.Windows.Forms.Label
    Friend WithEvents txAtrib As System.Windows.Forms.TextBox
    Friend WithEvents btnCancelar As System.Windows.Forms.Button
    Friend WithEvents btnConfirmar As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Sangria_Suplimento))
        Me.lblAtrib = New System.Windows.Forms.Label
        Me.txAtrib = New System.Windows.Forms.TextBox
        Me.btnCancelar = New System.Windows.Forms.Button
        Me.btnConfirmar = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'lblAtrib
        '
        Me.lblAtrib.BackColor = System.Drawing.Color.Transparent
        Me.lblAtrib.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAtrib.Location = New System.Drawing.Point(32, 56)
        Me.lblAtrib.Name = "lblAtrib"
        Me.lblAtrib.Size = New System.Drawing.Size(99, 16)
        Me.lblAtrib.TabIndex = 5
        Me.lblAtrib.Text = "Suprimento  :"
        '
        'txAtrib
        '
        Me.txAtrib.Location = New System.Drawing.Point(134, 56)
        Me.txAtrib.Name = "txAtrib"
        Me.txAtrib.Size = New System.Drawing.Size(64, 20)
        Me.txAtrib.TabIndex = 4
        Me.txAtrib.Text = ""
        '
        'btnCancelar
        '
        Me.btnCancelar.Image = CType(resources.GetObject("btnCancelar.Image"), System.Drawing.Image)
        Me.btnCancelar.Location = New System.Drawing.Point(250, 123)
        Me.btnCancelar.Name = "btnCancelar"
        Me.btnCancelar.Size = New System.Drawing.Size(75, 20)
        Me.btnCancelar.TabIndex = 7
        '
        'btnConfirmar
        '
        Me.btnConfirmar.Image = CType(resources.GetObject("btnConfirmar.Image"), System.Drawing.Image)
        Me.btnConfirmar.Location = New System.Drawing.Point(162, 123)
        Me.btnConfirmar.Name = "btnConfirmar"
        Me.btnConfirmar.Size = New System.Drawing.Size(75, 20)
        Me.btnConfirmar.TabIndex = 6
        '
        'Sangria_Suplimento
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.FromArgb(CType(228, Byte), CType(232, Byte), CType(185, Byte))
        Me.ClientSize = New System.Drawing.Size(344, 157)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnCancelar)
        Me.Controls.Add(Me.btnConfirmar)
        Me.Controls.Add(Me.lblAtrib)
        Me.Controls.Add(Me.txAtrib)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Sangria_Suplimento"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.ResumeLayout(False)

    End Sub


#End Region

    Private Sub Sangria_Suplimento_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Me.Tag = "SANGRIA" Or Me.Tag = "FECHAMENTO" Then
            lblAtrib.Text = "Sangria :"
        End If
        txAtrib.Text = main.montaMascara(0)

    End Sub

    Private Sub txAtrib_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txAtrib.KeyPress
        If e.KeyChar = ChrW(13) Then
            btnConfirmar.Focus()
        End If
    End Sub

    Private Sub btnConfirmar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConfirmar.Click
        Try
            If Me.Tag = "SANGRIA" Then
                If CDec(txAtrib.Text) > 0D Then
                    printer.OperacaoNaoFiscal.ExecutarSangria(CDec(txAtrib.Text))
                End If
                Me.Dispose()
            ElseIf Me.Tag = "FECHAMENTO" Then
                If CDec(txAtrib.Text) > 0D Then
                    printer.OperacaoNaoFiscal.ExecutarSangria(CDec(txAtrib.Text))
                End If
                printer.RelatoriosFiscais.ImprimirReducaoZ(100)
                main.montarAparenciaCaixaFechado(True)
                Me.Dispose()
            ElseIf Me.Tag = "SUPRIMENTO" Then
                If CDec(txAtrib.Text) > 0D Then
                    printer.OperacaoNaoFiscal.ExecutarSuprimento(Convert.ToDecimal(txAtrib.Text))
                End If

                Me.Dispose()
            Else
                printer.RelatoriosFiscais.ImprimirLeituraX(100)
                If (CDec(txAtrib.Text) > 0D) Then
                    printer.OperacaoNaoFiscal.ExecutarSuprimento(CDec(txAtrib.Text))
                End If
                main.montarAparenciaCaixaAberto()
                Me.Dispose()
            End If

        Catch ex As BematechException
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelar.Click
        Me.Dispose()
    End Sub
End Class
