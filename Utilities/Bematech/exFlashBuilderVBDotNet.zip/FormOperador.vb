Public Class FormOperador
    Inherits System.Windows.Forms.Form

    Public bSaidaAutomatica As Boolean
    Public botaoOkVisivel As Boolean    'N�o aparecer o bot�o OK

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lblMsgOperador As System.Windows.Forms.Label
    Friend WithEvents btnOk As System.Windows.Forms.Button
    Friend WithEvents lblRede As System.Windows.Forms.Label
    Friend WithEvents lblNSU As System.Windows.Forms.Label
    Friend WithEvents lblValor As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.lblMsgOperador = New System.Windows.Forms.Label
        Me.btnOk = New System.Windows.Forms.Button
        Me.lblRede = New System.Windows.Forms.Label
        Me.lblNSU = New System.Windows.Forms.Label
        Me.lblValor = New System.Windows.Forms.Label
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'lblMsgOperador
        '
        Me.lblMsgOperador.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMsgOperador.Location = New System.Drawing.Point(16, 24)
        Me.lblMsgOperador.Name = "lblMsgOperador"
        Me.lblMsgOperador.Size = New System.Drawing.Size(280, 16)
        Me.lblMsgOperador.TabIndex = 0
        Me.lblMsgOperador.Text = "�ltima Transa��o TEF foi Cancelada"
        Me.lblMsgOperador.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnOk
        '
        Me.btnOk.Location = New System.Drawing.Point(224, 128)
        Me.btnOk.Name = "btnOk"
        Me.btnOk.Size = New System.Drawing.Size(72, 24)
        Me.btnOk.TabIndex = 1
        Me.btnOk.Text = "Ok"
        '
        'lblRede
        '
        Me.lblRede.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRede.Location = New System.Drawing.Point(13, 59)
        Me.lblRede.Name = "lblRede"
        Me.lblRede.Size = New System.Drawing.Size(280, 16)
        Me.lblRede.TabIndex = 2
        Me.lblRede.Text = "Rede:"
        Me.lblRede.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblNSU
        '
        Me.lblNSU.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNSU.Location = New System.Drawing.Point(13, 80)
        Me.lblNSU.Name = "lblNSU"
        Me.lblNSU.Size = New System.Drawing.Size(272, 16)
        Me.lblNSU.TabIndex = 3
        Me.lblNSU.Text = "NSU:"
        Me.lblNSU.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblValor
        '
        Me.lblValor.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblValor.Location = New System.Drawing.Point(13, 104)
        Me.lblValor.Name = "lblValor"
        Me.lblValor.Size = New System.Drawing.Size(280, 16)
        Me.lblValor.TabIndex = 4
        Me.lblValor.Text = "Valor:"
        Me.lblValor.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Timer1
        '
        Me.Timer1.Interval = 6000
        '
        'FormOperador
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.FromArgb(CType(216, Byte), CType(228, Byte), CType(248, Byte))
        Me.ClientSize = New System.Drawing.Size(306, 160)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblValor)
        Me.Controls.Add(Me.lblNSU)
        Me.Controls.Add(Me.lblRede)
        Me.Controls.Add(Me.btnOk)
        Me.Controls.Add(Me.lblMsgOperador)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "FormOperador"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click
        Me.Close()
    End Sub

    Private Sub FormOperador_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        If bSaidaAutomatica Then
            Timer1.Enabled = True
            btnOk.Visible = False
        Else
            Timer1.Enabled = False
            btnOk.Visible = botaoOkVisivel
        End If
        If btnOk.Visible Then
            btnOk.Focus()
        Else
            If Me.Enabled Then
                Me.Focus()
            End If
        End If

    End Sub

    Private Sub btnOk_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnOk.LostFocus
        If btnOk.Visible Then
            btnOk.Focus()
        Else
            If Me.Enabled Then
                Me.Focus()
            End If
        End If

    End Sub

    Private Sub FormOperador_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.LostFocus
        If btnOk.Visible Then
            btnOk.Focus()
        Else
            If Me.Enabled Then
                Me.Focus()
            End If
        End If

    End Sub

    Private Sub Timer1_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Me.Close()
    End Sub
End Class
