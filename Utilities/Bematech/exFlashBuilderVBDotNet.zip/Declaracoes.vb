Module Declaracoes

    Public SubTotal As Decimal 'Armazena o subtotal da venda no cupom fiscal
End Module
