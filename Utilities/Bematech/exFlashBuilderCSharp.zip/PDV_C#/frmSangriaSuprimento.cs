using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace PDVCSharp
{
	/// <summary>
	/// Summary description for frmSangriaSuprimento.
	/// </summary>
	public class frmSangriaSuprimento : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnCancelar;
		private System.Windows.Forms.Button btnConfirmar;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtValor;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private frmVenda formVenda = null;

		public frmSangriaSuprimento()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		public frmSangriaSuprimento( frmVenda formVenda)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			this.formVenda = formVenda;

		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSangriaSuprimento));
			this.btnCancelar = new System.Windows.Forms.Button();
			this.btnConfirmar = new System.Windows.Forms.Button();
			this.txtValor = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// btnCancelar
			// 
			this.btnCancelar.Image = ((System.Drawing.Image)(resources.GetObject("btnCancelar.Image")));
			this.btnCancelar.Location = new System.Drawing.Point(248, 128);
			this.btnCancelar.Name = "btnCancelar";
			this.btnCancelar.Size = new System.Drawing.Size(75, 20);
			this.btnCancelar.TabIndex = 2;
			this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
			// 
			// btnConfirmar
			// 
			this.btnConfirmar.Image = ((System.Drawing.Image)(resources.GetObject("btnConfirmar.Image")));
			this.btnConfirmar.Location = new System.Drawing.Point(160, 128);
			this.btnConfirmar.Name = "btnConfirmar";
			this.btnConfirmar.Size = new System.Drawing.Size(75, 20);
			this.btnConfirmar.TabIndex = 1;
			this.btnConfirmar.Click += new System.EventHandler(this.btnConfirmar_Click);
			// 
			// txtValor
			// 
			this.txtValor.Location = new System.Drawing.Point(24, 56);
			this.txtValor.MaxLength = 9;
			this.txtValor.Name = "txtValor";
			this.txtValor.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.txtValor.Size = new System.Drawing.Size(64, 20);
			this.txtValor.TabIndex = 0;
			this.txtValor.Text = "0,00";
			this.txtValor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtValor_KeyPress);
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.Location = new System.Drawing.Point(24, 24);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(208, 16);
			this.label1.TabIndex = 4;
			this.label1.Text = "Informe o valor da Sangria:";
			// 
			// frmSangriaSuprimento
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(228)), ((System.Byte)(232)), ((System.Byte)(185)));
			this.ClientSize = new System.Drawing.Size(344, 160);
			this.Controls.Add(this.btnCancelar);
			this.Controls.Add(this.btnConfirmar);
			this.Controls.Add(this.txtValor);
			this.Controls.Add(this.label1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmSangriaSuprimento";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "frmSangriaSuprimento";
			this.Load += new System.EventHandler(this.frmSangriaSuprimento_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void txtValor_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)Keys.Enter)
			{
				this.btnConfirmar.Focus();
			}
			else if (e.KeyChar == '.')
			{
				e.Handled = true;
				SendKeys.Send(",");  //converte o ponto para virgula
			}
			else if ((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != (char)Keys.Back && e.KeyChar != ',')
			{
				e.Handled = true;
				SendKeys.Send("");
			}
		}

		private void btnCancelar_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void btnConfirmar_Click(object sender, System.EventArgs e)
		{
			try
			{
				if (this.txtValor.Text == "")
				{
					MessageBox.Show("O valor n�o pode ser nulo", "PDV-CSharp", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					this.txtValor.Focus();
					return;
				}
				
				decimal valor = decimal.Parse(txtValor.Text);
				if (valor < 0)
				{
					MessageBox.Show("O valor n�o pode ser negativo", "PDV-CSharp", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					this.txtValor.Focus();
					return;
				}

				if(this.Tag.ToString() == "SUPRIMENTO")
				{
					if (valor > 0)
					{
						frmVenda.printer.OperacaoNaoFiscal.ExecutarSuprimento(valor);
						formVenda.ExibirLayoutCaixaLivre();
					}
					else
					{
						MessageBox.Show("Por favor digite o valor do suprimento", "PDV-CSharp", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
						this.txtValor.Focus();
						return;
					}
				}
				else if(this.Tag.ToString() == "SANGRIA")
				{
					if (valor > 0)
					{
						frmVenda.printer.OperacaoNaoFiscal.ExecutarSangria(valor);
						formVenda.ExibirLayoutCaixaLivre();
					}
					else
					{
						MessageBox.Show("Por favor digite o valor da sangria", "PDV-CSharp", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
						this.txtValor.Focus();
						return;
					}
				}
				else if(this.Tag.ToString() == "ABERTURA CAIXA")
				{
					frmVenda.printer.RelatoriosFiscais.ImprimirLeituraX(60); // timeout 1 min
					if (valor > 0)
					{
						frmVenda.printer.OperacaoNaoFiscal.ExecutarSuprimento(decimal.Parse(txtValor.Text));
					}
					formVenda.ExibirLayoutCaixaLivre();
				}
				else if(this.Tag.ToString() == "FECHAMENTO CAIXA")
				{
					if (valor > 0)
					{
						frmVenda.printer.OperacaoNaoFiscal.ExecutarSangria(valor);
					}
					frmVenda.printer.RelatoriosFiscais.ImprimirReducaoZ(60); // timeout 1 min
					formVenda.ExibirLayoutCaixaFechado();
				}
				this.Close();
			}
			catch (Exception erro)
			{
				MessageBox.Show(erro.Message,"Erro no Cancelamento do Item", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void frmSangriaSuprimento_Load(object sender, System.EventArgs e)
		{
			if (this.Tag.ToString() == "SUPRIMENTO" || this.Tag.ToString() == "ABERTURA CAIXA")
				this.label1.Text = "Informe o valor do suprimento:";
			else
				this.label1.Text = "Informe o valor da sangria:";
		}
	}
}
