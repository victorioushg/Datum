using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace PDVCSharp
{
	/// <summary>
	/// Summary description for frmAdministrativo.
	/// </summary>
	public class frmAdministrativo : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnCancelar;
		private System.Windows.Forms.Button btnConfirmar;
		private System.Windows.Forms.Label lblMensagem;
		internal System.Windows.Forms.ComboBox cboRede;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmAdministrativo()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmAdministrativo));
			this.lblMensagem = new System.Windows.Forms.Label();
			this.cboRede = new System.Windows.Forms.ComboBox();
			this.btnCancelar = new System.Windows.Forms.Button();
			this.btnConfirmar = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lblMensagem
			// 
			this.lblMensagem.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(228)), ((System.Byte)(232)), ((System.Byte)(185)));
			this.lblMensagem.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblMensagem.Location = new System.Drawing.Point(8, 16);
			this.lblMensagem.Name = "lblMensagem";
			this.lblMensagem.Size = new System.Drawing.Size(296, 16);
			this.lblMensagem.TabIndex = 0;
			this.lblMensagem.Text = "Selecione a rede para iniciar o m�dulo ADM";
			this.lblMensagem.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// cboRede
			// 
			this.cboRede.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cboRede.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.cboRede.Items.AddRange(new object[] {
														 "AMEX",
														 "REDECARD",
														 "TECBAN",
														 "VISANET"});
			this.cboRede.Location = new System.Drawing.Point(16, 48);
			this.cboRede.Name = "cboRede";
			this.cboRede.Size = new System.Drawing.Size(280, 21);
			this.cboRede.TabIndex = 1;
			this.cboRede.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cboRede_KeyPress);
			// 
			// btnCancelar
			// 
			this.btnCancelar.Image = ((System.Drawing.Image)(resources.GetObject("btnCancelar.Image")));
			this.btnCancelar.Location = new System.Drawing.Point(224, 136);
			this.btnCancelar.Name = "btnCancelar";
			this.btnCancelar.Size = new System.Drawing.Size(75, 20);
			this.btnCancelar.TabIndex = 3;
			this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
			// 
			// btnConfirmar
			// 
			this.btnConfirmar.Image = ((System.Drawing.Image)(resources.GetObject("btnConfirmar.Image")));
			this.btnConfirmar.Location = new System.Drawing.Point(136, 136);
			this.btnConfirmar.Name = "btnConfirmar";
			this.btnConfirmar.Size = new System.Drawing.Size(75, 20);
			this.btnConfirmar.TabIndex = 2;
			this.btnConfirmar.Click += new System.EventHandler(this.btnConfirmar_Click);
			// 
			// frmAdministrativo
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.ClientSize = new System.Drawing.Size(312, 166);
			this.Controls.Add(this.btnCancelar);
			this.Controls.Add(this.btnConfirmar);
			this.Controls.Add(this.cboRede);
			this.Controls.Add(this.lblMensagem);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmAdministrativo";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "frmAdministrativo";
			this.Load += new System.EventHandler(this.frmAdministrativo_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void btnCancelar_Click(object sender, System.EventArgs e)
		{
			DialogResult = DialogResult.Cancel;
			Close();
		}

		private void btnConfirmar_Click(object sender, System.EventArgs e)
		{
			DialogResult = DialogResult.OK;
			Close();
		}

		private void frmAdministrativo_Load(object sender, System.EventArgs e)
		{
			cboRede.SelectedIndex = 0;
		}

		private void cboRede_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if( e.KeyChar == (char)Keys.Enter)
			{
				e.Handled = true;
				SendKeys.Send("{TAB}");
			}
		}
	}
}
