using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace PDVCSharp
{
	/// <summary>
	/// Summary description for frmTroco.
	/// </summary>
	public class frmTroco : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnOk;
		private System.Windows.Forms.Label lblTroco;
		private System.Windows.Forms.Label lblValorTroco;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmTroco()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		public frmTroco(decimal troco)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			this.lblValorTroco.Text = troco.ToString("C");
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTroco));
			this.btnOk = new System.Windows.Forms.Button();
			this.lblTroco = new System.Windows.Forms.Label();
			this.lblValorTroco = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// btnOk
			// 
			this.btnOk.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(184)), ((System.Byte)(193)), ((System.Byte)(2)));
			this.btnOk.Image = ((System.Drawing.Image)(resources.GetObject("btnOk.Image")));
			this.btnOk.Location = new System.Drawing.Point(128, 120);
			this.btnOk.Name = "btnOk";
			this.btnOk.Size = new System.Drawing.Size(48, 23);
			this.btnOk.TabIndex = 0;
			this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
			// 
			// lblTroco
			// 
			this.lblTroco.AutoSize = true;
			this.lblTroco.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblTroco.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblTroco.Location = new System.Drawing.Point(104, 8);
			this.lblTroco.Name = "lblTroco";
			this.lblTroco.Size = new System.Drawing.Size(105, 33);
			this.lblTroco.TabIndex = 1;
			this.lblTroco.Text = "TROCO";
			// 
			// lblValorTroco
			// 
			this.lblValorTroco.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblValorTroco.Location = new System.Drawing.Point(56, 64);
			this.lblValorTroco.Name = "lblValorTroco";
			this.lblValorTroco.Size = new System.Drawing.Size(200, 33);
			this.lblValorTroco.TabIndex = 2;
			this.lblValorTroco.Text = "0,00";
			this.lblValorTroco.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// frmTroco
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(228)), ((System.Byte)(232)), ((System.Byte)(185)));
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.ClientSize = new System.Drawing.Size(312, 166);
			this.Controls.Add(this.lblValorTroco);
			this.Controls.Add(this.lblTroco);
			this.Controls.Add(this.btnOk);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmTroco";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "frmTroco";
			this.ResumeLayout(false);

		}
		#endregion

		private void btnOk_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}
}
