using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Text;

namespace PDVCSharp
{
	/// <summary>
	/// Summary description for frmCancelamentoItem.
	/// </summary>
	public class frmCancelamentoItem : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtNumeroItem;
		private System.Windows.Forms.Button btnConfirmar;
		private System.Windows.Forms.Button btnCancelar;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		frmVenda formVenda = null;

		public frmCancelamentoItem()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		public frmCancelamentoItem(frmVenda formVenda)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			this.formVenda = formVenda;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmCancelamentoItem));
			this.label1 = new System.Windows.Forms.Label();
			this.txtNumeroItem = new System.Windows.Forms.TextBox();
			this.btnConfirmar = new System.Windows.Forms.Button();
			this.btnCancelar = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.Location = new System.Drawing.Point(32, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(208, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "N�mero do item a ser cancelado:";
			// 
			// txtNumeroItem
			// 
			this.txtNumeroItem.Location = new System.Drawing.Point(32, 40);
			this.txtNumeroItem.MaxLength = 3;
			this.txtNumeroItem.Name = "txtNumeroItem";
			this.txtNumeroItem.Size = new System.Drawing.Size(40, 20);
			this.txtNumeroItem.TabIndex = 1;
			this.txtNumeroItem.Text = "";
			this.txtNumeroItem.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumeroItem_KeyPress);
			// 
			// btnConfirmar
			// 
			this.btnConfirmar.Image = ((System.Drawing.Image)(resources.GetObject("btnConfirmar.Image")));
			this.btnConfirmar.Location = new System.Drawing.Point(152, 128);
			this.btnConfirmar.Name = "btnConfirmar";
			this.btnConfirmar.Size = new System.Drawing.Size(77, 20);
			this.btnConfirmar.TabIndex = 2;
			this.btnConfirmar.Click += new System.EventHandler(this.btnConfirmar_Click);
			// 
			// btnCancelar
			// 
			this.btnCancelar.Image = ((System.Drawing.Image)(resources.GetObject("btnCancelar.Image")));
			this.btnCancelar.Location = new System.Drawing.Point(240, 128);
			this.btnCancelar.Name = "btnCancelar";
			this.btnCancelar.Size = new System.Drawing.Size(75, 20);
			this.btnCancelar.TabIndex = 3;
			this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
			// 
			// frmCancelamentoItem
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(228)), ((System.Byte)(232)), ((System.Byte)(185)));
			this.ClientSize = new System.Drawing.Size(344, 160);
			this.Controls.Add(this.btnCancelar);
			this.Controls.Add(this.btnConfirmar);
			this.Controls.Add(this.txtNumeroItem);
			this.Controls.Add(this.label1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmCancelamentoItem";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "frmCancelamentoItem";
			this.ResumeLayout(false);

		}
		#endregion

		private void btnCancelar_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void txtNumeroItem_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Tab)
			{
				this.btnConfirmar.Focus();
			}
			if ((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != (char)Keys.Back)
			{
				e.Handled = true;
				SendKeys.Send("");
			}
		}

		private void btnConfirmar_Click(object sender, System.EventArgs e)
		{
			try
			{
				//if (Convetthis.txtNumeroItem.Text.t
				frmVenda.printer.Cupom.CancelarItem(this.txtNumeroItem.Text);

				// Preparando o cupom para ser colocado na tela
				StringBuilder cupom = new StringBuilder(30);
				cupom.Append("Item Cancelado: ");
				cupom.Append(this.txtNumeroItem.Text.PadLeft(3,'0'));
				cupom.Append(decimal.Negate(frmVenda.printer.Cupom.UltimoItemCancelado.ValorTotal).ToString("N").PadLeft(32,' '));
				cupom.Append('\n');

				formVenda.AtualizarDisplay(cupom.ToString());
				this.Close();
			}
			catch (Exception erro)
			{
				MessageBox.Show(erro.Message,"Erro no Cancelamento do Item", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}
	}
}
