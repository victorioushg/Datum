using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace PDVCSharp
{
	/// <summary>
	/// Summary description for frmPrincipal.
	/// </summary>
	public class frmPrincipal : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnVendas;
		private System.Windows.Forms.Button button1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmPrincipal()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
//		/// <summary>
//		/// The main entry point for the application.
//		/// </summary>
//		[STAThread]
//		static void Main() 
//		{
//			Application.Run(new frmPrincipal());
//		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPrincipal));
			this.btnVendas = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnVendas
			// 
			this.btnVendas.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(228)), ((System.Byte)(232)), ((System.Byte)(185)));
			this.btnVendas.Location = new System.Drawing.Point(24, 32);
			this.btnVendas.Name = "btnVendas";
			this.btnVendas.Size = new System.Drawing.Size(96, 48);
			this.btnVendas.TabIndex = 0;
			this.btnVendas.Text = "&Vendas";
			this.btnVendas.Click += new System.EventHandler(this.btnVendas_Click);
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(228)), ((System.Byte)(232)), ((System.Byte)(185)));
			this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
			this.button1.Location = new System.Drawing.Point(280, 152);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(56, 40);
			this.button1.TabIndex = 1;
			// 
			// frmPrincipal
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.ClientSize = new System.Drawing.Size(344, 198);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.btnVendas);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmPrincipal";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "PDV-CSharp";
			this.ResumeLayout(false);

		}
		#endregion

		private void btnVendas_Click(object sender, System.EventArgs e)
		{
			frmVenda formVenda  = new frmVenda();

			this.Visible = false;
			formVenda.ShowDialog();
			this.Visible = true;
		}
	}
}
