using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using Bematech.Fiscal.TEF;

namespace PDVCSharp
{
	/// <summary>
	/// Summary description for frmMsgTEF.
	/// </summary>
	public class frmOperador : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnOk;
		internal System.Windows.Forms.Label lblMensagem;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		private string mensagem = "";

		public frmOperador(string mensagem)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			this.mensagem = mensagem;
			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmOperador));
			this.btnOk = new System.Windows.Forms.Button();
			this.lblMensagem = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// btnOk
			// 
			this.btnOk.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(184)), ((System.Byte)(193)), ((System.Byte)(2)));
			this.btnOk.Image = ((System.Drawing.Image)(resources.GetObject("btnOk.Image")));
			this.btnOk.Location = new System.Drawing.Point(248, 136);
			this.btnOk.Name = "btnOk";
			this.btnOk.Size = new System.Drawing.Size(56, 23);
			this.btnOk.TabIndex = 1;
			this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
			// 
			// lblMensagem
			// 
			this.lblMensagem.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(228)), ((System.Byte)(232)), ((System.Byte)(185)));
			this.lblMensagem.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblMensagem.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblMensagem.Location = new System.Drawing.Point(16, 24);
			this.lblMensagem.Name = "lblMensagem";
			this.lblMensagem.Size = new System.Drawing.Size(280, 96);
			this.lblMensagem.TabIndex = 2;
			this.lblMensagem.Text = "lblMensagem";
			// 
			// frmOperador
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(183)), ((System.Byte)(194)), ((System.Byte)(2)));
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.ClientSize = new System.Drawing.Size(312, 166);
			this.ControlBox = false;
			this.Controls.Add(this.lblMensagem);
			this.Controls.Add(this.btnOk);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frmOperador";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "frmMsgTEF";
			this.Load += new System.EventHandler(this.frmMsgTEF_Load);
			this.Activated += new System.EventHandler(this.frmMsgTEF_Activated);
			this.ResumeLayout(false);

		}
		#endregion

		private void btnOk_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		private void frmMsgTEF_Load(object sender, System.EventArgs e)
		{
			lblMensagem.Text = mensagem;
			//Application.DoEvents();
		}

		private void frmMsgTEF_Activated(object sender, System.EventArgs e)
		{
			btnOk.Focus();
		}
	}
}
