using System;
using System.IO;
using System.Drawing;
using System.Globalization;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;
using System.Text;
using Bematech;
using Bematech.Texto;
using Bematech.Fiscal.ECF;
using Bematech.Fiscal.ECF.CupomFiscal;
using Bematech.Fiscal.ECF.OperacoesNaoFiscais;
using Bematech.Fiscal.ECF.Informacoes;
using Bematech.Fiscal.ECF.Inicializacao;
using Bematech.Relatorios;
using Bematech.Relatorios.Sintegra;
using Bematech.Relatorios.Administrativos;
using Bematech.Fiscal.GerenciamentoDados;
using Bematech.Fiscal.TEF;

namespace PDVCSharp
{
	/// <summary>
	/// summary description for Form1.
	/// </summary>
	public class frmVenda : System.Windows.Forms.Form
	{
		#region Constants
		private const string TRANSACAO_APROVADA = "0";
		private const string CONSULTA_CDC		= "41";
		private const string CONSULTA_CHEQUE	= "70";
		#endregion Constants
		
		#region Members

		#region private

		private string cliche = null;
		private string inscricaoEstadual = null;
		private string CNPJ = null;
		private DataSet dsProdutos;
		private OleDbDataAdapter daProdutos;
		//private oleDbCommandBuilder oleDbCommandBuilder1;
		private OleDbConnection conexao;
		

		private System.Windows.Forms.TextBox txtCodigo;
		private System.Windows.Forms.TextBox txtQuantidade;
		private System.Windows.Forms.Label lblValorUnitario;
		private System.Windows.Forms.Label lblTotalVenda;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.TextBox txtValorPagamento;
		private System.Windows.Forms.ComboBox cboFormasPagamento;
		private System.Windows.Forms.Label lblProduto;
		private System.Windows.Forms.PictureBox pctMenus;
		private System.Windows.Forms.PictureBox pctDadosVenda;
		private System.Windows.Forms.PictureBox pctDescricaoProduto;
		private System.Windows.Forms.RichTextBox rtbCupom;
		private System.Windows.Forms.PictureBox pctCupom;
		private System.Windows.Forms.PictureBox pctDadoFechamentoVenda;			
		private System.Windows.Forms.Label lblCaixaLivre;
		private System.Windows.Forms.Label lblMenuIniciarVenda;
		private System.Windows.Forms.Label lblMenuAlterarQtde;
		private System.Windows.Forms.Label lblMenuFecharVenda;
		private System.Windows.Forms.Label lblMenuCancelarVenda;
		private System.Windows.Forms.Label lblMenuSair;
		private System.Windows.Forms.Label lblMenuCancelarItem;
		private System.Windows.Forms.Label lblTotalItem;
		private System.Windows.Forms.Label lblMenuAbrirCaixa;
		private System.Windows.Forms.Label lblMenuSuprimento;
		private System.Windows.Forms.Label lblMenuSangria;
		private System.Windows.Forms.GroupBox grbSeparador1;
		private System.Windows.Forms.GroupBox grbSeparador2;
		private System.Windows.Forms.Label lblMenuFecharCaixa;
		private System.Windows.Forms.Label lblMenuVendas;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.DateTimePicker dtInicial;
		private System.Windows.Forms.DateTimePicker dtFinal;
		private System.Windows.Forms.Label lbSintegra;
		private System.Windows.Forms.Panel pnlSintegra;
		private System.Windows.Forms.Label lblMenuAdministrativoTEF;

		#endregion private

		private System.Windows.Forms.Label lblMenuRelatorios;
		private System.Windows.Forms.GroupBox grbRelatorios;
		private System.Windows.Forms.RadioButton rbtTotalAliquota;
		private System.Windows.Forms.RadioButton rbtListaVendedores;
		private System.Windows.Forms.RadioButton rbtListaClientes;
		private System.Windows.Forms.RadioButton rbtVendasPorECF;
		private System.Windows.Forms.RadioButton rbtVendasPorVendedor;
		private System.Windows.Forms.RadioButton rbtVendasPorProduto;
		private System.Windows.Forms.RadioButton rbtVendasPorCliente;
		private System.Windows.Forms.RadioButton rbtVendasPeriodo;
		private System.Windows.Forms.RadioButton rbtListaProdutos;
		private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
		private System.Windows.Forms.Label lblRelatorios;
		private System.Windows.Forms.TextBox txtSintegra;

		
		#region internal
		
		internal static ImpressoraFiscal printer = ImpressoraFiscal.Construir();
		
		#endregion internal

		#endregion

		public frmVenda()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			//this.CarregaDataSet();
			CarregaDados();
		}

		
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmVenda());
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmVenda));
			this.txtCodigo = new System.Windows.Forms.TextBox();
			this.txtQuantidade = new System.Windows.Forms.TextBox();
			this.lblValorUnitario = new System.Windows.Forms.Label();
			this.lblTotalItem = new System.Windows.Forms.Label();
			this.lblTotalVenda = new System.Windows.Forms.Label();
			this.rtbCupom = new System.Windows.Forms.RichTextBox();
			this.lblMenuIniciarVenda = new System.Windows.Forms.Label();
			this.lblMenuAlterarQtde = new System.Windows.Forms.Label();
			this.lblMenuFecharVenda = new System.Windows.Forms.Label();
			this.lblMenuCancelarVenda = new System.Windows.Forms.Label();
			this.cboFormasPagamento = new System.Windows.Forms.ComboBox();
			this.txtValorPagamento = new System.Windows.Forms.TextBox();
			this.lblMenuSair = new System.Windows.Forms.Label();
			this.pctDadosVenda = new System.Windows.Forms.PictureBox();
			this.pctMenus = new System.Windows.Forms.PictureBox();
			this.pctCupom = new System.Windows.Forms.PictureBox();
			this.pctDescricaoProduto = new System.Windows.Forms.PictureBox();
			this.lblProduto = new System.Windows.Forms.Label();
			this.pctDadoFechamentoVenda = new System.Windows.Forms.PictureBox();
			this.lblCaixaLivre = new System.Windows.Forms.Label();
			this.lblMenuCancelarItem = new System.Windows.Forms.Label();
			this.lblMenuAbrirCaixa = new System.Windows.Forms.Label();
			this.grbSeparador1 = new System.Windows.Forms.GroupBox();
			this.lblMenuSuprimento = new System.Windows.Forms.Label();
			this.lblMenuSangria = new System.Windows.Forms.Label();
			this.grbSeparador2 = new System.Windows.Forms.GroupBox();
			this.lblMenuFecharCaixa = new System.Windows.Forms.Label();
			this.lblMenuVendas = new System.Windows.Forms.Label();
			this.pnlSintegra = new System.Windows.Forms.Panel();
			this.txtSintegra = new System.Windows.Forms.TextBox();
			this.button1 = new System.Windows.Forms.Button();
			this.dtFinal = new System.Windows.Forms.DateTimePicker();
			this.dtInicial = new System.Windows.Forms.DateTimePicker();
			this.lblRelatorios = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.grbRelatorios = new System.Windows.Forms.GroupBox();
			this.rbtTotalAliquota = new System.Windows.Forms.RadioButton();
			this.rbtListaVendedores = new System.Windows.Forms.RadioButton();
			this.rbtListaClientes = new System.Windows.Forms.RadioButton();
			this.rbtVendasPorECF = new System.Windows.Forms.RadioButton();
			this.rbtVendasPorVendedor = new System.Windows.Forms.RadioButton();
			this.rbtVendasPorProduto = new System.Windows.Forms.RadioButton();
			this.rbtVendasPorCliente = new System.Windows.Forms.RadioButton();
			this.rbtVendasPeriodo = new System.Windows.Forms.RadioButton();
			this.rbtListaProdutos = new System.Windows.Forms.RadioButton();
			this.lbSintegra = new System.Windows.Forms.Label();
			this.lblMenuAdministrativoTEF = new System.Windows.Forms.Label();
			this.lblMenuRelatorios = new System.Windows.Forms.Label();
			this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
			this.pnlSintegra.SuspendLayout();
			this.grbRelatorios.SuspendLayout();
			this.SuspendLayout();
			// 
			// txtCodigo
			// 
			this.txtCodigo.AllowDrop = true;
			this.txtCodigo.AutoSize = false;
			this.txtCodigo.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(228)), ((System.Byte)(232)), ((System.Byte)(185)));
			this.txtCodigo.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtCodigo.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtCodigo.Location = new System.Drawing.Point(616, 56);
			this.txtCodigo.Name = "txtCodigo";
			this.txtCodigo.Size = new System.Drawing.Size(144, 18);
			this.txtCodigo.TabIndex = 0;
			this.txtCodigo.Text = "";
			this.txtCodigo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCodigo_KeyPress);
			// 
			// txtQuantidade
			// 
			this.txtQuantidade.AllowDrop = true;
			this.txtQuantidade.AutoSize = false;
			this.txtQuantidade.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(228)), ((System.Byte)(232)), ((System.Byte)(185)));
			this.txtQuantidade.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtQuantidade.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtQuantidade.Location = new System.Drawing.Point(616, 136);
			this.txtQuantidade.Name = "txtQuantidade";
			this.txtQuantidade.Size = new System.Drawing.Size(144, 18);
			this.txtQuantidade.TabIndex = 1;
			this.txtQuantidade.Text = "1";
			this.txtQuantidade.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtQuantidade.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQuantidade_KeyPress);
			// 
			// lblValorUnitario
			// 
			this.lblValorUnitario.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(228)), ((System.Byte)(232)), ((System.Byte)(185)));
			this.lblValorUnitario.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblValorUnitario.Location = new System.Drawing.Point(616, 224);
			this.lblValorUnitario.Name = "lblValorUnitario";
			this.lblValorUnitario.Size = new System.Drawing.Size(144, 16);
			this.lblValorUnitario.TabIndex = 2;
			this.lblValorUnitario.Text = "0,00";
			this.lblValorUnitario.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// lblTotalItem
			// 
			this.lblTotalItem.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(228)), ((System.Byte)(232)), ((System.Byte)(185)));
			this.lblTotalItem.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblTotalItem.Location = new System.Drawing.Point(616, 312);
			this.lblTotalItem.Name = "lblTotalItem";
			this.lblTotalItem.Size = new System.Drawing.Size(144, 16);
			this.lblTotalItem.TabIndex = 3;
			this.lblTotalItem.Text = "0,00";
			this.lblTotalItem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// lblTotalVenda
			// 
			this.lblTotalVenda.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(228)), ((System.Byte)(232)), ((System.Byte)(185)));
			this.lblTotalVenda.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblTotalVenda.Location = new System.Drawing.Point(616, 392);
			this.lblTotalVenda.Name = "lblTotalVenda";
			this.lblTotalVenda.Size = new System.Drawing.Size(144, 16);
			this.lblTotalVenda.TabIndex = 4;
			this.lblTotalVenda.Text = "0,00";
			this.lblTotalVenda.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// rtbCupom
			// 
			this.rtbCupom.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.rtbCupom.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.rtbCupom.Location = new System.Drawing.Point(192, 32);
			this.rtbCupom.Name = "rtbCupom";
			this.rtbCupom.ReadOnly = true;
			this.rtbCupom.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
			this.rtbCupom.Size = new System.Drawing.Size(376, 384);
			this.rtbCupom.TabIndex = 6;
			this.rtbCupom.TabStop = false;
			this.rtbCupom.Text = "";
			this.rtbCupom.WordWrap = false;
			this.rtbCupom.MouseDown += new System.Windows.Forms.MouseEventHandler(this.rtbCupom_MouseDown);
			// 
			// lblMenuIniciarVenda
			// 
			this.lblMenuIniciarVenda.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(218)), ((System.Byte)(223)), ((System.Byte)(149)));
			this.lblMenuIniciarVenda.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblMenuIniciarVenda.ForeColor = System.Drawing.Color.Black;
			this.lblMenuIniciarVenda.Location = new System.Drawing.Point(16, 64);
			this.lblMenuIniciarVenda.Name = "lblMenuIniciarVenda";
			this.lblMenuIniciarVenda.Size = new System.Drawing.Size(136, 16);
			this.lblMenuIniciarVenda.TabIndex = 7;
			this.lblMenuIniciarVenda.Text = "F2 - Iniciar Venda";
			// 
			// lblMenuAlterarQtde
			// 
			this.lblMenuAlterarQtde.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(218)), ((System.Byte)(223)), ((System.Byte)(149)));
			this.lblMenuAlterarQtde.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblMenuAlterarQtde.ForeColor = System.Drawing.Color.Black;
			this.lblMenuAlterarQtde.Location = new System.Drawing.Point(16, 88);
			this.lblMenuAlterarQtde.Name = "lblMenuAlterarQtde";
			this.lblMenuAlterarQtde.Size = new System.Drawing.Size(136, 16);
			this.lblMenuAlterarQtde.TabIndex = 8;
			this.lblMenuAlterarQtde.Text = "F3 - Alterar Qtde";
			// 
			// lblMenuFecharVenda
			// 
			this.lblMenuFecharVenda.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(218)), ((System.Byte)(223)), ((System.Byte)(149)));
			this.lblMenuFecharVenda.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblMenuFecharVenda.ForeColor = System.Drawing.Color.Black;
			this.lblMenuFecharVenda.Location = new System.Drawing.Point(16, 136);
			this.lblMenuFecharVenda.Name = "lblMenuFecharVenda";
			this.lblMenuFecharVenda.Size = new System.Drawing.Size(136, 16);
			this.lblMenuFecharVenda.TabIndex = 9;
			this.lblMenuFecharVenda.Text = "F5 - Fechar Venda";
			// 
			// lblMenuCancelarVenda
			// 
			this.lblMenuCancelarVenda.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(218)), ((System.Byte)(223)), ((System.Byte)(149)));
			this.lblMenuCancelarVenda.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblMenuCancelarVenda.ForeColor = System.Drawing.Color.Black;
			this.lblMenuCancelarVenda.Location = new System.Drawing.Point(16, 160);
			this.lblMenuCancelarVenda.Name = "lblMenuCancelarVenda";
			this.lblMenuCancelarVenda.Size = new System.Drawing.Size(136, 16);
			this.lblMenuCancelarVenda.TabIndex = 10;
			this.lblMenuCancelarVenda.Text = "F6 - Cancelar Venda";
			// 
			// cboFormasPagamento
			// 
			this.cboFormasPagamento.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(228)), ((System.Byte)(232)), ((System.Byte)(185)));
			this.cboFormasPagamento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cboFormasPagamento.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.cboFormasPagamento.Items.AddRange(new object[] {
																	"Dinheiro",
																	"Amex",
																	"Redecard",
																	"Visa",
																	"Tecban",
																	"Cheque",
																	"Cheque Tecban",
																	"Ticket"});
			this.cboFormasPagamento.Location = new System.Drawing.Point(600, 56);
			this.cboFormasPagamento.Name = "cboFormasPagamento";
			this.cboFormasPagamento.Size = new System.Drawing.Size(176, 26);
			this.cboFormasPagamento.TabIndex = 11;
			this.cboFormasPagamento.Visible = false;
			this.cboFormasPagamento.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cboFormasPagamento_KeyPress);
			// 
			// txtValorPagamento
			// 
			this.txtValorPagamento.AllowDrop = true;
			this.txtValorPagamento.AutoSize = false;
			this.txtValorPagamento.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(228)), ((System.Byte)(232)), ((System.Byte)(185)));
			this.txtValorPagamento.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtValorPagamento.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtValorPagamento.Location = new System.Drawing.Point(616, 136);
			this.txtValorPagamento.Name = "txtValorPagamento";
			this.txtValorPagamento.Size = new System.Drawing.Size(144, 18);
			this.txtValorPagamento.TabIndex = 12;
			this.txtValorPagamento.Text = "0,00";
			this.txtValorPagamento.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.txtValorPagamento.Visible = false;
			this.txtValorPagamento.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtValorPagamento_KeyPress);
			// 
			// lblMenuSair
			// 
			this.lblMenuSair.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(218)), ((System.Byte)(223)), ((System.Byte)(149)));
			this.lblMenuSair.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblMenuSair.ForeColor = System.Drawing.Color.Black;
			this.lblMenuSair.Location = new System.Drawing.Point(16, 296);
			this.lblMenuSair.Name = "lblMenuSair";
			this.lblMenuSair.Size = new System.Drawing.Size(136, 16);
			this.lblMenuSair.TabIndex = 13;
			this.lblMenuSair.Text = "F10 - Sair";
			// 
			// pctDadosVenda
			// 
			this.pctDadosVenda.Image = ((System.Drawing.Image)(resources.GetObject("pctDadosVenda.Image")));
			this.pctDadosVenda.Location = new System.Drawing.Point(584, 8);
			this.pctDadosVenda.Name = "pctDadosVenda";
			this.pctDadosVenda.Size = new System.Drawing.Size(217, 439);
			this.pctDadosVenda.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pctDadosVenda.TabIndex = 14;
			this.pctDadosVenda.TabStop = false;
			// 
			// pctMenus
			// 
			this.pctMenus.Image = ((System.Drawing.Image)(resources.GetObject("pctMenus.Image")));
			this.pctMenus.Location = new System.Drawing.Point(8, 8);
			this.pctMenus.Name = "pctMenus";
			this.pctMenus.Size = new System.Drawing.Size(169, 582);
			this.pctMenus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pctMenus.TabIndex = 15;
			this.pctMenus.TabStop = false;
			// 
			// pctCupom
			// 
			this.pctCupom.Image = ((System.Drawing.Image)(resources.GetObject("pctCupom.Image")));
			this.pctCupom.Location = new System.Drawing.Point(176, 8);
			this.pctCupom.Name = "pctCupom";
			this.pctCupom.Size = new System.Drawing.Size(410, 440);
			this.pctCupom.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pctCupom.TabIndex = 16;
			this.pctCupom.TabStop = false;
			// 
			// pctDescricaoProduto
			// 
			this.pctDescricaoProduto.Image = ((System.Drawing.Image)(resources.GetObject("pctDescricaoProduto.Image")));
			this.pctDescricaoProduto.Location = new System.Drawing.Point(176, 456);
			this.pctDescricaoProduto.Name = "pctDescricaoProduto";
			this.pctDescricaoProduto.Size = new System.Drawing.Size(621, 134);
			this.pctDescricaoProduto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pctDescricaoProduto.TabIndex = 17;
			this.pctDescricaoProduto.TabStop = false;
			// 
			// lblProduto
			// 
			this.lblProduto.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(228)), ((System.Byte)(232)), ((System.Byte)(185)));
			this.lblProduto.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblProduto.Location = new System.Drawing.Point(192, 512);
			this.lblProduto.Name = "lblProduto";
			this.lblProduto.Size = new System.Drawing.Size(584, 48);
			this.lblProduto.TabIndex = 18;
			this.lblProduto.Text = "lblProduto";
			// 
			// pctDadoFechamentoVenda
			// 
			this.pctDadoFechamentoVenda.Image = ((System.Drawing.Image)(resources.GetObject("pctDadoFechamentoVenda.Image")));
			this.pctDadoFechamentoVenda.Location = new System.Drawing.Point(584, 8);
			this.pctDadoFechamentoVenda.Name = "pctDadoFechamentoVenda";
			this.pctDadoFechamentoVenda.Size = new System.Drawing.Size(217, 208);
			this.pctDadoFechamentoVenda.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.pctDadoFechamentoVenda.TabIndex = 19;
			this.pctDadoFechamentoVenda.TabStop = false;
			// 
			// lblCaixaLivre
			// 
			this.lblCaixaLivre.BackColor = System.Drawing.Color.Transparent;
			this.lblCaixaLivre.Font = new System.Drawing.Font("Verdana", 44.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblCaixaLivre.ForeColor = System.Drawing.Color.White;
			this.lblCaixaLivre.Location = new System.Drawing.Point(192, 264);
			this.lblCaixaLivre.Name = "lblCaixaLivre";
			this.lblCaixaLivre.Size = new System.Drawing.Size(584, 81);
			this.lblCaixaLivre.TabIndex = 25;
			this.lblCaixaLivre.Text = "CAIXA LIVRE";
			this.lblCaixaLivre.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblMenuCancelarItem
			// 
			this.lblMenuCancelarItem.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(218)), ((System.Byte)(223)), ((System.Byte)(149)));
			this.lblMenuCancelarItem.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblMenuCancelarItem.ForeColor = System.Drawing.Color.Black;
			this.lblMenuCancelarItem.Location = new System.Drawing.Point(16, 112);
			this.lblMenuCancelarItem.Name = "lblMenuCancelarItem";
			this.lblMenuCancelarItem.Size = new System.Drawing.Size(136, 16);
			this.lblMenuCancelarItem.TabIndex = 26;
			this.lblMenuCancelarItem.Text = "F4 - Cancelar Item";
			// 
			// lblMenuAbrirCaixa
			// 
			this.lblMenuAbrirCaixa.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(218)), ((System.Byte)(223)), ((System.Byte)(149)));
			this.lblMenuAbrirCaixa.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblMenuAbrirCaixa.ForeColor = System.Drawing.Color.Black;
			this.lblMenuAbrirCaixa.Location = new System.Drawing.Point(16, 64);
			this.lblMenuAbrirCaixa.Name = "lblMenuAbrirCaixa";
			this.lblMenuAbrirCaixa.Size = new System.Drawing.Size(152, 16);
			this.lblMenuAbrirCaixa.TabIndex = 27;
			this.lblMenuAbrirCaixa.Text = "Alt + F2 - Abrir Caixa";
			// 
			// grbSeparador1
			// 
			this.grbSeparador1.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(218)), ((System.Byte)(223)), ((System.Byte)(149)));
			this.grbSeparador1.Location = new System.Drawing.Point(16, 184);
			this.grbSeparador1.Name = "grbSeparador1";
			this.grbSeparador1.Size = new System.Drawing.Size(144, 8);
			this.grbSeparador1.TabIndex = 28;
			this.grbSeparador1.TabStop = false;
			// 
			// lblMenuSuprimento
			// 
			this.lblMenuSuprimento.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(218)), ((System.Byte)(223)), ((System.Byte)(149)));
			this.lblMenuSuprimento.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblMenuSuprimento.ForeColor = System.Drawing.Color.Black;
			this.lblMenuSuprimento.Location = new System.Drawing.Point(16, 232);
			this.lblMenuSuprimento.Name = "lblMenuSuprimento";
			this.lblMenuSuprimento.Size = new System.Drawing.Size(136, 16);
			this.lblMenuSuprimento.TabIndex = 29;
			this.lblMenuSuprimento.Text = "F8 - Suprimento";
			// 
			// lblMenuSangria
			// 
			this.lblMenuSangria.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(218)), ((System.Byte)(223)), ((System.Byte)(149)));
			this.lblMenuSangria.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblMenuSangria.ForeColor = System.Drawing.Color.Black;
			this.lblMenuSangria.Location = new System.Drawing.Point(16, 256);
			this.lblMenuSangria.Name = "lblMenuSangria";
			this.lblMenuSangria.Size = new System.Drawing.Size(136, 16);
			this.lblMenuSangria.TabIndex = 30;
			this.lblMenuSangria.Text = "F9 - Sangria";
			// 
			// grbSeparador2
			// 
			this.grbSeparador2.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(218)), ((System.Byte)(223)), ((System.Byte)(149)));
			this.grbSeparador2.Location = new System.Drawing.Point(16, 280);
			this.grbSeparador2.Name = "grbSeparador2";
			this.grbSeparador2.Size = new System.Drawing.Size(144, 8);
			this.grbSeparador2.TabIndex = 31;
			this.grbSeparador2.TabStop = false;
			// 
			// lblMenuFecharCaixa
			// 
			this.lblMenuFecharCaixa.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(218)), ((System.Byte)(223)), ((System.Byte)(149)));
			this.lblMenuFecharCaixa.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblMenuFecharCaixa.ForeColor = System.Drawing.Color.Black;
			this.lblMenuFecharCaixa.Location = new System.Drawing.Point(16, 88);
			this.lblMenuFecharCaixa.Name = "lblMenuFecharCaixa";
			this.lblMenuFecharCaixa.Size = new System.Drawing.Size(152, 16);
			this.lblMenuFecharCaixa.TabIndex = 32;
			this.lblMenuFecharCaixa.Text = "Alt + F3 - Fechar Caixa";
			// 
			// lblMenuVendas
			// 
			this.lblMenuVendas.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(218)), ((System.Byte)(223)), ((System.Byte)(149)));
			this.lblMenuVendas.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblMenuVendas.ForeColor = System.Drawing.Color.Black;
			this.lblMenuVendas.Location = new System.Drawing.Point(16, 112);
			this.lblMenuVendas.Name = "lblMenuVendas";
			this.lblMenuVendas.Size = new System.Drawing.Size(152, 16);
			this.lblMenuVendas.TabIndex = 33;
			this.lblMenuVendas.Text = "Alt + F5 - Vendas";
			// 
			// pnlSintegra
			// 
			this.pnlSintegra.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(183)), ((System.Byte)(194)), ((System.Byte)(2)));
			this.pnlSintegra.Controls.Add(this.txtSintegra);
			this.pnlSintegra.Controls.Add(this.button1);
			this.pnlSintegra.Controls.Add(this.dtFinal);
			this.pnlSintegra.Controls.Add(this.dtInicial);
			this.pnlSintegra.Controls.Add(this.lblRelatorios);
			this.pnlSintegra.Controls.Add(this.label3);
			this.pnlSintegra.Controls.Add(this.label2);
			this.pnlSintegra.Controls.Add(this.grbRelatorios);
			this.pnlSintegra.Location = new System.Drawing.Point(176, 8);
			this.pnlSintegra.Name = "pnlSintegra";
			this.pnlSintegra.Size = new System.Drawing.Size(616, 576);
			this.pnlSintegra.TabIndex = 34;
			this.pnlSintegra.Visible = false;
			// 
			// txtSintegra
			// 
			this.txtSintegra.Location = new System.Drawing.Point(16, 112);
			this.txtSintegra.Multiline = true;
			this.txtSintegra.Name = "txtSintegra";
			this.txtSintegra.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtSintegra.Size = new System.Drawing.Size(584, 448);
			this.txtSintegra.TabIndex = 10;
			this.txtSintegra.Text = "";
			this.txtSintegra.WordWrap = false;
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(224)), ((System.Byte)(224)), ((System.Byte)(224)));
			this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.button1.Location = new System.Drawing.Point(280, 68);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(96, 24);
			this.button1.TabIndex = 7;
			this.button1.Text = "Gerar";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// dtFinal
			// 
			this.dtFinal.CustomFormat = "dd/MM/yyyy";
			this.dtFinal.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dtFinal.Location = new System.Drawing.Point(152, 72);
			this.dtFinal.Name = "dtFinal";
			this.dtFinal.Size = new System.Drawing.Size(104, 20);
			this.dtFinal.TabIndex = 5;
			// 
			// dtInicial
			// 
			this.dtInicial.CustomFormat = "dd/MM/yyyy";
			this.dtInicial.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
			this.dtInicial.Location = new System.Drawing.Point(24, 72);
			this.dtInicial.Name = "dtInicial";
			this.dtInicial.Size = new System.Drawing.Size(104, 20);
			this.dtInicial.TabIndex = 3;
			// 
			// lblRelatorios
			// 
			this.lblRelatorios.BackColor = System.Drawing.Color.Transparent;
			this.lblRelatorios.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblRelatorios.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(228)), ((System.Byte)(232)), ((System.Byte)(185)));
			this.lblRelatorios.Location = new System.Drawing.Point(16, 8);
			this.lblRelatorios.Name = "lblRelatorios";
			this.lblRelatorios.Size = new System.Drawing.Size(272, 40);
			this.lblRelatorios.TabIndex = 0;
			this.lblRelatorios.Text = "Relat�rio Sintegra";
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
			this.label3.Location = new System.Drawing.Point(152, 56);
			this.label3.Name = "label3";
			this.label3.TabIndex = 6;
			this.label3.Text = "Data Final";
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
			this.label2.Location = new System.Drawing.Point(24, 56);
			this.label2.Name = "label2";
			this.label2.TabIndex = 4;
			this.label2.Text = "Data Inicial";
			// 
			// grbRelatorios
			// 
			this.grbRelatorios.BackColor = System.Drawing.Color.Transparent;
			this.grbRelatorios.Controls.Add(this.rbtTotalAliquota);
			this.grbRelatorios.Controls.Add(this.rbtListaVendedores);
			this.grbRelatorios.Controls.Add(this.rbtListaClientes);
			this.grbRelatorios.Controls.Add(this.rbtVendasPorECF);
			this.grbRelatorios.Controls.Add(this.rbtVendasPorVendedor);
			this.grbRelatorios.Controls.Add(this.rbtVendasPorProduto);
			this.grbRelatorios.Controls.Add(this.rbtVendasPorCliente);
			this.grbRelatorios.Controls.Add(this.rbtVendasPeriodo);
			this.grbRelatorios.Controls.Add(this.rbtListaProdutos);
			this.grbRelatorios.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.grbRelatorios.Location = new System.Drawing.Point(16, 152);
			this.grbRelatorios.Name = "grbRelatorios";
			this.grbRelatorios.Size = new System.Drawing.Size(584, 408);
			this.grbRelatorios.TabIndex = 9;
			this.grbRelatorios.TabStop = false;
			this.grbRelatorios.Text = "Relat�rios";
			// 
			// rbtTotalAliquota
			// 
			this.rbtTotalAliquota.BackColor = System.Drawing.Color.Transparent;
			this.rbtTotalAliquota.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.rbtTotalAliquota.Location = new System.Drawing.Point(352, 232);
			this.rbtTotalAliquota.Name = "rbtTotalAliquota";
			this.rbtTotalAliquota.Size = new System.Drawing.Size(128, 24);
			this.rbtTotalAliquota.TabIndex = 8;
			this.rbtTotalAliquota.Text = "Total al�quota";
			// 
			// rbtListaVendedores
			// 
			this.rbtListaVendedores.BackColor = System.Drawing.Color.Transparent;
			this.rbtListaVendedores.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.rbtListaVendedores.Location = new System.Drawing.Point(352, 200);
			this.rbtListaVendedores.Name = "rbtListaVendedores";
			this.rbtListaVendedores.Size = new System.Drawing.Size(128, 24);
			this.rbtListaVendedores.TabIndex = 7;
			this.rbtListaVendedores.Text = "Vendedores";
			// 
			// rbtListaClientes
			// 
			this.rbtListaClientes.BackColor = System.Drawing.Color.Transparent;
			this.rbtListaClientes.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.rbtListaClientes.Location = new System.Drawing.Point(352, 168);
			this.rbtListaClientes.Name = "rbtListaClientes";
			this.rbtListaClientes.Size = new System.Drawing.Size(128, 24);
			this.rbtListaClientes.TabIndex = 6;
			this.rbtListaClientes.Text = "Clientes";
			// 
			// rbtVendasPorECF
			// 
			this.rbtVendasPorECF.BackColor = System.Drawing.Color.Transparent;
			this.rbtVendasPorECF.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.rbtVendasPorECF.Location = new System.Drawing.Point(88, 264);
			this.rbtVendasPorECF.Name = "rbtVendasPorECF";
			this.rbtVendasPorECF.Size = new System.Drawing.Size(160, 24);
			this.rbtVendasPorECF.TabIndex = 5;
			this.rbtVendasPorECF.Text = "Vendas por ECF";
			// 
			// rbtVendasPorVendedor
			// 
			this.rbtVendasPorVendedor.BackColor = System.Drawing.Color.Transparent;
			this.rbtVendasPorVendedor.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.rbtVendasPorVendedor.Location = new System.Drawing.Point(88, 232);
			this.rbtVendasPorVendedor.Name = "rbtVendasPorVendedor";
			this.rbtVendasPorVendedor.Size = new System.Drawing.Size(160, 24);
			this.rbtVendasPorVendedor.TabIndex = 4;
			this.rbtVendasPorVendedor.Text = "Vendas por vendedor";
			// 
			// rbtVendasPorProduto
			// 
			this.rbtVendasPorProduto.BackColor = System.Drawing.Color.Transparent;
			this.rbtVendasPorProduto.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.rbtVendasPorProduto.Location = new System.Drawing.Point(88, 200);
			this.rbtVendasPorProduto.Name = "rbtVendasPorProduto";
			this.rbtVendasPorProduto.Size = new System.Drawing.Size(160, 24);
			this.rbtVendasPorProduto.TabIndex = 3;
			this.rbtVendasPorProduto.Text = "Vendas por produto";
			// 
			// rbtVendasPorCliente
			// 
			this.rbtVendasPorCliente.BackColor = System.Drawing.Color.Transparent;
			this.rbtVendasPorCliente.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.rbtVendasPorCliente.Location = new System.Drawing.Point(88, 168);
			this.rbtVendasPorCliente.Name = "rbtVendasPorCliente";
			this.rbtVendasPorCliente.Size = new System.Drawing.Size(160, 24);
			this.rbtVendasPorCliente.TabIndex = 2;
			this.rbtVendasPorCliente.Text = "Vendas por cliente";
			// 
			// rbtVendasPeriodo
			// 
			this.rbtVendasPeriodo.BackColor = System.Drawing.Color.Transparent;
			this.rbtVendasPeriodo.Checked = true;
			this.rbtVendasPeriodo.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.rbtVendasPeriodo.Location = new System.Drawing.Point(88, 136);
			this.rbtVendasPeriodo.Name = "rbtVendasPeriodo";
			this.rbtVendasPeriodo.Size = new System.Drawing.Size(160, 24);
			this.rbtVendasPeriodo.TabIndex = 1;
			this.rbtVendasPeriodo.TabStop = true;
			this.rbtVendasPeriodo.Text = "Vendas por per�odo";
			// 
			// rbtListaProdutos
			// 
			this.rbtListaProdutos.BackColor = System.Drawing.Color.Transparent;
			this.rbtListaProdutos.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.rbtListaProdutos.Location = new System.Drawing.Point(352, 136);
			this.rbtListaProdutos.Name = "rbtListaProdutos";
			this.rbtListaProdutos.Size = new System.Drawing.Size(128, 24);
			this.rbtListaProdutos.TabIndex = 0;
			this.rbtListaProdutos.Text = "Produtos";
			// 
			// lbSintegra
			// 
			this.lbSintegra.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(218)), ((System.Byte)(223)), ((System.Byte)(149)));
			this.lbSintegra.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lbSintegra.ForeColor = System.Drawing.Color.Black;
			this.lbSintegra.Location = new System.Drawing.Point(16, 136);
			this.lbSintegra.Name = "lbSintegra";
			this.lbSintegra.Size = new System.Drawing.Size(152, 16);
			this.lbSintegra.TabIndex = 35;
			this.lbSintegra.Text = "Alt + F7 - Sintegra";
			// 
			// lblMenuAdministrativoTEF
			// 
			this.lblMenuAdministrativoTEF.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(218)), ((System.Byte)(223)), ((System.Byte)(149)));
			this.lblMenuAdministrativoTEF.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblMenuAdministrativoTEF.ForeColor = System.Drawing.Color.Black;
			this.lblMenuAdministrativoTEF.Location = new System.Drawing.Point(16, 208);
			this.lblMenuAdministrativoTEF.Name = "lblMenuAdministrativoTEF";
			this.lblMenuAdministrativoTEF.Size = new System.Drawing.Size(136, 16);
			this.lblMenuAdministrativoTEF.TabIndex = 36;
			this.lblMenuAdministrativoTEF.Text = "F7 - Adm TEF";
			// 
			// lblMenuRelatorios
			// 
			this.lblMenuRelatorios.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(218)), ((System.Byte)(223)), ((System.Byte)(149)));
			this.lblMenuRelatorios.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblMenuRelatorios.ForeColor = System.Drawing.Color.Black;
			this.lblMenuRelatorios.Location = new System.Drawing.Point(16, 160);
			this.lblMenuRelatorios.Name = "lblMenuRelatorios";
			this.lblMenuRelatorios.Size = new System.Drawing.Size(152, 16);
			this.lblMenuRelatorios.TabIndex = 37;
			this.lblMenuRelatorios.Text = "Alt + F8 - Relat�rios";
			// 
			// printPreviewDialog1
			// 
			this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
			this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
			this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
			this.printPreviewDialog1.Enabled = true;
			this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
			this.printPreviewDialog1.Location = new System.Drawing.Point(65, 100);
			this.printPreviewDialog1.MinimumSize = new System.Drawing.Size(375, 250);
			this.printPreviewDialog1.Name = "printPreviewDialog1";
			this.printPreviewDialog1.TransparencyKey = System.Drawing.Color.Empty;
			this.printPreviewDialog1.Visible = false;
			// 
			// frmVenda
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(228)), ((System.Byte)(232)), ((System.Byte)(185)));
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.ClientSize = new System.Drawing.Size(800, 600);
			this.ControlBox = false;
			this.Controls.Add(this.lblMenuCancelarVenda);
			this.Controls.Add(this.lblMenuRelatorios);
			this.Controls.Add(this.lblMenuAdministrativoTEF);
			this.Controls.Add(this.pnlSintegra);
			this.Controls.Add(this.lblMenuCancelarItem);
			this.Controls.Add(this.lblMenuVendas);
			this.Controls.Add(this.grbSeparador2);
			this.Controls.Add(this.lblMenuSangria);
			this.Controls.Add(this.lblMenuSuprimento);
			this.Controls.Add(this.grbSeparador1);
			this.Controls.Add(this.txtCodigo);
			this.Controls.Add(this.txtValorPagamento);
			this.Controls.Add(this.txtQuantidade);
			this.Controls.Add(this.lblProduto);
			this.Controls.Add(this.lblMenuSair);
			this.Controls.Add(this.cboFormasPagamento);
			this.Controls.Add(this.lblMenuFecharVenda);
			this.Controls.Add(this.lblMenuAlterarQtde);
			this.Controls.Add(this.lblMenuIniciarVenda);
			this.Controls.Add(this.rtbCupom);
			this.Controls.Add(this.lblTotalVenda);
			this.Controls.Add(this.lblTotalItem);
			this.Controls.Add(this.lblValorUnitario);
			this.Controls.Add(this.pctCupom);
			this.Controls.Add(this.pctDescricaoProduto);
			this.Controls.Add(this.pctDadosVenda);
			this.Controls.Add(this.pctDadoFechamentoVenda);
			this.Controls.Add(this.lblMenuFecharCaixa);
			this.Controls.Add(this.lblMenuAbrirCaixa);
			this.Controls.Add(this.lbSintegra);
			this.Controls.Add(this.lblCaixaLivre);
			this.Controls.Add(this.pctMenus);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "frmVenda";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "PDV-CSharp";
			this.Load += new System.EventHandler(this.frmVenda_Load);
			this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmVenda_KeyUp);
			this.pnlSintegra.ResumeLayout(false);
			this.grbRelatorios.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Le todos os produtos cadastrados no banco de dados e armazena
		/// em um dataset. 
		/// </summary>
		private void CarregaDados()
		{
			// efetua conexao com o banco de dados 
			string stringConexao = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Application.StartupPath + @"\ExemDotNET.mdb";
			try
			{
				conexao = new OleDbConnection(stringConexao);
				conexao.Open();
			}
			catch (Exception e)
			{
				MessageBox.Show("Erro ao acessar a base de dados : " + e.ToString());
				this.Dispose();
			}
			
			string sqlStr = "SELECT cod_barras, cod_produto, descricao, tipo_aliquota, " +
				"unidade_medida, valor_aliquota, valor_unitario FROM produto";
			
			daProdutos = new OleDbDataAdapter(sqlStr, conexao);
			daProdutos.SelectCommand.CommandText = sqlStr;
			//oleDbCommandBuilder1 = new OleDbCommandBuilder(daProdutos);
			dsProdutos = new DataSet();
			daProdutos.Fill(dsProdutos,"produto");
		}


		private void txtCodigo_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)Keys.Enter)
			{
				if( txtCodigo.Text == "")
				{
					this.txtQuantidade.Focus();
					return;
				}

				string tmpCodigo = txtCodigo.Text.PadLeft(13,'0');
				DataRow[] produtos;
				produtos = dsProdutos.Tables["Produto"].Select("COD_BARRAS = " + tmpCodigo);
				if (produtos.Length == 0)
				{
					MessageBox.Show("Produto n�o cadastrado!", "Exemplo C#", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					this.txtCodigo.Text = "";
					this.txtCodigo.Focus();
				}
				else
				{
					DataRow produto = produtos[0];
					try
					{
						Item item = new Item();

						item.Descricao = produto["descricao"].ToString();
						item.Codigo = produto["cod_barras"].ToString();
						if ((produto["TIPO_ALIQUOTA"].ToString() == "ICMS") || 
							(produto["TIPO_ALIQUOTA"].ToString() == "ISS") )
							item.Aliquota = produto["VALOR_ALIQUOTA"].ToString();
						else
							item.Aliquota = produto["TIPO_ALIQUOTA"].ToString();
						
						item.ValorUnitario = decimal.Parse(produto["VALOR_UNITARIO"].ToString());
						item.Quantidade = int.Parse(txtQuantidade.Text);

						printer.Cupom.Vender(item);

						// atualiza o display
						StringBuilder cupom = new StringBuilder(200);
						cupom.AppendFormat("{0:000}", item.NumeroSequencial);
						cupom.Append(' ',2);
						cupom.AppendFormat("{0,-29:G}", produto["DESCRICAO"]);
						cupom.Append(' ',2);
						cupom.AppendFormat(item.Quantidade.ToString("G").PadLeft(3, ' '));
						cupom.AppendFormat(item.ValorTotal.ToString("N").PadLeft(12, ' '));
						cupom.Append('\n');

						this.AtualizarDisplay(cupom.ToString());
						Application.DoEvents();

						this.lblValorUnitario.Text = item.ValorUnitario.ToString("N");
						this.lblTotalItem.Text = item.ValorTotal.ToString("N");
						this.lblProduto.Text = produto["DESCRICAO"].ToString();
						this.lblTotalVenda.Text = printer.Cupom.SubTotal.ToString("N");
						this.txtQuantidade.Text = "1"; // volta quantidade para 1
						this.txtCodigo.Text = "";
						this.lblMenuCancelarItem.Enabled = true;
						this.lblMenuFecharVenda.Enabled = true;

					}
					catch (BematechException erro)
					{
						MessageBox.Show(erro.Message, "Erro no cancelamento da venda", MessageBoxButtons.OK, MessageBoxIcon.Error);
					}
				
				}
			}
		}

		private void frmVenda_KeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			string msgErro = "PDV-CSharp";
			try
			{
				if (e.Shift || e.Control || e.Alt)
				{
					// Alt + F2 - Abrir o caixa
					if (e.Alt && e.KeyCode == Keys.F2 && this.lblMenuAbrirCaixa.Enabled == true)
					{
						frmSangriaSuprimento formSuprimento = new frmSangriaSuprimento(this);
						formSuprimento.Tag = "ABERTURA CAIXA";
						formSuprimento.ShowDialog();
					}
					// Alt + F3 - Fechar o caixa
					if (e.Alt && e.KeyCode == Keys.F3 && this.lblMenuFecharCaixa.Enabled == true)
					{
						DialogResult result;
					
						result = MessageBox.Show("O Fechamento do caixa emite a redu��o Z. Ap�s a emiss�o\n da redu��o Z a impressora ficar� travada at� �s 23:59 hs.\n Confirma o fechamento do caixa?", "Aten��o", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
						if (result == DialogResult.Yes)
						{
							frmSangriaSuprimento formSangria = new frmSangriaSuprimento(this);
							formSangria.Tag = "FECHAMENTO CAIXA";
							formSangria.ShowDialog();
						}
					}
					// Alt + F5 - Vendas
					if (e.Alt && e.KeyCode == Keys.F5 && this.lblMenuFecharCaixa.Enabled == true)
					{
						this.ExibirLayoutCaixaLivre();
					}

					// Alt + F7 - Sintegra
					// Alt + F8 - Relatorios
					if (e.Alt && e.KeyCode == Keys.F7 || 
						e.Alt && e.KeyCode == Keys.F8)
					{
						pnlSintegra.Visible = true;
						dtInicial.Value = DateTime.Now;
						dtFinal.Value = DateTime.Now;
						lblMenuSair.Text = "F10 - Voltar";
						if (e.KeyCode == Keys.F7)
						{
							lblRelatorios.Text = "Relat�rio Sintegra";
							txtSintegra.Visible = true;
							grbRelatorios.Visible = false;
						}
						else
						{
							lblRelatorios.Text = "Relat�rios Gerenciais";
							txtSintegra.Visible = false;
							grbRelatorios.Visible = true;
						}
					}
				}
				else
				{
					// F2 - Iniciar venda
					if (e.KeyCode == Keys.F2 && lblMenuIniciarVenda.Enabled == true)
					{
						msgErro = "Erro na Abertura da Venda";
						printer.Cupom.Abrir();
						this.ExibirLayoutVenda();
					}
					
						// F3 - Fechar venda
					else if (e.KeyCode == Keys.F3 && lblMenuAlterarQtde.Enabled == true)
					{
						this.txtQuantidade.Focus();
					}
					
						// F4 - Cancelar item
					else if (e.KeyCode == Keys.F4 && lblMenuCancelarItem.Enabled == true)
					{
						frmCancelamentoItem frm = new frmCancelamentoItem(this);
						frm.ShowDialog();

						if (printer.Cupom.ItensVendidos.Count == 0)
						{
							this.lblMenuCancelarItem.Enabled = false;
							this.lblMenuFecharVenda.Enabled = false;
						}
						this.lblTotalVenda.Text = printer.Cupom.SubTotal.ToString("N");

					}
					
						// F5 - Fechar venda
					else if (e.KeyCode == Keys.F5 && lblMenuFecharVenda.Enabled == true)
					{
						msgErro = "Erro no Fechamento da Venda";
						printer.Cupom.SubTotalizar();
						printer.Cupom.Totalizar();

						// Preparando o cupom para ser colocado na tela
						StringBuilder cupom = new StringBuilder(200);
						cupom.Append(' ', 40);
						cupom.Append('-', 11);
						cupom.Append('\n');
						cupom.Append("TOTAL R$");
						cupom.AppendFormat(printer.Cupom.SubTotal.ToString("N").PadLeft(43, ' '));
						cupom.Append('\n');

						AtualizarDisplay(cupom.ToString());
						txtCodigo.Visible = false;
						txtQuantidade.Visible = false;
						cboFormasPagamento.Visible = true;
						txtValorPagamento.Visible = true;
						txtValorPagamento.Text = printer.Cupom.SubTotal.ToString("N");
						cboFormasPagamento.SelectedIndex = 0;
						cboFormasPagamento.Focus();
						this.ExibirLayoutFechamentoVenda();
					}

						// F7 - Administrativo TEF
					else if (e.KeyCode == Keys.F7 && lblMenuAdministrativoTEF.Enabled == true)
					{
						frmAdministrativo adm = new frmAdministrativo();
						if (adm.ShowDialog(this) == DialogResult.OK)
						{
							Cursor = Cursors.WaitCursor;
							Application.DoEvents();
							AdministrativoTEF(adm.cboRede.Text);
							Cursor = Cursors.Default;
						}
						adm.Dispose();
					}
					
						// F6 - Cancelar venda
					else if (e.KeyCode == Keys.F6 && lblMenuCancelarVenda.Enabled == true)
					{
						CancelarCupom();
						CancelarTransacaoTEFPendente();
					}
					
						// F8 - Suprimento
					else if (e.KeyCode == Keys.F8 && lblMenuSuprimento.Enabled == true)
					{
						frmSangriaSuprimento formSuprimento = new frmSangriaSuprimento(this);
						formSuprimento.Tag = "SUPRIMENTO";
						formSuprimento.ShowDialog();
					}
						
						// F9 - Sangria
					else if (e.KeyCode == Keys.F9 && lblMenuSangria.Enabled == true)
					{
						frmSangriaSuprimento formSuprimento = new frmSangriaSuprimento(this);
						formSuprimento.Tag = "SANGRIA";
						formSuprimento.ShowDialog();
					}
					else if (e.KeyCode == Keys.F10 && lblMenuSair.Enabled == true)
					{
						// se estiver na tela de venda volta para a tela principal
						// (abertura e fechamento do caixa)
						if (this.lblCaixaLivre.Text == "CAIXA LIVRE")
						{
							this.ExibirLayoutCaixaAberto();
						}
						else if (pnlSintegra.Visible)
						{
							pnlSintegra.Visible = false;
							lblMenuSair.Text = "F10 - Sair";
						}
						else
						{
							printer.GerenciamentoDados.Dispose(); //destrutor da classe sintegra
							this.Close();
							this.Dispose();
						}
					}
				}
			}
			catch (Exception erro)
			{
				MessageBox.Show(erro.Message, msgErro, MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void cboFormasPagamento_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)Keys.Enter)
			{
				txtValorPagamento.Focus();
			}
		}
	
		private void EfetuarPagamento()
		{
			try
			{
				decimal valorPagamento = decimal.Parse(txtValorPagamento.Text);

				if (cboFormasPagamento.Text == "Amex" || 
					cboFormasPagamento.Text == "Visa" || 
					cboFormasPagamento.Text == "Redecard" || 
					cboFormasPagamento.Text.IndexOf("Tecban") >= 0 )
				{
					if (valorPagamento > (printer.Cupom.SubTotal - printer.Cupom.ValorPago))
					{
						MessageBox.Show("N�o � permitido troco para as opera��es TEF.", "PDV-CSHARP", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
						return;
					}

					this.Cursor = Cursors.WaitCursor;
					
					// Confirma a transa��o anterior antes de solicitar uma nova
					if (printer.TEF.TransacaoNaoConfirmada)
					{
						SolicitacaoConfirmacao confirmacao = printer.TEF.CriarSolicitacaoConfirmacao();
						printer.TEF.ConfirmarTransacao(confirmacao);
						Application.DoEvents();
						System.Threading.Thread.Sleep(2);
					}

					Transacao transacao = null;

					if (cboFormasPagamento.Text.IndexOf("Tecban") >= 0)
					{
						printer.TEF.PathSolicitacao = @"C:\Tef_disc\req";
						printer.TEF.PathResposta	= @"C:\Tef_disc\resp";
						
						if (cboFormasPagamento.Text == "Cheque Tecban")
						{
							SolicitacaoCheque solicitacao = printer.TEF.CriarSolicitacaoCheque(cboFormasPagamento.Text, valorPagamento);
							transacao = printer.TEF.EnviarSolicitacao(solicitacao);
						}
						else
						{
							SolicitacaoCartao solicitacao = printer.TEF.CriarSolicitacaoCartao(cboFormasPagamento.Text, valorPagamento);
							transacao = printer.TEF.EnviarSolicitacao(solicitacao);
						}
					}
					else
					{
						printer.TEF.PathSolicitacao = @"C:\Tef_dial\req";
						printer.TEF.PathResposta	= @"C:\Tef_dial\resp";
						
						SolicitacaoCartao solicitacao = printer.TEF.CriarSolicitacaoCartao(cboFormasPagamento.Text, valorPagamento);
						//solicitacao.Buffer.Insert(2, "777-777 = 10\r\n");
						transacao = printer.TEF.EnviarSolicitacao(solicitacao);
					}
					
					Application.DoEvents();
					if (transacao.Status != TRANSACAO_APROVADA)
					{
						this.Cursor = Cursors.Default;
						frmOperador formOperador = new frmOperador(transacao.TextoOperador);
						formOperador.ShowDialog();
						formOperador.Dispose();
						return;
					}
				}

				// tratamento de desligamento da impressora no cupom fiscal
				while (true)
				{
					try
					{
						printer.Cupom.EfetuarPagamento(cboFormasPagamento.Text, valorPagamento);
						break;
					}
					catch
					{
						if (MessageBox.Show("Impressora n�o responde. Tentar imprimir novamente?", "PDV-CSharp", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1) == DialogResult.No)
						{
							NaoConfirmarTransacao();
							return;
						}

					}
				}

				//Preparando o cupom para ser colocado na tela
				StringBuilder cupom = new StringBuilder(105);
				cupom.AppendFormat("{0,-16:G}", cboFormasPagamento.Text);
				cupom.AppendFormat(valorPagamento.ToString("N").PadLeft(35, ' '));
				cupom.Append('\n');

				AtualizarDisplay(cupom.ToString());

				if (printer.Cupom.ValorPago < printer.Cupom.SubTotal)
				{
					txtValorPagamento.Text = decimal.Subtract(printer.Cupom.SubTotal, printer.Cupom.ValorPago).ToString("N");
					cboFormasPagamento.SelectedIndex = 0;
					cboFormasPagamento.Focus();
				}
						
				else
				{
					Mensagens msgs = new Mensagens();
					msgs.Adicionar(new TextoFormatado("Muito Obrigado",Bematech.Texto.TextoFormatado.TamanhoCaracter.Normal,TextoFormatado.FormatoCaracter.Italico,TextoFormatado.TipoAlinhamento.Centralizado	));
					TextoFormatado msg = new TextoFormatado("Ter voc� como cliente � um privil�gio. Obrigado e volte sempre.");
					msgs.Adicionar(msg);
					
					// tratamento de desligamento da impressora no cupom fiscal
					while (true)
					{
						try
						{
							printer.Cupom.Fechar(msgs);
							break;
						}
						catch (GerenciadorDadosException erro)
						{
							MessageBox.Show(erro.Message, "Erro no Gerenciamento de Dados", MessageBoxButtons.OK, MessageBoxIcon.Error);
							break;
						}
						catch (TEFException)
						{
							if (MessageBox.Show("Impressora n�o responde. Tentar imprimir novamente?", "PDV-CSharp", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1) == DialogResult.No)
							{
								NaoConfirmarTransacao();
								return;
							}

						}
						catch(Exception ex)
						{
							MessageBox.Show(ex.Message);
							break;
						}
					}
					valorPagamento = printer.Cupom.ValorPago - printer.Cupom.SubTotal; // troco

					//Preparando a string Valor Recebido e Troco para ser exibido no display;
					cupom =  new StringBuilder(105);
					cupom.Append("Valor Recebido R$");
					cupom.AppendFormat(printer.Cupom.ValorPago.ToString("N").PadLeft(34, ' '));
					cupom.Append('\n');
					cupom.Append("Troco R$");
					cupom.AppendFormat(valorPagamento.ToString("N").PadLeft(43, ' '));
					cupom.Append('\n');
					AtualizarDisplay(cupom.ToString());

					Application.DoEvents();
					
					if ( printer.TEF.Transacoes.Count > 0)
					{
						ImprimirTEF();
					}

					this.Cursor = Cursors.Default;
					frmTroco frm = new frmTroco(valorPagamento);
					frm.ShowDialog();
					ExibirLayoutCaixaLivre();
				}
			}
			catch (TEFException erro)
			{
				frmOperador formOperador = new frmOperador(erro.Message);
				formOperador.ShowDialog();
				formOperador.Dispose();
			}
			catch (Exception erro)
			{
				frmOperador formOperador = new frmOperador(erro.Message);
				formOperador.ShowDialog();
				formOperador.Dispose();
			}
			finally
			{
				cboFormasPagamento.Focus();
				this.Cursor = Cursors.Default;
			}
		}

		/// <summary>
		/// Atualiza o display do cupom fiscal no form de venda
		/// </summary>
		/// <param name="mensagem">Texto a ser exibido no display</param>
		public void AtualizarDisplay(string mensagem)
		{
			rtbCupom.Focus();
			rtbCupom.SelectedText = mensagem;
			rtbCupom.ScrollToCaret();
			txtCodigo.Focus();
		}

		private void txtValorPagamento_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)Keys.Enter)
			{
				EfetuarPagamento();
			}
			else if (e.KeyChar == '.')
			{
				e.Handled = true;
				SendKeys.Send(",");  //converte o ponto para virgula
			}
			else if ((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != (char)Keys.Back && e.KeyChar != ',')
			{
				e.Handled = true;
				SendKeys.Send("");
			}
		}
		private void frmVenda_Load(object sender, System.EventArgs e)
		{

			try
			{
				// Exibe o form de splash
				frmSplash formSplash = new frmSplash();
				formSplash.ShowDialog();

				// Se houver transa��o TEF pendente cancela. 
				if (printer.TEF.Transacoes.Count > 0)
				{
					CancelarCupom(); // Cancela o cupom fiscal se estiver aberto 
					CancelarTransacaoTEFPendente();
				}

				// String de conexao com o banco access
				//conexaoBanco = conectar("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Application.StartupPath + @"\ExemDotNET.mdb;User ID=Admin;Jet OLEDB:Database Locking Mode=1;persist security info=False");

				GerenciadorDados sintegra = new GerenciadorDados(conexao);						
				CultureInfo myCultura = new CultureInfo(CultureInfo.CurrentCulture.LCID,false);
				myCultura.NumberFormat.NumberDecimalSeparator = ".";
				myCultura.DateTimeFormat.ShortDatePattern = "#MM/dd/yyyy#";
				myCultura.DateTimeFormat.LongTimePattern  = "";
				sintegra.CulturaInfo = myCultura; // no sqlserver N�o deve usar essa cultura			
				printer.GerenciamentoDados = sintegra;
			
				// Habilita gerenciamento dados para o sintegra e para 
				// os relat�rios gerenciais
				printer.GerenciamentoDados.GerenciaSintegra = true;
				printer.GerenciamentoDados.GerenciaRelatorio = true;

				if (printer.Cupom.Status.Aberto)
				{
					this.RestaurarCupom();
				}
				else
				{
					if (printer.Informacao.DataMovimento == DateTime.MinValue)
					{
						// PROGRAMANDO ALIQUOTA
						Inicia cdmInicializacao = printer.Inicializacao;
						try
						{
							if (printer.Informacao.Aliquotas.Count < 6)
							{
								cdmInicializacao.ProgramarAliquota(1.50M,Aliquota.TipoAliquota.ISS);
								cdmInicializacao.ProgramarAliquota(2.00M,Aliquota.TipoAliquota.ISS);
								cdmInicializacao.ProgramarAliquota(3.00M,Aliquota.TipoAliquota.ISS);
								cdmInicializacao.ProgramarAliquota(4.50M,Aliquota.TipoAliquota.ISS);
								cdmInicializacao.ProgramarAliquota(5.00M,Aliquota.TipoAliquota.ISS);
								cdmInicializacao.ProgramarAliquota(6.00M,Aliquota.TipoAliquota.ISS);
							}
						}
						catch (BematechException erro)
						{
							MessageBox.Show(erro.Message, "Erro ao tentar cadastrar aliquotas", MessageBoxButtons.OK, MessageBoxIcon.Error);
						}

						this.ExibirLayoutCaixaFechado();
					}
					else
					{
						this.ExibirLayoutCaixaLivre();
					}
				}
			}
			catch (Exception erro)
			{
				frmOperador formOperador = new frmOperador(erro.Message);
				if (erro.GetType() == typeof(ComunicacaoException))
				{
					formOperador = new frmOperador("Erro de comunica��o com a impressora.");
				}
				
				formOperador.ShowDialog();
				formOperador.Dispose();
				this.Dispose();
			}
		}
		private void LimparControles()
		{
			this.rtbCupom.Clear();
			this.txtCodigo.Text = "";
			this.txtQuantidade.Text = "1";
			this.txtValorPagamento.Text = "0,00";
			this.lblProduto.Text = "";
			this.lblTotalVenda.Text = "0,00";
			this.lblTotalItem.Text = "0,00";
			this.lblValorUnitario.Text = "0,00";
			this.txtCodigo.Focus();
		}

		internal void ExibirLayoutCaixaLivre()
		{
			// objetos pictures
			this.pctMenus.Visible = true;
			this.pctCupom.Visible = false;
			this.pctDadosVenda.Visible = false;
			this.pctDescricaoProduto.Visible = false;
			this.pctDadoFechamentoVenda.Visible = false;

			this.rtbCupom.Visible = false;
			this.cboFormasPagamento.Visible = false;
			this.grbSeparador1.Visible = true;
			this.grbSeparador2.Visible = true;

			this.lblCaixaLivre.Text = "CAIXA LIVRE";
			this.lblMenuAbrirCaixa.Enabled = false;
			this.lblMenuAbrirCaixa.Visible = false;
			this.lblMenuFecharCaixa.Enabled = false;
			this.lbSintegra.Visible = false;
			this.lblMenuFecharCaixa.Visible = false;
			this.lblMenuVendas.Visible = false;
			this.lblMenuVendas.Enabled = false;
			this.lblMenuIniciarVenda.Visible = true;
			this.lblMenuIniciarVenda.Enabled = true;
			this.lblMenuAlterarQtde.Visible = true;
			this.lblMenuAlterarQtde.Enabled = false;
			this.lblMenuCancelarVenda.Visible = true;
			this.lblMenuCancelarVenda.Enabled = false;
			this.lblMenuFecharVenda.Visible = true;
			this.lblMenuFecharVenda.Enabled = false;
			this.lblMenuCancelarItem.Visible = true;
			this.lblMenuCancelarItem.Enabled = false;
			this.lblMenuSair.Text = "F10 - Voltar";
			this.lblMenuSair.Enabled = true;
			this.lblMenuAdministrativoTEF.Visible = true;
			this.lblMenuAdministrativoTEF.Enabled = true;
			this.lblMenuSuprimento.Visible = true;
			this.lblMenuSuprimento.Enabled = true;
			this.lblMenuSangria.Visible = true;
			this.lblMenuSangria.Enabled = true;
			this.lblProduto.Visible = false;
			this.lblTotalVenda.Visible = false;
			this.lblTotalItem.Visible = false;
			this.lblValorUnitario.Visible = false;
			this.lblCaixaLivre.Visible = true;

			this.txtCodigo.Visible = false;
			this.txtQuantidade.Visible = false;
			this.txtValorPagamento.Visible = false;
		}
		internal void ExibirLayoutCaixaAberto()
		{
			// objetos pictures
			this.pctMenus.Visible = true;
			this.pctCupom.Visible = false;
			this.pctDadosVenda.Visible = false;
			this.pctDescricaoProduto.Visible = false;
			this.pctDadoFechamentoVenda.Visible = false;

			this.rtbCupom.Visible = false;
			this.cboFormasPagamento.Visible = false;
			this.grbSeparador1.Visible = false;
			this.grbSeparador2.Visible = true;

			this.lblCaixaLivre.Text = "CAIXA ABERTO";
			this.lblMenuIniciarVenda.Visible = false;
			this.lblMenuIniciarVenda.Enabled = false;
			this.lblMenuAlterarQtde.Visible = false;
			this.lblMenuAlterarQtde.Enabled = false;
			this.lblMenuCancelarVenda.Visible = false;
			this.lblMenuCancelarVenda.Enabled = false;
			this.lblMenuFecharVenda.Visible = false;
			this.lblMenuFecharVenda.Enabled = false;
			this.lblMenuSair.Enabled = true;
			this.lblMenuSair.Enabled = true;
			this.lblMenuSair.Text = "F10 - Sair";
			this.lblMenuCancelarItem.Visible = false;
			this.lblMenuCancelarItem.Enabled = false;
			this.lblMenuAdministrativoTEF.Visible = false;
			this.lblMenuAdministrativoTEF.Enabled = false;
			this.lblMenuSuprimento.Visible = false;
			this.lblMenuSuprimento.Enabled = false;
			this.lblMenuSangria.Visible = false;
			this.lblMenuSangria.Enabled = false;
			this.lblMenuAbrirCaixa.Visible = true;
			this.lblMenuAbrirCaixa.Enabled = false;
			this.lbSintegra.Visible = true;
			this.lblMenuFecharCaixa.Visible = true;
			this.lblMenuFecharCaixa.Enabled = true;
			this.lblMenuVendas.Visible = true;
			this.lblMenuVendas.Enabled = true;

			this.lblProduto.Visible = false;
			this.lblTotalVenda.Visible = false;
			this.lblTotalItem.Visible = false;
			this.lblValorUnitario.Visible = false;
			this.lblCaixaLivre.Visible = true;

			this.txtCodigo.Visible = false;
			this.txtQuantidade.Visible = false;
			this.txtValorPagamento.Visible = false;
		}
		internal void ExibirLayoutCaixaFechado()
		{
			// objetos pictures
			this.pctMenus.Visible = true;
			this.pctCupom.Visible = false;
			this.pctDadosVenda.Visible = false;
			this.pctDescricaoProduto.Visible = false;
			this.pctDadoFechamentoVenda.Visible = false;

			this.rtbCupom.Visible = false;
			this.cboFormasPagamento.Visible = false;
			this.grbSeparador1.Visible = false;
			this.grbSeparador2.Visible = false;

			this.lblCaixaLivre.Text = "CAIXA FECHADO";
			this.lblMenuIniciarVenda.Visible = false;
			this.lblMenuIniciarVenda.Enabled = false;
			this.lblMenuAlterarQtde.Visible = false;
			this.lblMenuAlterarQtde.Enabled = false;
			this.lblMenuCancelarVenda.Visible = false;
			this.lblMenuCancelarVenda.Enabled = false;
			this.lblMenuFecharVenda.Visible = false;
			this.lblMenuFecharVenda.Enabled = false;
			this.lblMenuSair.Enabled = true;
			this.lblMenuSair.Enabled = true;
			this.lblMenuCancelarItem.Visible = false;
			this.lblMenuCancelarItem.Enabled = false;
			this.lblMenuAdministrativoTEF.Visible = false;
			this.lblMenuAdministrativoTEF.Enabled = false;
			this.lblMenuSuprimento.Visible = false;
			this.lblMenuSuprimento.Enabled = false;
			this.lblMenuSangria.Visible = false;
			this.lblMenuSangria.Enabled = false;
			this.lblMenuAbrirCaixa.Visible = true;
			this.lblMenuAbrirCaixa.Enabled = true;
			this.lbSintegra.Visible = true;
			this.lblMenuFecharCaixa.Visible = true;
			this.lblMenuFecharCaixa.Enabled = false;
			this.lblMenuVendas.Visible = true;
			this.lblMenuVendas.Enabled = false;

			this.lblProduto.Visible = false;
			this.lblTotalVenda.Visible = false;
			this.lblTotalItem.Visible = false;
			this.lblValorUnitario.Visible = false;
			this.lblCaixaLivre.Visible = true;

			this.txtCodigo.Visible = false;
			this.txtQuantidade.Visible = false;
			this.txtValorPagamento.Visible = false;

			//this.pnlSintegra.Visible = true;
		}
		private void ExibirLayoutVenda()
		{
			this.LimparControles();
			//this.valorPagar = 0;
			//this.valorPago = 0;
			this.LerInformacoesCabecalhoCupom();
			this.MontarCabecalhoCupom();

			this.pctMenus.Visible = true;
			this.pctCupom.Visible = true;
			this.pctDadosVenda.Visible = true;
			this.pctDescricaoProduto.Visible = true;
			this.pctDadoFechamentoVenda.Visible = false;

			this.rtbCupom.Visible = true;
			this.cboFormasPagamento.Visible = false;
			
			this.txtCodigo.Visible = true;
			this.txtQuantidade.Visible = true;
			this.txtValorPagamento.Visible = false;
			
			this.lblCaixaLivre.Visible = false;
			this.lblMenuAbrirCaixa.Visible = false;
			this.lbSintegra.Visible = false;
			this.lblMenuFecharCaixa.Visible = false;
			this.lblMenuVendas.Visible = false;
			this.lblMenuIniciarVenda.Enabled = false;
			this.lblMenuAlterarQtde.Enabled = true;
			this.lblMenuCancelarItem.Enabled = false;
			this.lblMenuCancelarVenda.Enabled = true;
			this.lblMenuFecharVenda.Enabled = false;
			this.lblMenuSair.Enabled = false;
			this.lblMenuAdministrativoTEF.Enabled = false;
			this.lblMenuSuprimento.Enabled = false;
			this.lblMenuSangria.Enabled = false;
			this.lblProduto.Visible = true;
			this.lblTotalVenda.Visible = true;
			this.lblTotalItem.Visible = true;
			this.lblValorUnitario.Visible = true;
			this.txtCodigo.Focus();

			this.Refresh();
		}
		private void ExibirLayoutFechamentoVenda()
		{
			this.pctMenus.Visible = true;
			this.pctCupom.Visible = true;
			this.pctDadoFechamentoVenda.Visible = true;
			this.pctDadosVenda.Visible = false;
			this.pctDescricaoProduto.Visible = false;

			this.cboFormasPagamento.Visible = true;
			this.txtValorPagamento.Visible = true;
			this.txtCodigo.Visible = false;
			this.txtQuantidade.Visible = false;

			this.lblProduto.Visible = false;
			this.lblTotalVenda.Visible = false;
			this.lblTotalItem.Visible = false;
			this.lblValorUnitario.Visible = false;
			this.lblMenuAlterarQtde.Enabled = false;
			this.lblMenuFecharVenda.Enabled = false;
			this.lblMenuCancelarItem.Enabled = false;
		}
		private bool LerInformacoesCabecalhoCupom()
		{
			try
			{
				if (this.cliche == null)
					this.cliche = printer.Informacao.ClicheProprietario;
			
				if (this.inscricaoEstadual == null)
					this.inscricaoEstadual = printer.Informacao.InscricaoEstadual;
			
				if (this.CNPJ == null)
					this.CNPJ = printer.Informacao.CNPJ;
			}
			catch
			{
				return false;
			}

			return true;
			
		}
		private void MontarCabecalhoCupom()
		{
			StringBuilder cupom = new StringBuilder(500);
			cupom.Append(cliche);
			cupom.Append("CNPJ:");
			cupom.Append(CNPJ);
			cupom.Append('\n');
			cupom.Append("IE:");
			cupom.Append(inscricaoEstadual);
			cupom.Append('\n');
			cupom.Append('-', 51);
			cupom.Append('\n');
			cupom.Append(' ', 19);
			cupom.Append("CUPOM FISCAL");
			cupom.Append('\n');
			cupom.Append("ITEM  ");
			cupom.Append("DESCRI��O                     ");
			cupom.Append("QTD  ");
			cupom.Append("TOTAL ITEM");
			cupom.Append('\n');
			cupom.Append('-', 51);
			cupom.Append('\n');
			this.AtualizarDisplay(cupom.ToString());
		}

		private void rtbCupom_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			this.txtCodigo.Focus();
		}

		private void txtQuantidade_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Tab)
			{
				if (this.txtQuantidade.Text == null)
				{
					MessageBox.Show("Quantidade inv�lida", "ExemploCSharp",MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					txtQuantidade.Text = "";
					txtQuantidade.Focus();
				}
				this.txtCodigo.Focus();
			}
			else if ((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != (char)Keys.Back)
			{
				e.Handled = true;
				SendKeys.Send("");
			}
		}
	
		private void RestaurarCupom()
		{
			ExibirLayoutVenda();

			// percorre a cole��o de itens vendidos exibindo-os na tela
			foreach(Item item in printer.Cupom.TodosItens)
			{
				StringBuilder cupom = new StringBuilder(200);
				cupom.AppendFormat("{0:000}", item.NumeroSequencial);
				cupom.Append(' ',2);
				cupom.AppendFormat("{0,-29:G}", item.Descricao);
				cupom.Append(' ',2);
				cupom.AppendFormat(item.Quantidade.ToString("G").PadLeft(3, ' '));
				cupom.AppendFormat(item.ValorTotal.ToString("N").PadLeft(12, ' '));
				cupom.Append('\n');
				AtualizarDisplay(cupom.ToString());
			}

			// percorre a cole��o de itens cancelados exibindo-os na tela
			foreach(Item item in printer.Cupom.ItensCancelados)
			{
				// Preparando o cupom para ser colocado na tela
				StringBuilder cupom = new StringBuilder(30);
				cupom.Append("Item Cancelado: ");
				cupom.Append(item.NumeroSequencial.ToString().PadLeft(3,'0'));
				cupom.Append(decimal.Negate(item.ValorTotal).ToString("N").PadLeft(32,' '));
				cupom.Append('\n');
				AtualizarDisplay(cupom.ToString());
			}

			if (printer.Cupom.ItensVendidos.Count > 0)
			{
				this.lblMenuCancelarItem.Enabled = true;
				this.lblMenuFecharVenda.Enabled = true;
				this.lblTotalVenda.Text = printer.Cupom.SubTotal.ToString("N");
			}
			
			if (printer.Cupom.Status.SubTotalizado)
			{
				this.ExibirLayoutFechamentoVenda();
				//this.valorPagar = printer.Cupom.SubTotal;

				// Preparando o cupom para ser colocado na tela
				StringBuilder cupom = new StringBuilder(200);
				cupom.Append(' ', 40);
				cupom.Append('-', 11);
				cupom.Append('\n');
				cupom.Append("TOTAL R$");
				cupom.AppendFormat(printer.Cupom.SubTotal.ToString("N").PadLeft(43, ' '));
				cupom.Append('\n');

				AtualizarDisplay(cupom.ToString());
				//txtCodigo.Visible = false;
				//txtQuantidade.Visible = false;
				//cboFormasPagamento.Visible = true;
				//txtValorPagamento.Visible = true;
				txtValorPagamento.Text = printer.Cupom.SubTotal.ToString("N");
				cboFormasPagamento.SelectedIndex = 0;
				cboFormasPagamento.Focus();
			}
			
			if (printer.Cupom.Status.EmPagamento)
			{
				foreach(PagamentoEfetuado pagamento in printer.Cupom.PagamentosEfetuados)
				{
					// Preparando o cupom para ser colocado na tela
					StringBuilder cupom = new StringBuilder(60);
					cupom.AppendFormat("{0,-16:G}", pagamento.Descricao);
					cupom.AppendFormat(pagamento.Valor.ToString("N").PadLeft(35, ' '));
					cupom.Append('\n');

					AtualizarDisplay(cupom.ToString());
				}
				txtValorPagamento.Text = decimal.Subtract(printer.Cupom.SubTotal, printer.Cupom.ValorPago).ToString("N");
			}
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			// gera��o de relat�rios gerenciais
			if (grbRelatorios.Visible)
			{
				try
				{		
					//GerenciadorDados manager = printer.Sintegra;			
					GerenciadorDados dadosRelatorios = new GerenciadorDados(conexao);
					
					// cultura usada porque est� sendo utilizado o access
					CultureInfo myCultura = new CultureInfo(CultureInfo.CurrentCulture.LCID,false);
					myCultura.NumberFormat.NumberDecimalSeparator = ".";
					myCultura.DateTimeFormat.ShortDatePattern = "#MM/dd/yyyy#";
					myCultura.DateTimeFormat.LongTimePattern  = "";
					dadosRelatorios.CulturaInfo = myCultura; // no sqlserver N�o deve usar essa cultura


					if (dadosRelatorios != null)
					{
						OleDbDataAdapter daRelatorios = new OleDbDataAdapter();
						DataSetRelatorios dsRelatorios;
						//dadosRelatorios.Conexao .GerarDataSetRelatorio(dsRelatorios, dtInicial.Value, dtFinal.Value, daRelatorios);

						GeradorRelatorio geradorRelatorios = new  GeradorRelatorio();														

						geradorRelatorios.CulturaInfo = myCultura;
						dsRelatorios = geradorRelatorios.GerarDataSetRelatorio(dadosRelatorios.Conexao, dtInicial.Value, dtFinal.Value, daRelatorios);
						RelatorioAdministrativo relatorio;

						if (rbtListaProdutos.Checked)
						{
							relatorio = geradorRelatorios.ListaDeProdutos(dsRelatorios, true);
						}
						
						else if (rbtVendasPorCliente.Checked)
						{
							relatorio = geradorRelatorios.VendasPorCliente(dsRelatorios, true);
						}
						
						else if (this.rbtVendasPorProduto.Checked)
						{
							relatorio = geradorRelatorios.VendasPorProduto(dsRelatorios, true);
						}
						
						else if (rbtVendasPorVendedor.Checked)
						{
							relatorio = geradorRelatorios.VendasPorVendedor(dsRelatorios, true);
						}
						
						else if (rbtVendasPorECF.Checked)
						{
							relatorio = geradorRelatorios.VendasPorECF(dsRelatorios, true);
						}
						
						else if (rbtListaClientes.Checked)
						{
							relatorio = geradorRelatorios.ListaDeClientes(dsRelatorios, true);
						}
											
						else if (rbtListaVendedores.Checked)
						{
							relatorio = geradorRelatorios.ListaDeVendedores(dsRelatorios, true);
						}
						
						else if (rbtTotalAliquota.Checked)
						{
							relatorio = geradorRelatorios.VendasPorAliquota(dsRelatorios);
						}
						
						else 
						{
							relatorio = geradorRelatorios.VendasPorPeriodo(dsRelatorios,dtInicial.Value,dtFinal.Value, true);
						}

						printPreviewDialog1.Document = relatorio.Documento;
						printPreviewDialog1.Bounds = new Rectangle(0,0,800,600); // 800x600
						printPreviewDialog1.ShowDialog();
					}

				}
				catch (Exception erro)
				{
					MessageBox.Show (erro.Message);
				}
			}
			else
			{
				System.Data.OleDb.OleDbDataAdapter temp = new System.Data.OleDb.OleDbDataAdapter();
				
				RelatorioSintegra relatSintegra = new RelatorioSintegra();						
				relatSintegra.CulturaInfo = printer.GerenciamentoDados.CulturaInfo;
				DataSetRelatorios myDataSet =  relatSintegra.GerarDataSetSintegra(printer.GerenciamentoDados.Conexao,dtInicial.Value,dtFinal.Value,temp);							
				relatSintegra.Registro10 = new RegistroTipo10(dtFinal.Value.Year,dtFinal.Value.Month);				
				relatSintegra.Registro10.Cidade = "Curitiba";
				relatSintegra.Registro10.CNPJ   = "82373077000171";
				relatSintegra.Registro10.InscricaoEstadual =  "1018146530";
				relatSintegra.Registro10.RazaoSocial = "Bematech S.A";
				relatSintegra.Registro10.Estado = UnidadeFederacao.PR;			
							
				relatSintegra.Registro11.Contato = "Fulano";
				relatSintegra.Registro11.Logradouro = "Estrada de Santa Candida";
				relatSintegra.Registro11.Numero = "263";
				relatSintegra.Registro11.CEP = "82630490";
				relatSintegra.Registro11.Telefone = "33512700";
	
				if (relatSintegra.Gerar(myDataSet,"sintegra.txt"))
				{	
					
					this.txtSintegra.Clear();			
					StreamReader sr = new StreamReader("Sintegra.txt");
					this.txtSintegra.Text = sr.ReadToEnd();
					sr.Close();
				}
				else
				{
					this.txtSintegra.Lines = (string[])relatSintegra.ListaErros.ToArray(typeof(string));				
				}		
			}
		}

		/// <summary>
		/// 
		/// </summary>
		private void ImprimirTEF()
		{
			if (ImprimirComprovantes(false))
			{
				ConfirmarTransacao(); // confirma a impress�o dos comprovantses
			}
			else
			{
				NaoConfirmarTransacao(); // n�o confirma a �ltima transa��o
				CancelarTransacao(); // cancela as transa��es confirmadas
			}
			printer.TEF.ClearTransacoes(); // limpa a cole��o de transa��es aprovadas
		}

		/// <summary>
		/// Imprime os comprovantes das transa��es TEF.
		/// </summary>
		/// <param name="gerencial"></param>
		/// <returns>True se as transa��es forem impressas com sucesso.</returns>
		private bool ImprimirComprovantes(bool gerencial)
		{
			//printer.TEF.CorteParcialEntreComprovantes = false;
			printer.TEF.TimeoutEntreComprovantes = 2;
			printer.TEF.TravarTeclado(true);

			frmImpressaoTEF impressao =  new frmImpressaoTEF();
			impressao.lblMensagem.Text = printer.TEF.Transacoes[0].TextoOperador;
			impressao.Show();
			Application.DoEvents();
			for (int i = 0; i < printer.TEF.Transacoes.Count; )
			{
				try
				{
					impressao.lblMensagem.Text = printer.TEF.Transacoes[i].TextoOperador;
					printer.TEF.Imprimir(printer.TEF.Transacoes[i], gerencial);
					i += 1;
				}
				catch
				{
					printer.TEF.TravarTeclado(false);
					if (MessageBox.Show("Impressora n�o responde. Tentar imprimir novamente?", "PDV-CSharp", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
					{
						Application.DoEvents();
						gerencial = true;
						i = 0;
						printer.TEF.TravarTeclado(true);
					}
					else
					{
						impressao.Dispose();
						Application.DoEvents();
						return false;
					}
				}
			}
			printer.TEF.TravarTeclado(false);
			impressao.Dispose();
			return true;
		}

		/// <summary>
		/// Imprime e confirma o cancelamento de uma transa��o TEF
		/// </summary>
		/// <param name="transacaoCancelamento">Transa��o de cancelamento a ser impressa</param>
		/// <returns>True se cancelamento ok, false se cancelamento n�o ok</returns>
		/// <remarks>Se houver algum erro (impressora desligada, gerenciador inativo)
		/// fica em loop at� que o cancelamento seja conclu�do com sucesso</remarks>
		private bool ImprimirCancelamento(Transacao transacaoCancelamento)
		{
			//printer.TEF.CorteParcialEntreComprovantes = false;
			printer.TEF.TimeoutEntreComprovantes = 2;
			printer.TEF.TravarTeclado(true);

			frmImpressaoTEF impressao =  new frmImpressaoTEF();
			impressao.lblMensagem.Text = transacaoCancelamento.TextoOperador;
			impressao.Show();
			Application.DoEvents();
			while (true)
			{
				try
				{
					printer.TEF.Imprimir(transacaoCancelamento, true);
					ConfirmarTransacao();
					printer.TEF.TravarTeclado(false);
					impressao.Dispose();
					break;
				}
				catch
				{
					printer.TEF.TravarTeclado(false);
					if (MessageBox.Show("Impressora n�o responde. Tentar imprimir novamente?", "PDV-CSharp", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1) == DialogResult.No)
					{
						impressao.Dispose();
						NaoConfirmarTransacao();
						return false;
					}
				}
			}
			return true;
		}

		/// <summary>
		/// N�o confirma a �ltima transa��o enviando um NCN.
		/// </summary>
		/// <remarks>Se o gerenciador padr�o estiver inativo, fica em loop at� que o mesmo
		/// seja ativado. </remarks>
		internal static void NaoConfirmarTransacao()
		{
			while (true)
			{
				try
				{
					SolicitacaoNaoConfirmacao NCN = printer.TEF.CriarSolicitacaoNaoConfirmacao();
					string mensagem = printer.TEF.NaoConfirmarTransacao(NCN);
					frmOperador formOperador = new frmOperador(mensagem);
					formOperador.ShowDialog();
					//MessageBox.Show (mensagem, "PDV-CSharp", MessageBoxButtons.OK, MessageBoxIcon.Information);
					break;
				}
				catch (GerenciadorInativoException)
				{
					MessageBox.Show("Gerenciador Padr�o n�o est� ativo!", "Gerenciador Inativo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); 
				}
				catch (TEFException erro)
				{
					MessageBox.Show(erro.Message, "PDV-CSharp", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); 
				}
			}
		}

		/// <summary>
		/// Confirma a �ltima transa��o aprovada.
		/// </summary>
		/// <remarks>Se o gerenciador padr�o estiver inativo, fica em loop at� que o mesmo
		/// seja ativado. </remarks>
		private void ConfirmarTransacao()
		{
			SolicitacaoConfirmacao CNF = printer.TEF.CriarSolicitacaoConfirmacao();
			while (true)
			{
				try
				{
					printer.TEF.ConfirmarTransacao(CNF);
					break;
				}
				catch (GerenciadorInativoException erro)
				{
					MessageBox.Show (erro.Message, "PDV-CSharp", MessageBoxButtons.OK, MessageBoxIcon.Information );
				}
				catch (Exception erro)
				{
					MessageBox.Show (erro.Message, "PDV-CSharp", MessageBoxButtons.OK, MessageBoxIcon.Error);
				}
				Application.DoEvents();
			}
		}

		/// <summary>
		/// Cancela todas as transa��es confirmadas. Se houver algum erro 
		/// fica em loop at� que todas as transa��es sejam canceladas.
		/// </summary>
		/// <remarks>Se a transa��o a ser cancelada for uma consulta
		/// de cheque ou consulta CDC envia um NCN, pois n�o h�
		/// cancelamento (CNC) para consulta</remarks>
		private void CancelarTransacao()
		{
			frmOperador formOperador = null;
			for (int i = printer.TEF.Transacoes.Count - 1; i >= 0; i-- )
			{
				if (printer.TEF.Transacoes[i].Tipo == CONSULTA_CDC || 
					printer.TEF.Transacoes[i].Tipo == CONSULTA_CHEQUE)
				{
					NaoConfirmarTransacao();
				}
				else
				{
					bool cancelamentoOk = false;
					while (!cancelamentoOk)
					{
						try
						{
							SolicitacaoCancelamento CNC = printer.TEF.CriarSolicitacaoCancelamento(printer.TEF.Transacoes[i]);
							Transacao cancelamento = printer.TEF.CancelarTransacao(CNC);
					
							if (cancelamento.Status == TRANSACAO_APROVADA)
							{
								// imprime e confirma o cancelamento
								// se houver erro durante a impress�o envia o NCN
								cancelamentoOk = ImprimirCancelamento(cancelamento);
							}
							else // cancelamento n�o aprovado
							{
								formOperador = new frmOperador(cancelamento.TextoOperador);
								formOperador.ShowDialog();
								formOperador.Dispose();
							}
						}
						catch (GerenciadorInativoException erro)
						{
							formOperador = new frmOperador(erro.Message);
							formOperador.ShowDialog();
							formOperador.Dispose();
						}
						catch (Exception erro)
						{
							formOperador = new frmOperador(erro.Message);
							formOperador.ShowDialog();
							formOperador.Dispose();
						}
					}
				}
			}
		}

		/// <summary>
		/// Cancela as transa��es TEF que n�o foram impressas
		/// </summary>
		private void CancelarTransacaoTEFPendente()
		{
			// verifica se tem transa��o TEF n�o confirmada se tiver envia 
			// uma n�o confirma��o
			if (printer.TEF.TransacaoNaoConfirmada)
			{
				NaoConfirmarTransacao();
			}

			// verifica se tem transa��o TEF confirmada, se tiver, cancela.
			if (printer.TEF.Transacoes.Count > 0)
			{
				CancelarTransacao();
			}
		}
		
		private void AdministrativoTEF(string rede)
		{
			if (rede == "TECBAN")
			{
				printer.TEF.PathSolicitacao = "C:\\TEF_DISC\\REQ";
				printer.TEF.PathResposta = "C:\\TEF_DISC\\RESP";
			}
			else
			{
				printer.TEF.PathSolicitacao = "C:\\TEF_DIAL\\REQ";
				printer.TEF.PathResposta = "C:\\TEF_DIAL\\RESP";
			}

			try
			{
				SolicitacaoAdministrativa solicitacao = printer.TEF.CriarSolicitacaoAdministrativa();
				Transacao transacao = printer.TEF.EnviarSolicitacao(solicitacao);
				if (transacao.Status == TRANSACAO_APROVADA && transacao.QuantidadeLinhas != "0")
				{
					while (true)
					{
						if (ImprimirComprovantes(true))
						{
							ConfirmarTransacao();
							printer.TEF.ClearTransacoes();
							break;
						}
						else
						{
							NaoConfirmarTransacao();
							CancelarTransacao();
							break;
						}
					}
				}
				else
				{
					frmOperador formOperador = new frmOperador(transacao.TextoOperador);
					formOperador.ShowDialog();
					formOperador.Dispose();
				}

			}
			catch (GerenciadorInativoException erro)
			{
				frmOperador formOperador = new frmOperador(erro.Message);
				formOperador.ShowDialog();
				formOperador.Dispose();
			}
			catch (Exception erro)
			{
				frmOperador formOperador = new frmOperador(erro.Message);
				formOperador.ShowDialog();
				formOperador.Dispose();
			}
		}

		private void btnFechar_Click(object sender, System.EventArgs e)
		{
			pnlSintegra.Visible = false;
		}

		private void CancelarCupom()
		{
			try
			{
				if (printer.Cupom.Status.Aberto)
				{
					printer.Cupom.Cancelar();
					ExibirLayoutCaixaLivre();
				}
			}
			catch (Exception erro)
			{
				throw erro;
			}
		}
	}
}
